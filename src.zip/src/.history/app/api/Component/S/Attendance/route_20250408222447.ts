import { NextResponse } from "next/server";
import mongoose from "mongoose";
import AttendanceModel from "@/models/Attendance";

interface StudentAttendance {
  studentId: mongoose.Types.ObjectId;
  rollNo: string;
  name: string;
  status: "P" | "A" | "L";
}

interface MongoAttendanceRecord {
  _id: mongoose.Types.ObjectId;
  date: Date;
  year: number;
  month: number;
  week: number;
  slotNumber: number;
  startTime: string;
  endTime: string;
  className: string;
  course: string;
  room: string;
  teacherId: string;
  students: StudentAttendance[];
  __v: number;
}

interface ProcessedAttendanceRecord {
  date: string;
  time: string;
  status: string;
  course: string;
  room: string;
}

export async function GET(request: Request) {
  try {
    const connectDB = async () => {
      if (mongoose.connection.readyState === 0) {
        await mongoose.connect(process.env.MONGODB_URI!, {
          serverSelectionTimeoutMS: 5000,
          family: 4
        });
      }
    };
    await connectDB();
    
    const { searchParams } = new URL(request.url);
    const className = searchParams.get("className")?.trim();
    const rollNo = searchParams.get("rollNo")?.trim();
    const course = searchParams.get("course")?.trim();

    // Validate parameters
    if (!className || !rollNo || !course) {
      return NextResponse.json(
        { error: "Missing required parameters" },
        { status: 400 }
      );
    }

    // Case-insensitive search with proper typing
    const attendanceRecords = await AttendanceModel.find({
      className: { $regex: new RegExp(`^${className}$`, 'i') },
      course: { $regex: new RegExp(`^${course}$`, 'i') }
    }).lean<MongoAttendanceRecord[]>();

    // Process records with validation
    const studentAttendance = attendanceRecords.flatMap((record) => {
      const students = record.students.filter(student => 
        student.rollNo.trim() === rollNo
      );
      
      if (!students.length) return [];
      
      return students.map(student => ({
        date: new Date(record.date).toISOString().split('T')[0],
        time: `${record.startTime} - ${record.endTime}`,
        status: student.status,
        course: record.course,
        room: record.room
      }));
    });
     // Calculate attendance stats
     const totalClasses = studentAttendance.length;
     const presents = studentAttendance.filter(a => a.status === "P").length;
     const absents = studentAttendance.filter(a => a.status === "A").length;
     const leaves = studentAttendance.filter(a => a.status === "L").length;
     const percentage = totalClasses > 0 
       ? Math.round((presents / totalClasses) * 100)
       : 0;
 
     return NextResponse.json({
       stats: { totalClasses, presents, absents, leaves, percentage },
       records: studentAttendance
     });

    // ... rest of the stats calculation ...
    
  } catch (error) {
    console.error("Detailed Error:", error);
    return NextResponse.json(
      { error: "Database connection failed. Please check server logs." },
      { status: 500 }
    );
  }
}

   