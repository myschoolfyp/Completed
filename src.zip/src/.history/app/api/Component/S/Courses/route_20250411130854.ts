import { NextResponse } from "next/server";
import mongoose from "mongoose";
const connectDB = async () => {
  if (mongoose.connection.readyState === 0) {
    await mongoose.connect(process.env.MONGODB_URI!);
  }
};

export async function GET(request: Request) {
  try {
    await connectDB();
    
    // Get class information from headers
    const classLevel = request.headers.get("classLevel");
    const classType = request.headers.get("classType");
    
    if (!classLevel || !classType) {
      return NextResponse.json(
        { error: "Class information missing" },
        { status: 400 }
      );
    }

    // Convert to database class name format (e.g., "TWO")
    const classNameMap: {[key: string]: string} = {
      "Grade 2 General": "TWO",
      // Add other mappings as needed
    };
    const className = classNameMap[`Grade ${classLevel} ${classType}`] || `Grade ${classLevel} ${classType}`;

    // Find class details
    const classData = await ClassModel.findOne({ className })
      .select("courses teachers")
      .lean();

    if (!classData) {
      return NextResponse.json(
        { error: "Class not found" },
        { status: 404 }
      );
    }

    // Map courses with teachers
    const coursesWithTeachers = classData.courses.map(course => {
      const teacher = classData.teachers.find(t => t.course === course);
      return {
        course,
        teacher: teacher?.teacher || "Not assigned",
        teacherId: teacher?.teacherId || ""
      };
    });

    return NextResponse.json(coursesWithTeachers);
  } catch (error) {
    console.error("Error:", error);
    return NextResponse.json(
      { error: "Internal Server Error" },
      { status: 500 }
    );
  }
}