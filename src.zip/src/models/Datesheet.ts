// models/Datesheet.ts (or wherever your schema lives)
import mongoose from 'mongoose';

const datesheetSchema = new mongoose.Schema({
  datesheetName: { type: String, required: true },
  className:     { type: String, required: true },
  classId:       { type: mongoose.Schema.Types.ObjectId, ref: 'Class', required: true },
  classLevel:    { type: String, required: true },
  schedule: [{
    course:    { type: String, required: true },
    date:      { type: Date,   required: true },
    startTime: { type: String, required: true, default: "" },
    endTime:   { type: String, required: true, default: "" },
    roomNo:    { type: String, default: "" }
  }],
  createdAt:    { type: Date, default: Date.now }
}, { collection: 'datesheets' });

export default mongoose.models.Datesheet || mongoose.model("Datesheet", datesheetSchema);
