import mongoose, { Document, Schema } from "mongoose";

export interface IRecipient {
  id: string;
  role: "admin" | "teacher" | "student" | "parent";
}

export interface IResponse {
  responderId: string;
  role: "admin" | "teacher" | "student" | "parent";
  message: string;
  createdAt: Date;
}

export interface IAnnouncement extends Document {
  message: string;
  attachmentUrl?: string;
  recipients: IRecipient[];
  responses: IResponse[];
  createdAt: Date;
  updatedAt: Date;
}

const AnnouncementSchema = new Schema<IAnnouncement>(
  {
    message: { type: String, required: true },
    attachmentUrl: { type: String },
    recipients: [
      {
        id: { type: Schema.Types.ObjectId, required: true, refPath: "recipients.role" },
        role: { type: String, required: true, enum: ["admin", "teacher", "student", "parent"] },
      },
    ],
    responses: [
      {
        responderId: { type: Schema.Types.ObjectId, required: true },
        role: { type: String, required: true, enum: ["admin", "teacher", "student", "parent"] },
        message: { type: String, required: true },
        createdAt: { type: Date, required: true },
      },
    ],
  },
  {
    collection: "annoucements",   // <— matches your existing Mongo collection
    timestamps: true,
  }
);

export default mongoose.models.Announcement ||
  mongoose.model<IAnnouncement>("Announcement", AnnouncementSchema);
