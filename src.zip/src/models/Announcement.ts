import mongoose, { Schema, Document } from "mongoose";

export interface IAnnouncement extends Document {
  stream: "admins" | "teachers" | "parents" | "students";
  kind: "announcement" | "complaint";
  recipients: string[];
  sender: string;
  description: string;
  date: Date;
  attachment?: { data: Buffer; name: string };
  replies?: {
    sender: string;
    description: string;
    date: Date;
  }[];
}

const ReplySchema = new Schema(
  {
    sender: { type: String, required: true },
    description: { type: String, required: true },
    date: { type: Date, default: () => new Date() },
  },
  { _id: false }
);

const AnnouncementSchema = new Schema<IAnnouncement>(
  {
    stream: {
      type: String,
      required: true,
      enum: ["admins", "teachers", "parents", "students"],
    },
    kind: {
      type: String,
      required: true,
      enum: ["announcement", "complaint"],
      default: "announcement",
    },
    recipients: { type: [String], required: true },
    sender: { type: String, required: true },
    description: { type: String, required: true },
    date: { type: Date, default: () => new Date() },
    attachment: {
      data: Buffer,
      name: String,
    },
    replies: { type: [ReplySchema], default: [] },
  },
  { collection: "announcements" }
);

export default mongoose.models.Announcement ||
  mongoose.model<IAnnouncement>("Announcement", AnnouncementSchema);
