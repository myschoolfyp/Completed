// src/models/Quiz.ts  (updated schema)
import mongoose, { Schema, Document } from "mongoose";

export type QuizMode = "online";

export interface IQuizSubmission {
  rollNo: string;
  studentName: string;
  submittedAt: Date;
  answers?: { question: number; answer: string }[];
}

export interface IQuiz extends Document {
  quizTitle: string;
  description?: string;
  className: string;
  course: string;
  totalMarks: number;
  deadline: Date;
  key: string;
  mode: QuizMode;
  questionCount: number;
  timeLimit: number;      // minutes
  shortNote?: string;
  correctAnswers: { question: number; answer: string }[];
  teacherId: mongoose.Types.ObjectId;
  teacherFirstName: string;
  teacherLastName: string;
  submissions: IQuizSubmission[];
}

const submissionSchema = new Schema<IQuizSubmission>({
  rollNo:      { type: String, required: true },
  studentName: { type: String, required: true },
  submittedAt: { type: Date,   default: Date.now },
  answers: [
    {
      question: { type: Number, required: true },
      answer:   { type: String, required: true },
    },
  ],
});

const quizSchema = new Schema<IQuiz>({
  quizTitle:       { type: String, required: true },
  description:     { type: String, default: "" },
  className:       { type: String, required: true },
  course:          { type: String, required: true },
  totalMarks:      { type: Number, required: true },
  deadline:        { type: Date,   required: true },
  key:             { type: String, required: true },
  mode:            { type: String, required: true, enum: ["online"] },
  questionCount:   { type: Number, required: true },
  timeLimit:       { type: Number, required: true },
  shortNote:       { type: String, default: "" },
  correctAnswers: [
    {
      question: { type: Number, required: true },
      answer:   { type: String, required: true },
    },
  ],
  teacherId:        { type: Schema.Types.ObjectId, required: true, ref: "Teacher" },
  teacherFirstName: { type: String, required: true },
  teacherLastName:  { type: String, required: true },
  submissions:      [submissionSchema],
});

export default mongoose.models.Quiz ||
  mongoose.model<IQuiz>("Quiz", quizSchema, "quizzes");
