"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";
import { Lock, UserCircle2, BookUser } from "lucide-react";

export default function Login() {
  const [cnic, setCnic] = useState("");
  const [rollNo, setRollNo] = useState("");
  const [password, setPassword] = useState("");
  const [category, setCategory] = useState("");
  const [error, setError] = useState("");
  const router = useRouter();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    try {
      const payload = {
        ...(category === "Student" ? { rollNo } : { cnic }),
        password,
        userType: category,
      };

      const response = await fetch("/api/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });

      if (!response.ok) {
        const { message } = await response.json();
        setError(message || "Error logging in");
        return;
      }

      const { 
        cnic: userCnic, 
        rollNo: userRollNo, 
        userType, 
        firstName, 
        lastName, 
        contactNumber 
      } = await response.json();

      alert("Login successful!");

      // Store identifier based on user type
      if (userType === "Student") {
        localStorage.setItem("rollNo", userRollNo);
      } else {
        localStorage.setItem("cnic", userCnic);
      }
      
      localStorage.setItem("firstName", firstName);
      localStorage.setItem("lastName", lastName);
      localStorage.setItem("contactNumber", contactNumber);

      router.push(`/Profile?userType=${userType}`);
    } catch (err) {
      setError("An unexpected error occurred");
    }
  };

  return (
    <div className="flex justify-center items-center min-h-screen bg-gradient-to-br from-[#0F6466]/10 to-[#2C3532]/5 p-4">
      <div className="w-full max-w-4xl bg-white rounded-xl shadow-2xl overflow-hidden border border-[#0F6466]/20">
        {/* Header with gradient */}
        <div className="bg-gradient-to-r from-[#0F6466] to-[#2C3532] p-6 text-center">
          <h2 className="text-3xl font-bold text-white">Welcome Back</h2>
          <p className="text-white/90 mt-2">Sign in to your account</p>
        </div>

        <div className="p-8 grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Left side - Visual element */}
          <div className="hidden lg:flex flex-col justify-center items-center bg-gradient-to-br from-[#0F6466]/10 to-[#2C3532]/10 rounded-lg p-6">
            <div className="w-full h-full flex items-center justify-center">
              <div className="text-center">
                <UserCircle2 className="mx-auto h-24 w-24 text-[#0F6466] mb-4" />
                <h3 className="text-2xl font-semibold text-[#0F6466]">Educational Portal</h3>
                <p className="mt-2 text-gray-600">Access your personalized learning dashboard</p>
              </div>
            </div>
          </div>

          {/* Right side - Form */}
          <div>
            {error && (
              <div className="mb-6 p-3 bg-red-50 border-l-4 border-red-500 text-red-700 rounded">
                <p className="text-center font-medium">{error}</p>
              </div>
            )}

            <form onSubmit={handleSubmit} className="space-y-6">
              {/* Role Selection */}
              <div>
                <label htmlFor="role" className="block text-sm font-medium text-gray-700 mb-2">
                  <div className="flex items-center">
                    <UserCircle2 className="mr-2 h-5 w-5 text-[#0F6466]" />
                    Select Your Role
                  </div>
                </label>
                <select
                  id="role"
                  value={category}
                  onChange={(e) => setCategory(e.target.value)}
                  required
                  className="w-full px-4 py-3 rounded-lg border-2 border-gray-200 focus:border-[#0F6466] focus:ring-2 focus:ring-[#0F6466]/30 transition-all appearance-none"
                >
                  <option value="" disabled>Select Your Role</option>
                  <option value="Teacher">Teacher</option>
                  <option value="Admin">Admin</option>
                  <option value="Parent">Parent</option>
                  <option value="Student">Student</option>
                </select>
              </div>

              {/* Dynamic Identifier Input */}
              {category === "Student" ? (
                <div>
                  <label htmlFor="rollNo" className="block text-sm font-medium text-gray-700 mb-2">
                    <div className="flex items-center">
                      <BookUser className="mr-2 h-5 w-5 text-[#0F6466]" />
                      Roll Number
                    </div>
                  </label>
                  <input
                    type="text"
                    id="rollNo"
                    value={rollNo}
                    onChange={(e) => setRollNo(e.target.value.replace(/\D/g, "").slice(0, 9))}
                    placeholder="123456789"
                    required
                    pattern="\d{9}"
                    className="w-full px-4 py-3 rounded-lg border-2 border-gray-200 focus:border-[#0F6466] focus:ring-2 focus:ring-[#0F6466]/30 transition-all"
                  />
                </div>
              ) : (
                <div>
                  <label htmlFor="cnic" className="block text-sm font-medium text-gray-700 mb-2">
                    <div className="flex items-center">
                      <BookUser className="mr-2 h-5 w-5 text-[#0F6466]" />
                      CNIC (Without Dashes)
                    </div>
                  </label>
                  <input
                    type="text"
                    id="cnic"
                    value={cnic}
                    onChange={(e) => setCnic(e.target.value.replace(/\D/g, "").slice(0, 13))}
                    placeholder="3420112345678"
                    required
                    pattern="\d{13}"
                    className="w-full px-4 py-3 rounded-lg border-2 border-gray-200 focus:border-[#0F6466] focus:ring-2 focus:ring-[#0F6466]/30 transition-all"
                  />
                </div>
              )}

              {/* Password Input */}
              <div>
                <label htmlFor="password" className="block text-sm font-medium text-gray-700 mb-2">
                  <div className="flex items-center">
                    <Lock className="mr-2 h-5 w-5 text-[#0F6466]" />
                    Password
                  </div>
                </label>
                <input
                  type="password"
                  id="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  required
                  className="w-full px-4 py-3 rounded-lg border-2 border-gray-200 focus:border-[#0F6466] focus:ring-2 focus:ring-[#0F6466]/30 transition-all"
                />
              </div>

              <div className="pt-2">
                <button
                  type="submit"
                  className="w-full py-3 bg-gradient-to-r from-[#0F6466] to-[#2C3532] text-white rounded-lg shadow-lg hover:from-[#2C3532] hover:to-[#0F6466] transition-all duration-300 text-lg font-semibold transform hover:scale-[1.01]"
                >
                  Sign In
                </button>
              </div>

              <div className="text-center text-sm text-gray-600">
                Don't have an account?{" "}
                <a 
                  href="Register#" 
                  className="font-semibold text-[#0F6466] hover:text-[#2C3532] transition-colors"
                >
                  Create account
                </a>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
  );
}