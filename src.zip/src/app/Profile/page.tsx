// app/Components/Profile/page.tsx
"use client";
import React, { useState, useEffect } from "react";
import { useSearchParams, useRouter } from "next/navigation";

interface Child {
  id: string;
  rollNo: string;
  name: string;
}
interface UserData {
  _id: string;
  firstName: string;
  lastName: string;
  email: string;
  contactNumber: string;
  profilePicture?: string;
  userType: string;
  department?: string;
  cnic?: string;
  rollNo?: string;
  classLevel?: string;
  classType?: string;
  className?: string;
  children?: Child[];
}

export default function Profile() {
  const searchParams = useSearchParams();
  const router       = useRouter();

  const [userType,     setUserType]     = useState<string | null>(null);
  const [userData,     setUserData]     = useState<UserData | null>(null);
  const [error,        setError]        = useState("");
  const [isMenuVisible,setIsMenuVisible]= useState(false);
  const [bgGradient,   setBgGradient]   = useState("from-[#0F6466]/90 to-[#0D4B4C]/90");

  // Per-role gradients
  const gradientMap: Record<string,string> = {
    Admin:   "from-[#0A4B4C]/90 to-[#0F6466]/90",
  Teacher: "from-[#0F6466]/90 to-[#208E8C]/90",
    Student: "from-[#17807A]/90 to-[#219E1C]/90",
    // Soft Cyan → Pale Aqua
    Parent:  "from-[#219E1C]/90 to-[#2AD6B6]/90",
  };
  
  

  useEffect(() => {
    // Try queryParam first; fallback to localStorage
    const utParam   = searchParams.get("userType");
    const utStored  = localStorage.getItem("userType");
    const ut        = utParam || utStored;

    // ID from either rollNo or cnic
    const id = ut === "Student"
      ? localStorage.getItem("rollNo")
      : localStorage.getItem("cnic");

    if (!ut || !id) {
      setError("Please login first");
      return;
    }

    setUserType(ut);
    setBgGradient(gradientMap[ut] || gradientMap.Student);
    fetchUserData(id, ut);
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  async function fetchUserData(identifier: string, ut: string) {
    try {
      const res = await fetch("/api/profile", {
        headers: { identifier, userType: ut },
      });
      const data = await res.json();

      if (!res.ok) {
        setError(data.message || "User not found");
        return;
      }

      setUserData(data);
      // Persist for reload
      localStorage.setItem("userType", ut);
      localStorage.setItem("firstName", data.firstName);
      localStorage.setItem("lastName", data.lastName);
      localStorage.setItem("email", data.email);
      localStorage.setItem("contactNumber", data.contactNumber);
      if (data.profilePicture) {
        localStorage.setItem("profilePicture", data.profilePicture);
      }

      if (ut === "Student") {
        localStorage.setItem("rollNo", data.rollNo!);
        localStorage.setItem("classLevel", data.classLevel!);
        localStorage.setItem("classType", data.classType!);
        localStorage.setItem("className", data.className!);
        localStorage.setItem("studentId", data._id);
      } else {
        localStorage.setItem("cnic", data.cnic!);
        localStorage.setItem(`${ut.toLowerCase()}Id`, data._id);
        if (ut === "Teacher" && data.department) {
          localStorage.setItem("department", data.department);
        }
      }
    } catch (e) {
      console.error(e);
      setError("Failed to fetch user details");
    }
  }

  function handleLogout() {
    localStorage.clear();
    router.push("/Login");
  }

  if (error) return <div className="text-red-500 text-center mt-10">{error}</div>;
  if (!userData) return <div className="text-center mt-10 text-xl">Loading...</div>;
  return (
    <div className={`flex bg-gradient-to-br ${bgGradient} min-h-screen`}>
      {/* Sidebar */}
      <nav className={`fixed inset-y-0 left-0 w-64 bg-white/10 backdrop-blur-md text-white shadow-xl flex flex-col transition-transform duration-300 overflow-y-auto ${isMenuVisible ? "translate-x-0" : "-translate-x-full"}`}>
        <div className="flex-grow">
          <div className="py-6 text-center font-bold text-2xl border-b border-white/20">
            {userData.userType} Dashboard
          </div>

          {/* Admin Menu */}
          {/* Admin Menu */}
          {userData.userType === "Admin" && (
  <div className="p-4 space-y-2">
    
    {/* 👤 Primary user groups */}
    {["Admins", "Teachers", "Students", "Parents"].map(label => (
      <button
        key={label}
        className="w-full py-3 bg-gradient-to-r from-purple-700 to-indigo-600 rounded-lg text-white font-medium hover:opacity-90"
        onClick={() => router.push(`/Components/A/${label}`)}
      >
        {label}
      </button>
    ))}
    <hr className="my-4 border-white" />

    {/* 📚 Academic sections */}
    {["Classes", "Courses", "Timetable"].map(label => (
      <button
        key={label}
        className="w-full py-3 bg-gradient-to-r from-blue-700 to-cyan-500 rounded-lg text-white font-medium hover:opacity-90"
        onClick={() => router.push(`/Components/A/${label}`)}
      >
        {label}
      </button>
    ))}
    <hr className="my-4 border-white" />

    {/* 📈 Results & Dates */}
    {["Datesheet", "Results"].map(label => (
      <button
        key={label}
        className="w-full py-3 bg-gradient-to-r from-green-600 to-emerald-400 rounded-lg text-white font-medium hover:opacity-90"
        onClick={() => router.push(`/Components/A/${label}`)}
      >
        {label}
      </button>
    ))}
    <hr className="my-4 border-white" />

    {/* 🛠️ Admin Tools */}
    {["Events", "Announcements",].map(label => (
      <button
        key={label}
        className="w-full py-3 bg-gradient-to-r from-yellow-600 to-orange-500 rounded-lg text-white font-medium hover:opacity-90"
        onClick={() => router.push(`/Components/A/${label}`)}
      >
        {label}
      </button>
    ))}

  </div>
)}



          {/* Teacher Menu */}
          {userData.userType === "Teacher" && (
  <div className="p-4 space-y-2">
    
    {/* 📘 Core Teaching Tools */}
    {["Timetable", "MyClasses"].map(label => (
      <button
        key={label}
        className="w-full py-3 bg-gradient-to-r from-indigo-600 to-sky-500 rounded-lg text-white font-medium hover:opacity-90"
        onClick={() => router.push(`/Components/T/${label}`)}
      >
        {label}
      </button>
    ))}

    {/* 📋 Class-Specific Features */}
    <button
      className="w-full py-3 bg-gradient-to-r from-blue-600 to-cyan-500 rounded-lg text-white font-medium hover:opacity-90"
      onClick={() => router.push("/Components/T/MyClasses/ViewClass/Attendance")}
    >
      Attendance
    </button>
    <button
      className="w-full py-3 bg-gradient-to-r from-blue-600 to-cyan-500 rounded-lg text-white font-medium hover:opacity-90"
      onClick={() => router.push("/Components/T/MyClasses/ViewClass/Assignments")}
    >
      Assignments
    </button>
    <button
      className="w-full py-3 bg-gradient-to-r from-blue-600 to-cyan-500 rounded-lg text-white font-medium hover:opacity-90"
      onClick={() => router.push("/Components/T/MyClasses/ViewClass/Quiz/Create")}
    >
      Quizzes
    </button>

    {/* 📊 Result Section */}
    <hr className="my-4 border-white/20" />
    <button
      className="w-full py-3 bg-gradient-to-r from-rose-600 to-pink-400 rounded-lg text-white font-medium hover:opacity-90"
      onClick={() => router.push("/Components/T/MyClasses/ViewClass/Results")}
    >
      Results
    </button>

    {/* 📢 Communication Tools */}
    <hr className="my-4 border-white/20" />
    {["Events", "Announcements","Complain"].map(label => (
      <button
        key={label}
        className="w-full py-3 bg-gradient-to-r from-emerald-600 to-teal-500 rounded-lg text-white font-medium hover:opacity-90"
        onClick={() => router.push(`/Components/T/${label}`)}
      >
        {label}
      </button>
    ))}
  </div>
)}

{/* Student Menu */}
{userData.userType === "Student" && (
  <div className="p-4 space-y-2">
    
    {/* 📘 Academic Tools */}
    {["Timetable", "Courses", "Attendance", "Assignments", "Quiz"].map(label => (
      <button
        key={label}
        className="w-full py-3 bg-gradient-to-r from-indigo-600 to-sky-500 rounded-lg text-white font-medium hover:opacity-90"
        onClick={() => router.push(`/Components/S/${label}`)}
      >
        {label}
      </button>
    ))}

    {/* 🧾 Exam-Related */}
    <hr className="my-4 border-white/20" />
    {["Datesheets", "Results"].map(label => (
      <button
        key={label}
        className="w-full py-3 bg-gradient-to-r from-pink-500 to-purple-500 rounded-lg text-white font-medium hover:opacity-90"
        onClick={() => router.push(`/Components/S/${label}`)}
      >
        {label}
      </button>
    ))}

    {/* 🗓️ Events & 📣 Announcements */}
    <hr className="my-4 border-white/20" />
    <div className="space-y-4">
      <button
        className="w-full py-3 bg-gradient-to-r from-emerald-600 to-teal-500 rounded-lg text-white font-medium hover:opacity-90"
        onClick={() => router.push('/Components/T/Events')}
      >
        Events
      </button>
      <button
        className="w-full py-3 bg-gradient-to-r from-yellow-500 to-orange-400 rounded-lg text-white font-medium hover:opacity-90"
        onClick={() => router.push('/Components/S/Announcements')}
      >
        Announcements
      </button>
    </div>

  </div>
)}

          {/* Parent Menu */}
          {userData.userType === "Parent" && (
  <div className="p-4 space-y-2">
    
    {/* Children Button */}
    <button
      className="w-full py-3 bg-gradient-to-r from-pink-600 to-rose-500 rounded-lg text-white font-medium"
      onClick={() => router.push("/Components/P/Children")}
    >
      Children
    </button>

    <hr className="my-4 border-white/20" />

    {/* Timetable, Courses, Attendance, Assignments */}
    {["Timetable", "Courses", "Attendance", "Assignments"].map(label => (
      <button
        key={label}
        className="w-full py-3 bg-gradient-to-r from-indigo-600 to-blue-500 rounded-lg text-white font-medium"
        onClick={() => router.push(`/Components/P/${label}`)}
      >
        {label}
      </button>
    ))}

    <hr className="my-4 border-white/20" />

    {/* DateSheet, Quiz, Results */}
    {["DateSheet", "Quiz", "Results"].map(label => (
      <button
        key={label}
        className="w-full py-3 bg-gradient-to-r from-green-600 to-emerald-500 rounded-lg text-white font-medium"
        onClick={() => router.push(`/Components/P/${label}`)}
      >
        {label}
      </button>
    ))}

    {/* Events & Announcements */}
    <hr className="my-4 border-white/20" />
    <div className="space-y-4">
      <button
        className="w-full py-3 bg-gradient-to-r from-red-600 to-pink-500 rounded-lg text-white font-medium"
        onClick={() => router.push('/Components/T/Events')}
      >
        Events
      </button>
      <button
        className="w-full py-3 bg-gradient-to-r from-yellow-600 to-orange-500 rounded-lg text-white font-medium"
        onClick={() => router.push('/Components/P/Announcements')}
      >
        Announcements
      </button>
      <button
        className="w-full py-3 bg-gradient-to-r from-yellow-600 to-orange-500 rounded-lg text-white font-medium"
        onClick={() => router.push('/Components/P/Complain')}
      >
        Complain
      </button>
    </div>

  </div>
)}

        </div>

        {/* Logout */}
        <div className="p-4 border-t border-white/20">
          <button
            className="w-full py-3 bg-gradient-to-r from-rose-600 to-pink-500 rounded-lg text-white font-medium"
            onClick={handleLogout}
          >
            Logout
          </button>
        </div>
      </nav>

      {/* Main Content */}
      <main className={`flex-grow p-8 transition-all duration-300 ${isMenuVisible ? "ml-64" : "ml-0"}`}>
        <div className="flex justify-between items-center mb-6">
          <button
            className="w-10 h-10 bg-white text-[#0F6466] rounded-full shadow-lg"
            onClick={() => setIsMenuVisible(v => !v)}
          >
            {isMenuVisible ? "✕" : "☰"}
          </button>
          <button
            className="py-3 px-6 bg-white text-[#0F6466] rounded-lg shadow hover:bg-gray-100"
            onClick={() => router.push("/Editprofile")}
          >
            Edit Profile
          </button>
        </div>

        {/* Profile */}
        <section className="mb-12 p-8 rounded-xl shadow-lg bg-white/90 backdrop-blur-sm border-2 border-white/20">
          <div className="flex flex-col md:flex-row items-center gap-8">
            {/* Avatar */}
            <div className="relative">
              <div className="absolute inset-0 bg-gradient-to-br from-current to-transparent rounded-full blur-2xl opacity-30 animate-pulse"></div>
              <img
                src={userData.profilePicture || "/default-avatar.png"}
                alt="Avatar"
                className="w-48 h-48 rounded-full border-4 border-white shadow-lg relative z-10"
              />
            </div>
            {/* Info */}
            <div className="flex-1">
              <h2 className="text-4xl font-bold text-gray-800 flex items-center">
                {userData.firstName} {userData.lastName}
                <span className="ml-4 px-3 py-1 text-sm bg-gray-200 rounded-full">
                  {userData.userType}
                </span>
              </h2>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mt-6">
                {/* Basic details */}
                <Card title="Contact" value={userData.contactNumber} />
                <Card title="Email"   value={userData.email} />

                {/* CNIC */}
                {userData.userType !== "Student" && (
                  <Card title="CNIC" value={userData.cnic!} />
                )}

                {/* Student extras */}
                {userData.userType === "Student" && (
                  <>
                    <Card title="Roll No"     value={userData.rollNo!} />
                    <Card title="Class Level" value={userData.classLevel!} />
                    <Card title="Class Type"  value={userData.classType!} />
                    <Card title="Class Name"  value={userData.className!} />
                  </>
                )}

                {/* Teacher department */}
                {userData.userType === "Teacher" && userData.department && (
                  <div className="md:col-span-2">
                    <Card
                      title="Department"
                      value={userData.department}
                    />
                  </div>
                )}

                {/* Parent children */}
                {userData.userType === "Parent" && userData.children?.length && (
                  <div className="md:col-span-2">
                    <p className="font-semibold text-gray-600 mb-2">Children</p>
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                      {userData.children.map((c,i) => (
                        <div key={c.id} className="p-3 bg-white rounded-lg border">
                          <p className="font-medium text-gray-700">Child {i+1}</p>
                          <p className="text-gray-800">{c.name}</p>
                          <p className="text-sm text-gray-500">Roll No: {c.rollNo}</p>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            </div>
          </div>
        </section>

        <h2 className="text-center text-4xl font-bold text-white mt-10 mb-8">
          Welcome to your {userData.userType} Portal
        </h2>
      </main>
    </div>
  );
}

// Helper card component
function Card({ title, value }: { title: string; value: string }) {
  return (
    <div className="p-4 bg-gray-50 rounded-xl shadow-sm border">
      <p className="font-semibold text-gray-600">{title}</p>
      <p className="text-gray-800">{value}</p>
    </div>
  );
}
