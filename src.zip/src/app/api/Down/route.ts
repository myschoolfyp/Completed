// app/api/Down/route.ts
import { NextResponse } from "next/server";
import mongoose from "mongoose";
import AssignmentModel, { IAssignment } from "@/models/Assignment";  // 🛠️ Correct model import

const connectDB = async () => {
  if (mongoose.connection.readyState === 0) {
    await mongoose.connect(process.env.MONGODB_URI!);
  }
};

export async function GET(req: Request) {
  await connectDB();

  const { searchParams } = new URL(req.url);
  const assignmentId = searchParams.get("assignmentId");

  if (!assignmentId) {
    return NextResponse.json({ error: "assignmentId is required" }, { status: 400 });
  }

  const assignment = await AssignmentModel
    .findById(assignmentId)
    .select("file.data file.contentType file.fileName")
    .lean() as IAssignment | null;  // 🛠️ TYPE IT HERE properly

  if (!assignment || !assignment.file?.data) {
    return NextResponse.json({ error: "File not found" }, { status: 404 });
  }

  const buffer = assignment.file.data as unknown as Buffer;

  return new Response(buffer, {
    status: 200,
    headers: {
      "Content-Type": assignment.file.contentType,
      "Content-Disposition": `attachment; filename="${assignment.file.fileName}"`,
    },
  });
}
