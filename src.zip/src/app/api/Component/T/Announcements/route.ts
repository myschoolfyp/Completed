// src/app/Component/T/Announcements/route.ts
import { NextResponse } from "next/server";
import { MongoClient, ObjectId } from "mongodb";

const MONGO_URI = "mongodb://localhost:27017";
const DB_NAME = "myschool";
const COLL_NAME = "announcements";

async function connectDb() {
  console.log("[API] 🔗 connecting to MongoDB at", MONGO_URI);
  const client = new MongoClient(MONGO_URI);
  await client.connect();
  console.log("[API] ✅ connected to DB", DB_NAME);
  return client.db(DB_NAME);
}

export async function GET(request: Request) {
  const url = new URL(request.url);
  const recipient = url.searchParams.get("recipient");
  console.log("[API][GET] incoming params:", { recipient });

  if (!recipient) {
    console.error("[API][GET] Missing recipient → 400");
    return NextResponse.json({ message: "recipient required" }, { status: 400 });
  }

  try {
    const db = await connectDb();
    const query = { stream: "teachers", recipients: recipient };
    console.log("[API][GET] find query:", query);

    const docs = await db
      .collection(COLL_NAME)
      .find(query)
      .sort({ date: -1 })
      .toArray();
    console.log("[API][GET] found", docs.length, "docs");

    // Deep-dive each doc's recipient list
    docs.forEach((d) => {
      console.log(
        "[API][GET] doc",
        d._id.toString(),
        "recipients:",
        d.recipients,
        "includes?",
        d.recipients.includes(recipient)
      );
    });

    const out = docs.map((d) => ({
      _id: d._id.toString(),
      description: d.description,
      date: (d.date as Date).toISOString(),
      replies: Array.isArray(d.replies)
        ? d.replies.map((r: any) => ({
            senderCnic: r.senderCnic,
            senderName: r.senderName,
            description: r.description,
            date: (r.date as Date).toISOString(),
          }))
        : [],
    }));
    console.log("[API][GET] returning payload:", out);
    return NextResponse.json(out);
  } catch (err) {
    console.error("[API][GET] error:", err);
    return NextResponse.json({ message: "Database error" }, { status: 500 });
  }
}

export async function POST(request: Request) {
  console.log("[API][POST] received new reply");
  try {
    const body = await request.json();
    console.log("[API][POST] body:", body);

    const { annId, senderCnic, senderName, description } = body as any;
    if (!annId || !senderCnic || !senderName || !description) {
      console.error("[API][POST] missing fields → 400");
      return NextResponse.json(
        { message: "annId, senderCnic, senderName & description required" },
        { status: 400 }
      );
    }

    const db = await connectDb();
    const reply = { senderCnic, senderName, description, date: new Date() };
    console.log("[API][POST] pushing reply to", annId, ":", reply);

    const result = await db
      .collection(COLL_NAME)
      .updateOne({ _id: new ObjectId(annId) }, { $push: { replies: reply } as any });
    console.log("[API][POST] update result:", result);

    if (result.modifiedCount === 0) {
      console.error("[API][POST] no document modified → 404");
      return NextResponse.json({ message: "Announcement not found" }, { status: 404 });
    }

    const resp = { ...reply, date: reply.date.toISOString() };
    console.log("[API][POST] responding with:", resp);
    return NextResponse.json(resp, { status: 201 });
  } catch (err) {
    console.error("[API][POST] server error:", err);
    return NextResponse.json({ message: "Server error" }, { status: 500 });
  }
}
