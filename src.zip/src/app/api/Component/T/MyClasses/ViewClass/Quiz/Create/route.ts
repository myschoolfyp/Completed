// src/app/api/Component/T/MyClasses/ViewClass/Quiz/Create/route.ts
import { NextResponse } from "next/server";
import mongoose from "mongoose";
import QuizModel from "@/models/Quiz";
import TeacherModel from "@/models/Teacher";

const MONGODB_URI = process.env.MONGODB_URI!;
if (!MONGODB_URI) throw new Error("MONGODB_URI is not defined");
async function connectDB() {
  if (mongoose.connection.readyState === 0) {
    await mongoose.connect(MONGODB_URI);
  }
}

export async function POST(req: Request) {
  await connectDB();
  const form = await req.formData();

  // Required fields
  const quizTitle     = form.get("quizTitle")?.toString() || "";
  const description   = form.get("description")?.toString() || "";
  const className     = form.get("className")?.toString() || "";
  const course        = form.get("course")?.toString() || "";
  const totalMarks    = Number(form.get("totalMarks")?.toString()) || 0;
  const deadlineStr   = form.get("deadline")?.toString() || "";
  const teacherId     = form.get("teacherId")?.toString() || "";
  const key           = form.get("key")?.toString() || "";
  const mode          = form.get("mode")?.toString();
  const questionCount = Number(form.get("questionCount")?.toString()) || 0;
  const timeLimit     = Number(form.get("timeLimit")?.toString()) || 0;
  const shortNote     = form.get("shortNote")?.toString() || "";

  // Parse correctAnswers JSON
  let rawAnswers: any;
  try {
    rawAnswers = JSON.parse(form.get("correctAnswers")?.toString() || "[]");
  } catch {
    return NextResponse.json({ error: "Invalid correctAnswers JSON" }, { status: 400 });
  }
  const correctAnswers = rawAnswers.map((item: any) => ({
    question: Number(item.question),
    answer: String(item.answer),
  }));

  // Validations
  if (!quizTitle) {
    return NextResponse.json({ error: "quizTitle is required" }, { status: 400 });
  }
  if (!mongoose.Types.ObjectId.isValid(teacherId)) {
    return NextResponse.json({ error: "Invalid teacherId" }, { status: 400 });
  }
  if (mode !== "online") {
    return NextResponse.json({ error: "Only online mode supported" }, { status: 400 });
  }
  if (questionCount < 1 || questionCount > 50) {
    return NextResponse.json({ error: "questionCount must be 1–50" }, { status: 400 });
  }
  if (timeLimit < 1) {
    return NextResponse.json({ error: "timeLimit must be at least 1" }, { status: 400 });
  }
  if (
    !Array.isArray(correctAnswers) ||
    correctAnswers.length !== questionCount
  ) {
    return NextResponse.json(
      { error: "correctAnswers length mismatch" },
      { status: 400 }
    );
  }
  for (const ca of correctAnswers) {
    if (
      typeof ca.question !== "number" ||
      ca.question < 1 ||
      ca.question > questionCount ||
      !["A", "B", "C", "D", "E"].includes(ca.answer)
    ) {
      return NextResponse.json(
        { error: "Invalid correctAnswers format" },
        { status: 400 }
      );
    }
  }

  // Verify teacher exists
  const teacher = await TeacherModel.findById(teacherId);
  if (!teacher) {
    return NextResponse.json({ error: "Teacher not found" }, { status: 404 });
  }

  // Build quiz document
  const doc: any = {
    quizTitle,
    description,
    className,
    course,
    totalMarks,
    deadline: new Date(deadlineStr),
    key,
    mode: "online",
    questionCount,
    timeLimit,
    shortNote,
    correctAnswers,
    teacherId: teacher._id,
    teacherFirstName: teacher.firstName,
    teacherLastName: teacher.lastName,
    submissions: [],
  };

  await QuizModel.create(doc);
  return NextResponse.json({ message: "Quiz created!" }, { status: 201 });
}
