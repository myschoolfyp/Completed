// app/api/Component/T/MyClasses/ViewClass/Results/route.ts

import { NextResponse } from "next/server";
import mongoose from "mongoose";
import ResultModel from "@/models/Result";

const connectDB = async () => {
  if (mongoose.connection.readyState === 0) {
    await mongoose.connect(process.env.MONGODB_URI!);
  }
};

export async function POST(req: Request) {
  try {
    console.log("🏷️  /Results POST invoked"); 
    await connectDB();
    const body = await req.json();
    console.log("📥 payload:", body);

    const {
      datesheetId,
      datesheetName,
      className,
      course,
      totalMarks,
      studentResults,
    } = body;

    // basic validation
    if (
      !datesheetId || !datesheetName ||
      !className || !course ||
      typeof totalMarks !== "number" ||
      !Array.isArray(studentResults) ||
      studentResults.length === 0
    ) {
      return NextResponse.json(
        { error: "Missing fields or no students" },
        { status: 400 }
      );
    }

    // remove any old result for this triplet
    await ResultModel.deleteMany({ datesheetId, className, course });


    const doc = new ResultModel({
      datesheetId,
      datesheetName,
      className,
      course,
      totalMarks,
      studentResults,
    });
    await doc.save();
    return NextResponse.json(doc.toJSON(), { status: 201 });
    console.log("✅ Saved result document:", doc.toJSON());

    return NextResponse.json(
      { success: true, id: doc._id },
      { status: 201 }
    );
  } catch (err: any) {
    console.error("Result POST error:", err);
    return NextResponse.json(
      { error: err.message || "Server error" },
      { status: 500 }
    );
  }
}
