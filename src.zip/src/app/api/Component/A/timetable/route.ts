import { NextResponse } from "next/server";
import mongoose from "mongoose";
import TimetableModel from "@/models/Timetable";

const connectDB = async () => {
  if (mongoose.connection.readyState === 0) {
    await mongoose.connect(process.env.MONGODB_URI!);
  }
};

export async function GET(request: Request) {
  try {
    await connectDB();

    const { searchParams } = new URL(request.url);
    const className = searchParams.get("className");

    if (className) {
      const timetable = await TimetableModel.findOne({ className })
        .select("-createdAt -__v")
        .lean();

      if (!timetable) {
        return NextResponse.json(
          { error: "Timetable not found" },
          { status: 404 }
        );
      }
      return NextResponse.json(timetable);
    }

    const classNames = await TimetableModel.distinct("className");
    return NextResponse.json({ classNames });

  } catch (error) {
    console.error("Error:", error);
    return NextResponse.json(
      { error: "Internal Server Error" },
      { status: 500 }
    );
  }
}

export async function DELETE(request: Request) {
  try {
    await connectDB();

    const { searchParams } = new URL(request.url);
    const id = searchParams.get("id");

    if (!id) {
      return NextResponse.json({ error: "Missing timetable ID" }, { status: 400 });
    }

    const deleted = await TimetableModel.findByIdAndDelete(id);

    if (!deleted) {
      return NextResponse.json({ error: "Timetable not found" }, { status: 404 });
    }

    return NextResponse.json({ message: "Timetable deleted successfully" });

  } catch (error) {
    console.error("Delete error:", error);
    return NextResponse.json({ error: "Server error" }, { status: 500 });
  }
}
