import { NextResponse } from "next/server";
import mongoose from "mongoose";
import connectDB from "@/lib/mongodb";
import DatesheetModel from "@/models/Datesheet";

const ensureDB = async () => {
  if (mongoose.connection.readyState === 0) {
    await connectDB();
  }
};

export async function GET(request: Request) {
  await ensureDB();
  const { searchParams } = new URL(request.url);
  const id = searchParams.get("datesheetId");
  if (id) {
    const ds = await DatesheetModel.findById(id).lean();
    if (!ds) return NextResponse.json({ error: "Not found" }, { status: 404 });
    return NextResponse.json(ds);
  }
  const all = await DatesheetModel.find()
    .select("datesheetName className classLevel schedule createdAt")
    .sort({ createdAt: -1 })
    .lean();
  return NextResponse.json(all);
}

export async function PUT(request: Request) {
  await ensureDB();
  const { datesheetId, datesheetName, schedule } = await request.json();
  if (!datesheetId || !datesheetName || !Array.isArray(schedule)) {
    return NextResponse.json({ error: "Missing required fields" }, { status: 400 });
  }
  const processed = schedule.map((e: any) => ({ ...e, date: new Date(e.date) }));
  const updated = await DatesheetModel.findByIdAndUpdate(
    datesheetId,
    { $set: { datesheetName, schedule: processed } },
    { new: true, runValidators: true }
  );
  if (!updated) return NextResponse.json({ error: "Update failed" }, { status: 500 });
  return NextResponse.json({ success: true, message: "Updated!" });
}

export async function DELETE(request: Request) {
  await ensureDB();
  const { datesheetId } = await request.json();
  if (!datesheetId) {
    return NextResponse.json({ error: "Missing datesheetId" }, { status: 400 });
  }
  const del = await DatesheetModel.findByIdAndDelete(datesheetId);
  if (!del) return NextResponse.json({ error: "Delete failed" }, { status: 500 });
  // return a JSON so client can parse
  return NextResponse.json({ success: true, message: "Deleted" });
}
