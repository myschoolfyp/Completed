import { NextResponse } from "next/server";
import { MongoClient, ObjectId } from "mongodb";

const mongoUri = "mongodb://localhost:27017/myschool";

export async function GET(request: Request) {
  let client: MongoClient | null = null;
  try {
    client = new MongoClient(mongoUri);
    await client.connect();
    const db = client.db();

    const url = new URL(request.url);
    const cnicParam = url.searchParams.get("cnic");
    if (cnicParam) {
      const p = await db.collection("parents").findOne(
        { cnic: cnicParam },
        { projection: { password: 0 } }
      );
      if (!p) {
        return NextResponse.json({ message: "Parent not found", error: true }, { status: 404 });
      }
      // Ensure students array is returned
      const serialized = { ...p, _id: p._id.toString(), students: p.students || [] };
      return NextResponse.json(serialized, { status: 200 });
    }

    const all = await db.collection("parents").find({}, { projection: { password: 0 } }).toArray();
    const serializedAll = all.map(p => ({
      ...p,
      _id: p._id.toString(),
      students: p.students || []
    }));
    return NextResponse.json(serializedAll, { status: 200 });
  } catch (err: any) {
    console.error("GET /Parents error:", err);
    return NextResponse.json({ message: "Internal server error", error: true }, { status: 500 });
  } finally {
    client?.close();
  }
}

export async function POST(request: Request) {
  let client: MongoClient | null = null;
  try {
    const { cnic, firstName, lastName, email, password, contactNumber } = await request.json();
    if (!cnic || !firstName || !lastName || !email || !password || !contactNumber) {
      return NextResponse.json({ message: "All fields are required", error: true }, { status: 400 });
    }
    if (!/^\d{13}$/.test(cnic)) {
      return NextResponse.json({ message: "CNIC must be 13 digits", error: true }, { status: 400 });
    }
    client = new MongoClient(mongoUri);
    await client.connect();
    const db = client.db();

    if (await db.collection("parents").findOne({ cnic })) {
      return NextResponse.json({ message: "CNIC exists", error: true }, { status: 409 });
    }

    await db.collection("parents").insertOne({
      cnic, firstName, lastName, email, password, contactNumber, students: []
    });
    return NextResponse.json({ message: "Parent added", error: false }, { status: 201 });
  } catch (err) {
    console.error("POST /Parents error:", err);
    return NextResponse.json({ message: "Internal server error", error: true }, { status: 500 });
  } finally {
    client?.close();
  }
}

export async function DELETE(request: Request) {
  let client: MongoClient | null = null;
  try {
    const { id } = await request.json();
    if (!id) {
      return NextResponse.json({ message: "Parent ID required", error: true }, { status: 400 });
    }
    client = new MongoClient(mongoUri);
    await client.connect();
    const result = await client.db().collection("parents").deleteOne({ _id: new ObjectId(id) });
    if (result.deletedCount === 0) {
      return NextResponse.json({ message: "Parent not found", error: true }, { status: 404 });
    }
    return NextResponse.json({ message: "Parent deleted", error: false }, { status: 200 });
  } catch (err) {
    console.error("DELETE /Parents error:", err);
    return NextResponse.json({ message: "Internal server error", error: true }, { status: 500 });
  } finally {
    client?.close();
  }
}

export async function PUT(request: Request) {
  let client: MongoClient | null = null;
  try {
    const body = await request.json();

    client = new MongoClient(mongoUri);
    await client.connect();
    const db = client.db();

    // Assignment flow:
    if (Array.isArray(body.parentIds) && Array.isArray(body.studentIds)) {
      const { parentIds, studentIds } = body as { parentIds: string[]; studentIds: string[] };
      const studs = await db
        .collection("students")
        .find({ _id: { $in: studentIds.map(id => new ObjectId(id)) } })
        .toArray();
      const studentDetails = studs.map(s => ({
        _id: s._id,
        rollNo: s.rollNo,
        firstName: s.firstName,
        lastName: s.lastName,
        classLevel: s.classLevel,
        classType: s.classType
      }));
      await Promise.all(
        parentIds.map(pid =>
          db.collection("parents").updateOne(
            { _id: new ObjectId(pid) },
            { $addToSet: { students: { $each: studentDetails } } }
          )
        )
      );
      return NextResponse.json({ message: "Assigned", error: false }, { status: 200 });
    }

    // Update parent flow:
    const { id, firstName, lastName, contactNumber, password } = body as any;
    if (!id || !firstName || !lastName || !contactNumber) {
      return NextResponse.json({ message: "Missing fields", error: true }, { status: 400 });
    }
    const updateObj: any = { firstName, lastName, contactNumber };
    if (password) updateObj.password = password;
    const result = await db
      .collection("parents")
      .updateOne({ _id: new ObjectId(id) }, { $set: updateObj });
    if (result.matchedCount === 0) {
      return NextResponse.json({ message: "Parent not found", error: true }, { status: 404 });
    }
    return NextResponse.json({ message: "Parent updated", error: false }, { status: 200 });

  } catch (err) {
    console.error("PUT /Parents error:", err);
    return NextResponse.json({ message: "Internal server error", error: true }, { status: 500 });
  } finally {
    client?.close();
  }
}
