// /api/Component/A/Teachers/route.ts

import { NextResponse } from "next/server";
import { MongoClient, ObjectId } from "mongodb";
import bcrypt from "bcryptjs";

const mongoUri = "mongodb://localhost:27017/myschool";

export async function GET(request: Request) {
  let client: MongoClient | null = null;
  try {
    client = new MongoClient(mongoUri);
    await client.connect();
    const db = client.db();

    const url = new URL(request.url);
    const cnicParam = url.searchParams.get("cnic");
    if (cnicParam) {
      const teacher = await db
        .collection("teachers")
        .findOne(
          { cnic: cnicParam },
          { projection: { password: 0, profilePicture: 0 } }
        );
      if (!teacher) {
        return NextResponse.json(
          { message: "Teacher not found", error: true },
          { status: 404 }
        );
      }
      return NextResponse.json(
        { ...teacher, _id: teacher._id.toString() },
        { status: 200 }
      );
    }

    const all = await db
      .collection("teachers")
      .find({}, { projection: { password: 0, profilePicture: 0 } })
      .toArray();
    const serialized = all.map(t => ({ ...t, _id: t._id.toString() }));
    return NextResponse.json(serialized, { status: 200 });
  } catch (err: any) {
    console.error("GET /Teachers error:", err);
    return NextResponse.json(
      { message: "Internal server error", error: true },
      { status: 500 }
    );
  } finally {
    client?.close();
  }
}

export async function POST(request: Request) {
  let client: MongoClient | null = null;
  try {
    const { firstName, lastName, email, password, cnic, contactNumber, department } =
      await request.json();

    // Validate required fields
    if (
      !firstName || !lastName ||
      !email || !password ||
      !cnic || !contactNumber || !department
    ) {
      return NextResponse.json(
        { message: "All fields are required", error: true },
        { status: 400 }
      );
    }
    if (!/^[A-Za-z]+$/.test(firstName) || !/^[A-Za-z]+$/.test(lastName)) {
      return NextResponse.json(
        { message: "Names must contain letters only", error: true },
        { status: 400 }
      );
    }
    if (!/^\d{13}$/.test(cnic)) {
      return NextResponse.json(
        { message: "CNIC must be 13 digits", error: true },
        { status: 400 }
      );
    }
    if (!email.includes("@")) {
      return NextResponse.json(
        { message: "Email must include @", error: true },
        { status: 400 }
      );
    }

    client = new MongoClient(mongoUri);
    await client.connect();
    const db = client.db();

    // Duplicate CNIC check
    if (await db.collection("teachers").findOne({ cnic })) {
      return NextResponse.json(
        { message: "CNIC already exists", error: true },
        { status: 409 }
      );
    }

    // *** HASH PASSWORD ***
    const hashedPwd = await bcrypt.hash(password, 10);

    const result = await db.collection("teachers").insertOne({
      firstName,
      lastName,
      email,
      password: hashedPwd,
      cnic,
      contactNumber,
      department
    });

    return NextResponse.json(
      { message: "Teacher added", id: result.insertedId.toString(), error: false },
      { status: 201 }
    );
  } catch (err) {
    console.error("POST /Teachers error:", err);
    return NextResponse.json(
      { message: "Internal server error", error: true },
      { status: 500 }
    );
  } finally {
    client?.close();
  }
}

export async function DELETE(request: Request) {
  let client: MongoClient | null = null;
  try {
    const { id } = await request.json();
    if (!id) {
      return NextResponse.json(
        { message: "Teacher ID is required", error: true },
        { status: 400 }
      );
    }

    client = new MongoClient(mongoUri);
    await client.connect();
    const result = await client
      .db()
      .collection("teachers")
      .deleteOne({ _id: new ObjectId(id) });

    if (result.deletedCount === 0) {
      return NextResponse.json(
        { message: "Teacher not found", error: true },
        { status: 404 }
      );
    }

    return NextResponse.json(
      { message: "Teacher deleted", error: false },
      { status: 200 }
    );
  } catch (err) {
    console.error("DELETE /Teachers error:", err);
    return NextResponse.json(
      { message: "Internal server error", error: true },
      { status: 500 }
    );
  } finally {
    client?.close();
  }
}

export async function PUT(request: Request) {
  let client: MongoClient | null = null;
  try {
    const { id, firstName, lastName, department, contactNumber, password } =
      await request.json();

    // Validate required update fields
    if (!id || !firstName || !lastName || !department || !contactNumber) {
      return NextResponse.json(
        { message: "Missing required fields", error: true },
        { status: 400 }
      );
    }

    client = new MongoClient(mongoUri);
    await client.connect();
    const db = client.db();

    // Build update object
    const updateObj: any = { firstName, lastName, department, contactNumber };

    // *** HASH NEW PASSWORD IF PROVIDED ***
    if (password) {
      updateObj.password = await bcrypt.hash(password, 10);
    }

    const result = await db
      .collection("teachers")
      .updateOne({ _id: new ObjectId(id) }, { $set: updateObj });

    if (result.matchedCount === 0) {
      return NextResponse.json(
        { message: "Teacher not found", error: true },
        { status: 404 }
      );
    }

    return NextResponse.json(
      { message: "Teacher updated", error: false },
      { status: 200 }
    );
  } catch (err) {
    console.error("PUT /Teachers error:", err);
    return NextResponse.json(
      { message: "Internal server error", error: true },
      { status: 500 }
    );
  } finally {
    client?.close();
  }
}
