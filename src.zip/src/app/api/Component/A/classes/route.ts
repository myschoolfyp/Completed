import { NextResponse } from "next/server";
import { MongoClient, ObjectId } from "mongodb";

const mongoUri = "mongodb://localhost:27017/myschool";

async function connect() {
  const client = new MongoClient(mongoUri);
  await client.connect();
  return client.db();
}

export async function GET() {
  try {
    const db = await connect();
    const classes = await db.collection("classes").find().toArray();
    return NextResponse.json(classes);
  } catch (error: any) {
    return NextResponse.json(
      { message: "Server error: " + error.message },
      { status: 500 }
    );
  }
}

export async function POST(request: Request) {
  try {
    const db = await connect();
    const data = await request.json();

    // Validate class name (letters + spaces, max 15 chars)
    if (!/^[A-Za-z\s]{1,15}$/.test(data.className)) {
      return NextResponse.json(
        { message: "Class name must be letters only (max 15 chars)" },
        { status: 400 }
      );
    }
    // Prevent duplicates
    const exists = await db.collection("classes").findOne({ className: data.className });
    if (exists) {
      return NextResponse.json(
        { message: "Class name already exists" },
        { status: 400 }
      );
    }

    // Stream logic
    if (["Class 9", "Class 10"].includes(data.classLevel)) {
      if (!["Arts","Science","Computer"].includes(data.stream)) {
        return NextResponse.json(
          { message: "Invalid stream for class 9 or 10" },
          { status: 400 }
        );
      }
    } else {
      data.stream = "General";
    }

    const result = await db.collection("classes").insertOne({
      classLevel: data.classLevel,
      className:  data.className,
      stream:     data.stream,
      students:   data.students || [],
      courses:    data.courses  || [],
    });
    return NextResponse.json(result);
  } catch (error: any) {
    return NextResponse.json(
      { message: "Server error: " + error.message },
      { status: 500 }
    );
  }
}

export async function DELETE(request: Request) {
  try {
    const db = await connect();
    const { id } = await request.json();
    if (!id) {
      return NextResponse.json({ message: "Missing class ID" }, { status: 400 });
    }
    await db.collection("classes").deleteOne({ _id: new ObjectId(id) });
    return NextResponse.json({ message: "Deleted" });
  } catch (error: any) {
    return NextResponse.json(
      { message: "Server error: " + error.message },
      { status: 500 }
    );
  }
}
