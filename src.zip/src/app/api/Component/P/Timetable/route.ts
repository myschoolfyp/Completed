// app/api/Component/P/Timetable/route.ts

import { NextResponse } from "next/server";

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url);
    const cnic = searchParams.get("cnic");
    if (!cnic) {
      return NextResponse.json(
        { error: "cnic query parameter is required" },
        { status: 400 }
      );
    }

    // derive origin to call our own APIs
    const url = new URL(request.url);
    const origin = url.origin;

    // 1) fetch the list of children
    const childrenRes = await fetch(
      `${origin}/api/Component/P/Children?cnic=${encodeURIComponent(cnic)}`
    );
    if (!childrenRes.ok) {
      const err = await childrenRes.json();
      return NextResponse.json(
        { error: err.error || "Failed to fetch children" },
        { status: childrenRes.status }
      );
    }
    const { parentName, students } = await childrenRes.json();

    // 2) for each child, fetch their timetable
    const childrenTimetables = await Promise.all(
      students.map(async (stu: any) => {
        const ttRes = await fetch(
          `${origin}/api/Component/S/Timetable?className=${encodeURIComponent(
            stu.className
          )}`
        );
        if (!ttRes.ok) {
          // if one timetable fails, skip it but still return others
          return { ...stu, timetable: [], error: "Not found" };
        }
        const { days } = await ttRes.json();
        return { ...stu, timetable: days };
      })
    );

    return NextResponse.json({
      parentName,
      children: childrenTimetables,
    });
  } catch (error: any) {
    console.error("P/Timetable Error:", error);
    return NextResponse.json(
      { error: "Internal Server Error" },
      { status: 500 }
    );
  }
}
