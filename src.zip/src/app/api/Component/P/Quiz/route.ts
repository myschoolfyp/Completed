// app/api/Component/P/Quiz/route.ts
import { NextResponse } from "next/server";

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url);
    const cnic = searchParams.get("cnic");
    if (!cnic) {
      return NextResponse.json(
        { error: "cnic query parameter is required" },
        { status: 400 }
      );
    }
    const origin = new URL(request.url).origin;

    // 1) fetch children
    const childrenRes = await fetch(
      `${origin}/api/Component/P/Children?cnic=${encodeURIComponent(cnic)}`
    );
    if (!childrenRes.ok) {
      const err = await childrenRes.json();
      return NextResponse.json(
        { error: err.error || "Failed to fetch children" },
        { status: childrenRes.status }
      );
    }
    const { parentName, students } = await childrenRes.json();

    // 2) fetch courses per child
    const coursesRes = await fetch(
      `${origin}/api/Component/P/Courses?cnic=${encodeURIComponent(cnic)}`
    );
    if (!coursesRes.ok) {
      const err = await coursesRes.json();
      return NextResponse.json(
        { error: err.error || "Failed to fetch courses" },
        { status: coursesRes.status }
      );
    }
    const { children: courseData } = await coursesRes.json();
    const courseMap = new Map<string, string[]>();
    courseData.forEach((c: any) => {
      courseMap.set(c._id, c.courses);
    });

    // 3) for each child × each course, fetch quizzes + status
    const childrenQuiz = await Promise.all(
      students.map(async (stu: any) => {
        const stuCourses = courseMap.get(stu._id) || [];
        const quizzesByCourse: Record<string, any[]> = {};

        await Promise.all(
          stuCourses.map(async (course: string) => {
            const qRes = await fetch(
              `${origin}/api/Component/S/Quiz?` +
              `className=${encodeURIComponent(stu.className)}` +
              `&course=${encodeURIComponent(course)}` +
              `&rollNo=${encodeURIComponent(stu.rollNo)}`
            );
            if (qRes.ok) {
              const body = await qRes.json();
              quizzesByCourse[course] = body.quizzes;
            } else {
              quizzesByCourse[course] = [];
            }
          })
        );

        return {
          _id: stu._id,
          firstName: stu.firstName,
          lastName: stu.lastName,
          className: stu.className,
          rollNo: stu.rollNo,
          courses: stuCourses,
          quizzesByCourse,
        };
      })
    );

    return NextResponse.json({
      parentName,
      children: childrenQuiz,
    });
  } catch (error: any) {
    console.error("P/Quiz Error:", error);
    return NextResponse.json(
      { error: "Internal Server Error" },
      { status: 500 }
    );
  }
}
