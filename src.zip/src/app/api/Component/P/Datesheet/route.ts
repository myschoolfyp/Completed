// app/api/Component/P/Datesheet/route.ts

import { NextResponse } from "next/server";

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url);
    const cnic = searchParams.get("cnic");
    if (!cnic) {
      return NextResponse.json(
        { error: "cnic query parameter is required" },
        { status: 400 }
      );
    }

    const origin = new URL(request.url).origin;

    // 1) fetch children list
    const kidsRes = await fetch(
      `${origin}/api/Component/P/Children?cnic=${encodeURIComponent(cnic)}`
    );
    if (!kidsRes.ok) {
      const e = await kidsRes.json();
      return NextResponse.json(
        { error: e.message || "Failed to fetch children" },
        { status: kidsRes.status }
      );
    }
    const { parentName, students } = await kidsRes.json();

    // 2) for each child, fetch their datesheets
    const childrenWithDatesheets = await Promise.all(
      students.map(async (stu: any) => {
        const dsRes = await fetch(
          `${origin}/api/Component/S/Datesheets?className=${encodeURIComponent(
            stu.className
          )}`
        );
        let datesheets = [];
        if (dsRes.ok) {
          datesheets = await dsRes.json();
        }
        return {
          _id: stu._id,
          firstName: stu.firstName,
          lastName: stu.lastName,
          className: stu.className,
          datesheets,
        };
      })
    );

    return NextResponse.json({
      parentName,
      children: childrenWithDatesheets,
    });
  } catch (err: any) {
    console.error("P/Datesheet Error:", err);
    return NextResponse.json(
      { error: "Internal Server Error" },
      { status: 500 }
    );
  }
}
