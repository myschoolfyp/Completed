// src/app/Component/P/Complain/route.ts
import { NextResponse } from "next/server";
import mongoose, { Types } from "mongoose";
import Complain from "@/models/Complain";

const MONGO_URI = "mongodb://localhost:27017";
const DB_NAME = "myschool";

async function connectDb() {
  if (mongoose.connection.readyState < 1) {
    await mongoose.connect(MONGO_URI, { dbName: DB_NAME });
  }
}

export async function GET(request: Request) {
  const cnic = new URL(request.url).searchParams.get("cnic");
  if (!cnic) {
    return NextResponse.json({ message: "cnic required" }, { status: 400 });
  }
  await connectDb();
  const comps = await Complain.find({ parentCnic: cnic })
    .sort({ createdAt: -1 })
    .lean();

  const out = comps.map((c) => ({
    _id: c._id.toString(),
    teacherName: c.teacherName,
    parentName: c.parentName,
    className: c.className,
    studentName: c.studentName,
    rollNo: c.rollNo,
    description: c.description,
    date: c.createdAt.toISOString(),
    replies: (c.parentReplies || []).map((r) => ({
      senderCnic: r.senderCnic,
      senderName: r.senderName,
      description: r.description,
      date: r.date.toISOString(),
    })),
  }));

  return NextResponse.json(out);
}

export async function POST(request: Request) {
  const { complaintId, senderCnic, senderName, description } =
    await request.json();
  if (!complaintId || !senderCnic || !senderName || !description) {
    return NextResponse.json(
      {
        message:
          "complaintId, senderCnic, senderName & description required",
      },
      { status: 400 }
    );
  }
  await connectDb();
  const reply = {
    senderCnic,
    senderName,
    description,
    date: new Date(),
  };
  const res = await Complain.updateOne(
    {
      _id: new Types.ObjectId(complaintId),
      parentCnic: senderCnic,
    },
    { $push: { parentReplies: reply } }
  );
  if (res.matchedCount === 0) {
    return NextResponse.json(
      { message: "Complaint not found or not yours" },
      { status: 404 }
    );
  }
  return NextResponse.json(
    { ...reply, date: reply.date.toISOString() },
    { status: 201 }
  );
}
