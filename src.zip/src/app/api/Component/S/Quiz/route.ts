// src/app/api/Component/S/Quiz/route.ts

import { NextResponse } from "next/server";
import mongoose from "mongoose";
import QuizModel from "@/models/Quiz";

// define the shape of what .lean() will return
interface LeanQuiz {
  _id: mongoose.Types.ObjectId;
  quizTitle: string;
  description?: string;
  totalMarks: number;
  questionCount?: number;
  mode: "offline" | "online";
  deadline: Date;
  quizFile?: { fileName: string };
  submissions?: { rollNo: string }[];
}

const connectDB = async () => {
  if (mongoose.connection.readyState === 0) {
    await mongoose.connect(process.env.MONGODB_URI!);
  }
};

export async function GET(req: Request) {
  await connectDB();
  const { searchParams } = new URL(req.url);

  const rawClass = searchParams.get("className")?.trim()  || "";
  const rawCourse = searchParams.get("course")?.trim()   || "";
  const rollNo = searchParams.get("rollNo")?.trim()      || "";

  if (!rawClass || !rawCourse || !rollNo) {
    return NextResponse.json(
      { error: "className, course & rollNo are required" },
      { status: 400 }
    );
  }

  // match course ignoring trailing spaces in DB
  const coursePattern = new RegExp(`^\\s*${rawCourse}\\s*$`, "i");

  // fetch only the fields we need + submissions.rollNo
  const rawQuizzes = await QuizModel.find({
    className: rawClass,
    course: coursePattern,
  })
    .select([
      "quizTitle",
      "description",
      "totalMarks",
      "questionCount",
      "mode",
      "deadline",
      "quizFile.fileName",
      "submissions.rollNo",
    ])
    .lean<LeanQuiz[]>();

  // annotate each quiz with `submitted` for this student
  const quizzes = rawQuizzes.map((q) => ({
    _id:           q._id.toString(),
    quizTitle:     q.quizTitle,
    description:   q.description,
    totalMarks:    q.totalMarks,
    questionCount: q.questionCount,
    mode:          q.mode,
    deadline:      q.deadline,
    quizFile:      q.quizFile,
    submitted:     (q.submissions ?? []).some(
                     (s: { rollNo: string }) => s.rollNo === rollNo
                   ),
  }));

  return NextResponse.json({ quizzes });
}
