// src/app/Component/S/Announcements/route.ts
import { NextResponse } from "next/server";
import { MongoClient, ObjectId } from "mongodb";

const MONGO_URI = "mongodb://localhost:27017";
const DB_NAME = "myschool";
const COLL_NAME = "announcements";

async function connectDb() {
  const client = new MongoClient(MONGO_URI);
  await client.connect();
  return client.db(DB_NAME);
}

export async function GET(request: Request) {
  const url = new URL(request.url);
  const stream = url.searchParams.get("stream");
  const recipient = url.searchParams.get("recipient");

  if (stream !== "students" || !recipient) {
    return NextResponse.json(
      { message: "stream=students & recipient required" },
      { status: 400 }
    );
  }

  const db = await connectDb();
  const docs = await db
    .collection(COLL_NAME)
    .find({ stream: "students", recipients: recipient })
    .sort({ date: -1 })
    .toArray();

  const out = docs.map((d) => ({
    _id: d._id.toString(),
    description: d.description,
    date: (d.date as Date).toISOString(),
    replies: Array.isArray(d.replies)
      ? d.replies.map((r: any) => ({
          senderRollNo: r.senderRollNo,
          senderName: r.senderName,
          description: r.description,
          date: (r.date as Date).toISOString(),
        }))
      : [],
  }));

  return NextResponse.json(out);
}

export async function POST(request: Request) {
  const body = (await request.json()) as {
    annId?: string;
    senderRollNo?: string;
    senderName?: string;
    description?: string;
  };

  if (
    !body.annId ||
    !body.senderRollNo ||
    !body.senderName ||
    !body.description
  ) {
    return NextResponse.json(
      { message: "annId, senderRollNo, senderName & description required" },
      { status: 400 }
    );
  }

  const db = await connectDb();
  const reply = {
    senderRollNo: body.senderRollNo,
    senderName: body.senderName,
    description: body.description,
    date: new Date(),
  };

  const result = await db.collection(COLL_NAME).updateOne(
    { _id: new ObjectId(body.annId) },
    { $push: { replies: reply } as any }
  );
  if (result.modifiedCount === 0) {
    return NextResponse.json({ message: "Announcement not found" }, { status: 404 });
  }

  return NextResponse.json(
    { ...reply, date: reply.date.toISOString() },
    { status: 201 }
  );
}
