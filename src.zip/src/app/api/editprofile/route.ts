import { NextResponse } from "next/server";
import dbConnect from "@/lib/mongodb";
import bcrypt from "bcryptjs";

import Admin from "@/models/Admin";
import Teacher from "@/models/Teacher";
import Parent from "@/models/Parent";
import Student from "@/models/Student";

type Models = {
  Admin: typeof Admin;
  Teacher: typeof Teacher;
  Parent: typeof Parent;
  Student: typeof Student;
};

const models: Models = { Admin, Teacher, Parent, Student };

async function authenticate(
  userType: keyof Models,
  identifier: string,
  password: string
) {
  const Model = models[userType];
  let query: any = {};
  if (userType === "Student") query.rollNo = identifier;
  else query.cnic = identifier;

  const user = await Model.findOne(query).lean();
  if (!user) return null;
  const match = await bcrypt.compare(password, (user as any).password);
  if (!match) return null;
  return user;
}

export async function POST(req: Request) {
  // → verify credentials and return user data
  try {
    await dbConnect();
    const { userType, identifier, password } = await req.json();
    if (!userType || !identifier || !password) {
      return NextResponse.json({ error: "Missing fields" }, { status: 400 });
    }
    const user = await authenticate(userType, identifier, password);
    if (!user) {
      return NextResponse.json({ error: "Invalid credentials" }, { status: 401 });
    }
    // strip sensitive
    const { password: _, ...safe } = user as any;
    return NextResponse.json({ user: safe });
  } catch (err: any) {
    console.error("EditProfile POST error:", err);
    return NextResponse.json({ error: "Server error" }, { status: 500 });
  }
}

export async function PUT(req: Request) {
  // → verify, then apply updates
  try {
    await dbConnect();
    const { userType, identifier, password, updates } = await req.json();
    if (!userType || !identifier || !password || !updates) {
      return NextResponse.json({ error: "Missing fields" }, { status: 400 });
    }
    const Model = models[userType as keyof Models];
    // re-authenticate
    const user = await authenticate(userType, identifier, password);
    if (!user) {
      return NextResponse.json({ error: "Invalid credentials" }, { status: 401 });
    }

    // build update object, only allowed keys
    const allowed = ["firstName","lastName","email","contactNumber","profilePicture","password"];
    const setObj: any = {};
    for (const k of allowed) {
      if (k in updates) {
        if (k === "password") {
          setObj.password = await bcrypt.hash(updates.password, 10);
        } else {
          setObj[k] = updates[k];
        }
      }
    }
    // identifier and other locked fields are not updatable

    const query: any = {};
    if (userType === "Student") query.rollNo = identifier;
    else query.cnic = identifier;

    const updated = await Model.findOneAndUpdate(query, setObj, { new: true }).lean();
    if (!updated) {
      return NextResponse.json({ error: "User not found" }, { status: 404 });
    }
    return NextResponse.json({ success: true });
  } catch (err: any) {
    console.error("EditProfile PUT error:", err);
    return NextResponse.json({ error: "Server error" }, { status: 500 });
  }
}
