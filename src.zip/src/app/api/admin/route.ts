// /api/Component/A/Admins/route.ts

import { NextResponse } from "next/server";
import { MongoClient, ObjectId } from "mongodb";
import bcrypt from "bcryptjs";

const mongoUri = "mongodb://localhost:27017/myschool";

export async function GET(request: Request) {
  let client: MongoClient | null = null;
  try {
    client = new MongoClient(mongoUri);
    await client.connect();
    const db = client.db();

    const url = new URL(request.url);
    const cnicParam = url.searchParams.get("cnic");
    if (cnicParam) {
      const admin = await db
        .collection("admins")
        .findOne(
          { cnic: cnicParam },
          { projection: { password: 0, profilePicture: 0 } }
        );
      if (!admin) {
        return NextResponse.json(
          { message: "Admin not found", error: true },
          { status: 404 }
        );
      }
      return NextResponse.json(
        { ...admin, _id: admin._id.toString() },
        { status: 200 }
      );
    }

    const all = await db
      .collection("admins")
      .find({}, { projection: { password: 0, profilePicture: 0 } })
      .toArray();
    const serialized = all.map(a => ({ ...a, _id: a._id.toString() }));
    return NextResponse.json(serialized, { status: 200 });
  } catch (err: any) {
    console.error("GET /Admins error:", err);
    return NextResponse.json(
      { message: "Internal server error", error: true },
      { status: 500 }
    );
  } finally {
    client?.close();
  }
}

export async function POST(request: Request) {
  let client: MongoClient | null = null;
  try {
    const { cnic, firstName, lastName, email, password, contactNumber } =
      await request.json();

    // Validate required fields
    if (!cnic || !firstName || !lastName || !email || !password || !contactNumber) {
      return NextResponse.json(
        { message: "All fields are required", error: true },
        { status: 400 }
      );
    }
    if (!/^\d{13}$/.test(cnic)) {
      return NextResponse.json(
        { message: "CNIC must be 13 digits", error: true },
        { status: 400 }
      );
    }
    if (!email.includes("@")) {
      return NextResponse.json(
        { message: "Email must include @", error: true },
        { status: 400 }
      );
    }

    client = new MongoClient(mongoUri);
    await client.connect();
    const db = client.db();

    // Duplicate checks
    if (await db.collection("admins").findOne({ cnic })) {
      return NextResponse.json(
        { message: "CNIC already exists", error: true },
        { status: 409 }
      );
    }
    if (await db.collection("admins").findOne({ email })) {
      return NextResponse.json(
        { message: "Email already exists", error: true },
        { status: 409 }
      );
    }

    // *** HASH PASSWORD ***
    const hashedPwd = await bcrypt.hash(password, 10);

    const result = await db.collection("admins").insertOne({
      cnic,
      firstName,
      lastName,
      email,
      password: hashedPwd,
      contactNumber,
    });
    return NextResponse.json(
      { message: "Admin added", id: result.insertedId.toString(), error: false },
      { status: 201 }
    );
  } catch (err) {
    console.error("POST /Admins error:", err);
    return NextResponse.json(
      { message: "Internal server error", error: true },
      { status: 500 }
    );
  } finally {
    client?.close();
  }
}

export async function DELETE(request: Request) {
  let client: MongoClient | null = null;
  try {
    const { id } = await request.json();
    if (!id) {
      return NextResponse.json(
        { message: "Admin ID is required", error: true },
        { status: 400 }
      );
    }
    client = new MongoClient(mongoUri);
    await client.connect();
    const result = await client
      .db()
      .collection("admins")
      .deleteOne({ _id: new ObjectId(id) });
    if (result.deletedCount === 0) {
      return NextResponse.json(
        { message: "Admin not found", error: true },
        { status: 404 }
      );
    }
    return NextResponse.json(
      { message: "Admin deleted", error: false },
      { status: 200 }
    );
  } catch (err) {
    console.error("DELETE /Admins error:", err);
    return NextResponse.json(
      { message: "Internal server error", error: true },
      { status: 500 }
    );
  } finally {
    client?.close();
  }
}

export async function PUT(request: Request) {
  let client: MongoClient | null = null;
  try {
    const { id, firstName, lastName, password, contactNumber } =
      await request.json();

    // Required fields
    if (!id || !firstName || !lastName || !contactNumber) {
      return NextResponse.json(
        { message: "Missing required fields", error: true },
        { status: 400 }
      );
    }

    client = new MongoClient(mongoUri);
    await client.connect();
    const db = client.db();

    // Build the update object
    const updateObj: any = { firstName, lastName, contactNumber };

    // *** HASH NEW PASSWORD IF PROVIDED ***
    if (password) {
      updateObj.password = await bcrypt.hash(password, 10);
    }

    const result = await db
      .collection("admins")
      .updateOne({ _id: new ObjectId(id) }, { $set: updateObj });

    if (result.matchedCount === 0) {
      return NextResponse.json(
        { message: "Admin not found", error: true },
        { status: 404 }
      );
    }
    return NextResponse.json(
      { message: "Admin updated", error: false },
      { status: 200 }
    );
  } catch (err) {
    console.error("PUT /Admins error:", err);
    return NextResponse.json(
      { message: "Internal server error", error: true },
      { status: 500 }
    );
  } finally {
    client?.close();
  }
}
