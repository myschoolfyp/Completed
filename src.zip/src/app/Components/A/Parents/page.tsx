"use client";

import { useState, useEffect } from "react";
import { useRouter } from "next/navigation";
import { FiPlus } from "react-icons/fi";

interface Parent {
  _id: string;
  cnic: string;
  firstName: string;
  lastName: string;
  email: string;
  contactNumber: string;
  students?: ParentStudent[];
}

interface ParentStudent {
  _id: string;
  rollNo: string;
  firstName: string;
  lastName: string;
  classLevel: number;
  classType: string;
}

interface ParentForm {
  cnic: string;
  firstName: string;
  lastName: string;
  email: string;
  password: string;
  contactNumber: string;
}

const API = "/api/Component/A/Parents";

export default function Parents() {
  const router = useRouter();

  // Data
  const [parents, setParents] = useState<Parent[]>([]);
  const [students, setStudents] = useState<ParentStudent[]>([]);

  // Filters & selection
  const [searchParent, setSearchParent] = useState("");
  const [selectedParents, setSelectedParents] = useState<string[]>([]);

  // Add / Update forms
  const [showAdd, setShowAdd] = useState(false);
  const [newParent, setNewParent] = useState<ParentForm>({
    cnic: "",
    firstName: "",
    lastName: "",
    email: "",
    password: "",
    contactNumber: "",
  });
  const [showUpdate, setShowUpdate] = useState(false);
  const [updateCnic, setUpdateCnic] = useState("");
  const [updateParent, setUpdateParent] = useState<Partial<ParentForm> & { _id?: string }>({});

  // Assign-students modal
  const [isAssignOpen, setAssignOpen] = useState(false);
  const [chosenParentIds, setChosenParentIds] = useState<string[]>([]);
  const [chosenStudentIds, setChosenStudentIds] = useState<string[]>([]);
  const [searchStudent, setSearchStudent] = useState("");

  // View-children modal
  const [viewingChildren, setViewingChildren] = useState<ParentStudent[] | null>(null);

  // Feedback
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);

  // Initial fetch
  useEffect(() => {
    fetchParents();
    fetchStudents();
  }, []);

  async function fetchParents() {
    const res = await fetch(API);
    if (res.ok) setParents(await res.json());
  }

  async function fetchStudents() {
    const res = await fetch("/api/Component/A/Students");
    if (res.ok) setStudents(await res.json());
  }

  // ── ADD PARENT ───────────────────────────────────────────────────────────────
  function validateAdd() {
    const { cnic, firstName, lastName, email, password, contactNumber } = newParent;
    if (![cnic, firstName, lastName, email, password, contactNumber].every(Boolean)) {
      setError("All fields are required.");
      return false;
    }
    if (!/^\d{13}$/.test(cnic)) {
      setError("CNIC must be 13 digits.");
      return false;
    }
    if (!/^[A-Za-z]+$/.test(firstName) || !/^[A-Za-z]+$/.test(lastName)) {
      setError("Names must contain letters only.");
      return false;
    }
    if (!email.includes("@")) {
      setError("Email must include @.");
      return false;
    }
    setError(null);
    return true;
  }

  async function handleAdd() {
    if (!validateAdd()) return;
    const res = await fetch(API, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(newParent),
    });
    const data = await res.json();
    if (res.ok) {
      setSuccess("Parent added!");
      setNewParent({ cnic: "", firstName: "", lastName: "", email: "", password: "", contactNumber: "" });
      fetchParents();
    } else {
      setError(data.message);
    }
  }

  // ── UPDATE PARENT ────────────────────────────────────────────────────────────
  async function handleSearch() {
    setError(null);
    setSuccess(null);
    if (!/^\d{13}$/.test(updateCnic)) {
      setError("Enter a valid 13-digit CNIC.");
      return;
    }
    const res = await fetch(`${API}?cnic=${updateCnic}`);
    if (!res.ok) {
      const err = await res.json();
      setError(err.message);
      return;
    }
    const p = await res.json();
    setUpdateParent({ ...p, password: "" });
  }

  function validateUpdate() {
    const { firstName, lastName, contactNumber } = updateParent;
    if (![firstName, lastName, contactNumber].every(Boolean)) {
      setError("First, last name, and contact are required.");
      return false;
    }
    if (!/^[A-Za-z]+$/.test(firstName!) || !/^[A-Za-z]+$/.test(lastName!)) {
      setError("Names must be letters only.");
      return false;
    }
    setError(null);
    return true;
  }

  async function handleUpdate() {
    if (!validateUpdate()) return;
    const payload: any = {
      id: updateParent._id,
      firstName: updateParent.firstName,
      lastName: updateParent.lastName,
      contactNumber: updateParent.contactNumber,
    };
    if (updateParent.password) payload.password = updateParent.password;
    const res = await fetch(API, {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload),
    });
    const d = await res.json();
    if (res.ok) {
      setSuccess("Parent updated!");
      setUpdateParent({});
      setUpdateCnic("");
      fetchParents();
    } else {
      setError(d.message);
    }
  }

  // ── DELETE ───────────────────────────────────────────────────────────────────
  async function handleDelete(id: string) {
    await fetch(API, {
      method: "DELETE",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ id }),
    });
    fetchParents();
  }

  function toggleSelectAll(e: React.ChangeEvent<HTMLInputElement>) {
    if (e.target.checked) setSelectedParents(parents.map(p => p._id));
    else setSelectedParents([]);
  }

  function toggleSingleSelect(id: string) {
    setSelectedParents(prev =>
      prev.includes(id) ? prev.filter(x => x !== id) : [...prev, id]
    );
  }

  async function handleBulkDelete() {
    for (const id of selectedParents) {
      await handleDelete(id);
    }
    setSelectedParents([]);
  }

  // ── ASSIGN STUDENTS ─────────────────────────────────────────────────────────
  const filteredParentsForAssign = parents.filter(p => p.cnic.includes(searchParent));
  const filteredStudentsForAssign = students.filter(s =>
    s.firstName.toLowerCase().includes(searchStudent.toLowerCase()) ||
    s.lastName.toLowerCase().includes(searchStudent.toLowerCase()) ||
    s.rollNo.includes(searchStudent)
  );

  const toggleParentAssign = (id: string) => {
    setChosenParentIds(prev =>
      prev.includes(id) ? prev.filter(x => x !== id) : [...prev, id]
    );
  };

  const toggleStudentAssign = (id: string) => {
    setChosenStudentIds(prev =>
      prev.includes(id) ? prev.filter(x => x !== id) : [...prev, id]
    );
  };

  async function handleAssign() {
    if (chosenParentIds.length === 0 || chosenStudentIds.length === 0) {
      return alert("Select at least one parent and one student");
    }
    const res = await fetch(API, {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ parentIds: chosenParentIds, studentIds: chosenStudentIds }),
    });
    if (res.ok) {
      fetchParents();
      setAssignOpen(false);
      setChosenParentIds([]);
      setChosenStudentIds([]);
    } else {
      console.error("Assign failed:", await res.text());
      alert("Failed to assign");
    }
  }

  // ── VIEW CHILDREN ───────────────────────────────────────────────────────────
  function openChildren(studs?: ParentStudent[]) {
    setViewingChildren(studs || []);
  }

  // ── FILTERED TABLE DATA ─────────────────────────────────────────────────────
  const filtered = parents.filter(p => p.cnic.includes(searchParent));

  // —————————————————————————————————————————————————————————————
  // Everything above is the logic and state. Below comes the `return ( … )`.
  // When you’re ready, enter **101** and I’ll give you the JSX section.
  // —————————————————————————————————————————————————————————————
  return (
    <div className="p-8">
      {/* Header */}
      <div className="flex justify-between mb-6">
        <h1 className="text-3xl font-bold text-[#0F6466]">Parents Management</h1>
        <button
          className="bg-[#0F6466] text-white px-6 py-3 rounded-lg hover:bg-[#0D4B4C]"
          onClick={() => router.back()}
        >
          Back to Dashboard
        </button>
      </div>

      {/* Actions */}
      <div className="flex gap-4 mb-6">
        <button
          className="bg-green-600 text-white px-4 py-2 rounded"
          onClick={() => {
            setShowAdd(true);
            setShowUpdate(false);
            setError(null);
            setSuccess(null);
          }}
        >
          Add New Parent
        </button>
        <button
          className="bg-blue-600 text-white px-4 py-2 rounded"
          onClick={() => {
            setShowUpdate(true);
            setShowAdd(false);
            setError(null);
            setSuccess(null);
          }}
        >
          Update Parent
        </button>
        {selectedParents.length > 0 && (
          <button
            className="bg-red-600 text-white px-4 py-2 rounded"
            onClick={handleBulkDelete}
          >
            Delete Selected ({selectedParents.length})
          </button>
        )}
        <button
          className="flex items-center gap-2 bg-green-700 text-white px-4 py-2 rounded hover:bg-green-800"
          onClick={() => setAssignOpen(true)}
        >
          <FiPlus /> Assign Students
        </button>
      </div>

      {/* ADD FORM */}
      {showAdd && (
        <div className="mb-6 border p-6 rounded shadow">
          {error && <p className="text-red-500 mb-2">{error}</p>}
          {success && <p className="text-green-500 mb-2">{success}</p>}
          <div className="grid grid-cols-3 gap-4">
            {[
              { name: "cnic", placeholder: "CNIC (13 digits)" },
              { name: "firstName", placeholder: "First Name" },
              { name: "lastName", placeholder: "Last Name" },
              { name: "email", placeholder: "Email", type: "email" },
              { name: "password", placeholder: "Password", type: "password" },
              { name: "contactNumber", placeholder: "Contact Number" }
            ].map(fld => (
              <input
                key={fld.name}
                type={(fld as any).type || "text"}
                placeholder={fld.placeholder}
                value={(newParent as any)[fld.name]}
                onChange={e => {
                  const v = e.target.value;
                  setNewParent(prev => ({
                    ...prev,
                    [fld.name]: fld.name === "cnic"
                      ? v.replace(/\D/g, "").slice(0,13)
                      : v
                  }));
                  setError(null);
                  setSuccess(null);
                }}
                className="border p-2 rounded"
              />
            ))}
          </div>
          <div className="mt-4 space-x-4">
            <button
              className="bg-[#0F6466] text-white px-4 py-2 rounded"
              onClick={handleAdd}
            >
              Save
            </button>
            <button
              className="px-4 py-2 rounded border"
              onClick={() => setShowAdd(false)}
            >
              Cancel
            </button>
          </div>
        </div>
      )}

      {/* UPDATE FORM */}
      {showUpdate && (
        <div className="mb-6 border p-6 rounded shadow">
          <h2 className="font-semibold">Search by CNIC</h2>
          <div className="flex gap-2 mt-2">
            <input
              placeholder="CNIC"
              value={updateCnic}
              onChange={e => setUpdateCnic(e.target.value.replace(/\D/g, "").slice(0,13))}
              className="border p-2 rounded"
            />
            <button
              className="bg-blue-600 text-white px-4 py-2 rounded"
              onClick={handleSearch}
            >
              Search
            </button>
            <button
              className="px-4 py-2 rounded border"
              onClick={() => {
                setUpdateParent({});
                setUpdateCnic("");
                setError(null);
              }}
            >
              Clear
            </button>
          </div>
          {error && <p className="text-red-500 mt-2">{error}</p>}
          {updateParent._id && (
            <div className="mt-4 grid grid-cols-3 gap-4">
              <input
                disabled
                value={updateParent.cnic}
                className="bg-gray-100 border p-2 rounded"
              />
              <input
                disabled
                type="email"
                value={updateParent.email}
                className="bg-gray-100 border p-2 rounded"
              />
              <input
                placeholder="First Name"
                value={updateParent.firstName || ""}
                onChange={e =>
                  setUpdateParent(p => ({ ...p, firstName: e.target.value }))
                }
                className="border p-2 rounded"
              />
              <input
                placeholder="Last Name"
                value={updateParent.lastName || ""}
                onChange={e =>
                  setUpdateParent(p => ({ ...p, lastName: e.target.value }))
                }
                className="border p-2 rounded"
              />
              <input
                placeholder="Contact Number"
                value={updateParent.contactNumber || ""}
                onChange={e =>
                  setUpdateParent(p => ({ ...p, contactNumber: e.target.value }))
                }
                className="border p-2 rounded"
              />
              <input
                placeholder="New Password (optional)"
                type="password"
                value={updateParent.password || ""}
                onChange={e =>
                  setUpdateParent(p => ({ ...p, password: e.target.value }))
                }
                className="border p-2 rounded"
              />
              <div className="col-span-3 mt-2 space-x-4">
                <button
                  className="bg-[#0F6466] text-white px-4 py-2 rounded"
                  onClick={handleUpdate}
                >
                  Save Changes
                </button>
                <button
                  className="px-4 py-2 rounded border"
                  onClick={() => setShowUpdate(false)}
                >
                  Cancel
                </button>
              </div>
            </div>
          )}
        </div>
      )}

      {/* FILTER */}
      <div className="mb-4 flex gap-2">
        <input
          placeholder="Filter by CNIC…"
          value={searchParent}
          onChange={e => setSearchParent(e.target.value)}
          className="border p-2 rounded w-64"
        />
      </div>

      {/* TABLE */}
      <table className="w-full border-collapse shadow-lg">
        <thead className="bg-[#0F6466] text-white">
          <tr>
            <th className="p-4">
              <input
                type="checkbox"
                onChange={toggleSelectAll}
                checked={selectedParents.length === filtered.length && filtered.length > 0}
              />
            </th>
            <th className="p-4">First</th>
            <th className="p-4">Last</th>
            <th className="p-4">Email</th>
            <th className="p-4">Contact</th>
            <th className="p-4">CNIC</th>
            <th className="p-4"># Students</th>
            <th className="p-4">Actions</th>
          </tr>
        </thead>
        <tbody>
          {filtered.map(p => (
            <tr key={p._id} className="border-b hover:bg-gray-50">
              <td className="p-4 text-center">
                <input
                  type="checkbox"
                  checked={selectedParents.includes(p._id)}
                  onChange={() => toggleSingleSelect(p._id)}
                />
              </td>
              <td className="p-4 text-center">{p.firstName}</td>
              <td className="p-4 text-center">{p.lastName}</td>
              <td className="p-4 text-center">{p.email}</td>
              <td className="p-4 text-center">{p.contactNumber}</td>
              <td className="p-4 text-center">{p.cnic}</td>
              <td
                className="p-4 text-center cursor-pointer text-blue-600 hover:underline"
                onClick={() => openChildren(p.students)}
              >
                {p.students?.length || 0}
              </td>
              <td className="p-4 text-center">
                <button
                  className="bg-red-500 text-white px-3 py-1 rounded hover:bg-red-600"
                  onClick={() => handleDelete(p._id)}
                >
                  Delete
                </button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>

      {/* ASSIGN STUDENTS MODAL */}
      {isAssignOpen && (
        <div
          className="fixed inset-0 bg-black/50 flex items-center justify-center p-4"
          onClick={() => setAssignOpen(false)}
        >
          <div
            className="bg-white rounded-lg shadow-lg w-full max-w-3xl p-6"
            onClick={e => e.stopPropagation()}
          >
            <h2 className="text-2xl font-bold mb-4">Assign Students</h2>

            {/* Parent selector */}
            <div className="mb-4">
              <label className="block font-semibold mb-1">Filter Parents by CNIC:</label>
              <input
                type="text"
                value={searchParent}
                onChange={e => setSearchParent(e.target.value)}
                placeholder="Enter CNIC…"
                className="border p-2 rounded w-full mb-2"
              />
              <div className="max-h-32 overflow-y-auto border p-2 rounded">
                {filteredParentsForAssign.map(p => (
                  <label key={p._id} className="flex items-center gap-2 mb-1">
                    <input
                      type="checkbox"
                      checked={chosenParentIds.includes(p._id)}
                      onChange={() => toggleParentAssign(p._id)}
                      disabled={!chosenParentIds.includes(p._id) && chosenParentIds.length >= 2}
                    />
                    {p.firstName} {p.lastName} ({p.cnic})
                  </label>
                ))}
                {filteredParentsForAssign.length === 0 && (
                  <p className="text-sm text-gray-500">No parents match.</p>
                )}
              </div>
            </div>

            {/* Student selector */}
            <div className="mb-4">
              <label className="block font-semibold mb-1">Search Students:</label>
              <input
                type="text"
                value={searchStudent}
                onChange={e => setSearchStudent(e.target.value)}
                placeholder="Name or Roll No…"
                className="border p-2 rounded w-full mb-2"
              />
              <div className="max-h-32 overflow-y-auto border p-2 rounded">
                {filteredStudentsForAssign.map(s => (
                  <label key={s._id} className="flex items-center gap-2 mb-1">
                    <input
                      type="checkbox"
                      checked={chosenStudentIds.includes(s._id)}
                      onChange={() => toggleStudentAssign(s._id)}
                    />
                    {s.firstName} {s.lastName} — {s.rollNo} (Class {s.classLevel})
                  </label>
                ))}
                {filteredStudentsForAssign.length === 0 && (
                  <p className="text-sm text-gray-500">No students match.</p>
                )}
              </div>
            </div>

            <div className="flex justify-end gap-4 mt-4">
              <button
                className="px-4 py-2 border"
                onClick={() => setAssignOpen(false)}
              >
                Cancel
              </button>
              <button
                className="px-4 py-2 bg-[#0F6466] text-white rounded"
                onClick={handleAssign}
              >
                Save Assignment
              </button>
            </div>
          </div>
        </div>
      )}

      {/* VIEW CHILDREN MODAL */}
      {viewingChildren && (
        <div
          className="fixed inset-0 bg-black/50 flex items-center justify-center p-4"
          onClick={() => setViewingChildren(null)}
        >
          <div
            className="bg-white rounded-lg shadow-lg w-full max-w-md p-6"
            onClick={e => e.stopPropagation()}
          >
            <h2 className="text-xl font-bold mb-4">Children Details</h2>
            <ul className="space-y-2">
              {viewingChildren.map(s => (
                <li key={s._id} className="border-b pb-2">
                  {s.firstName} {s.lastName} — {s.rollNo} (Class {s.classLevel})
                </li>
              ))}
            </ul>
            <div className="mt-4 text-right">
              <button
                className="px-4 py-2 border"
                onClick={() => setViewingChildren(null)}
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
