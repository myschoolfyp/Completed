"use client";

import { useState, useEffect } from "react";
import { useRouter } from "next/navigation";

interface Student {
  _id: string;
  rollNo: string;
  firstName: string;
  lastName: string;
  email: string;
  contactNumber: string;
  classLevel: number;
}

interface StudentForm {
  rollNo: string;
  firstName: string;
  lastName: string;
  password: string;
  email: string;
  contactNumber: string;
  classLevel: number;
}

const API = "/api/Component/A/Students";
const classLevels = Array.from({ length: 10 }, (_, i) => i + 1);

export default function Students() {
  const router = useRouter();

  // Data + filters + selection
  const [students, setStudents] = useState<Student[]>([]);
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedClassLevel, setSelectedClassLevel] = useState<"all" | string>("all");
  const [selectedStudents, setSelectedStudents] = useState<string[]>([]);

  // Add form
  const [showAdd, setShowAdd] = useState(false);
  const [newStudent, setNewStudent] = useState<StudentForm>({
    rollNo: "",
    firstName: "",
    lastName: "",
    password: "",
    email: "",
    contactNumber: "",
    classLevel: 1
  });

  // Update form
  const [showUpdate, setShowUpdate] = useState(false);
  const [updateRollNo, setUpdateRollNo] = useState("");
  const [updateStudent, setUpdateStudent] = useState<Partial<StudentForm> & { _id?: string; rollNo?: string }>({});

  // Feedback
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);

  useEffect(() => {
    fetchStudents();
  }, []);

  async function fetchStudents() {
    try {
      const res = await fetch(API);
      if (res.ok) setStudents(await res.json());
    } catch (e) {
      console.error(e);
    }
  }

  // ── ADD STUDENT ───────────────────────────────────────────────────────────────
  function validateAdd() {
    const { rollNo, firstName, lastName, password, email, contactNumber } = newStudent;
    if (![rollNo, firstName, lastName, password, email, contactNumber].every(Boolean)) {
      setError("All fields are required.");
      return false;
    }
    if (!/^[A-Za-z]+$/.test(firstName) || !/^[A-Za-z]+$/.test(lastName)) {
      setError("Names must contain letters only.");
      return false;
    }
    if (!/^\d{9}$/.test(rollNo)) {
      setError("Roll No must be exactly 9 digits.");
      return false;
    }
    if (!email.includes("@")) {
      setError("Email must include “@”.");
      return false;
    }
    setError(null);
    return true;
  }

  async function handleAdd() {
    if (!validateAdd()) return;
    try {
      const res = await fetch(API, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(newStudent)
      });
      const data = await res.json();
      if (res.ok) {
        setSuccess("Student added!");
        setNewStudent({
          rollNo: "",
          firstName: "",
          lastName: "",
          password: "",
          email: "",
          contactNumber: "",
          classLevel: 1
        });
        fetchStudents();
      } else {
        setError(data.message || "Failed to add student.");
      }
    } catch {
      setError("Unexpected error.");
    }
  }

  // ── UPDATE STUDENT ────────────────────────────────────────────────────────────
  async function handleSearch() {
    setError(null);
    setSuccess(null);
    if (!/^\d{9}$/.test(updateRollNo)) {
      setError("Enter a valid 9-digit Roll No.");
      return;
    }
    try {
      const res = await fetch(`${API}?rollNo=${updateRollNo}`);
      if (!res.ok) {
        const err = await res.json();
        setError(err.message || "Student not found.");
        return;
      }
      const data: any = await res.json();
      setUpdateStudent({ ...data, password: "" });
    } catch {
      setError("Error searching for student.");
    }
  }

  function validateUpdate() {
    const { firstName, lastName, classLevel, email, contactNumber, password } = updateStudent;
    if (![firstName, lastName, classLevel, email, contactNumber].every(Boolean)) {
      setError("All fields except password are required.");
      return false;
    }
    if (!/^[A-Za-z]+$/.test(firstName!) || !/^[A-Za-z]+$/.test(lastName!)) {
      setError("Names must contain letters only.");
      return false;
    }
    if (password && password.length < 6) {
      setError("Password must be at least 6 characters.");
      return false;
    }
    if (!email!.includes("@")) {
      setError("Email must include “@”.");
      return false;
    }
    setError(null);
    return true;
  }

  async function handleUpdate() {
    if (!validateUpdate()) return;
    try {
      const payload: any = {
        id: updateStudent._id,
        firstName: updateStudent.firstName,
        lastName: updateStudent.lastName,
        classLevel: updateStudent.classLevel,
        email: updateStudent.email,
        contactNumber: updateStudent.contactNumber
      };
      if (updateStudent.password) payload.password = updateStudent.password;
      const res = await fetch(API, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload)
      });
      const data = await res.json();
      if (res.ok) {
        setSuccess("Student updated!");
        setUpdateStudent({});
        setUpdateRollNo("");
        fetchStudents();
      } else {
        setError(data.message || "Failed to update.");
      }
    } catch {
      setError("Server error.");
    }
  }

  // ── DELETE (single & bulk) ────────────────────────────────────────────────────
  async function handleDelete(id: string) {
    await fetch(API, {
      method: "DELETE",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ id })
    });
    fetchStudents();
  }

  const toggleSelectAll = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.checked) {
      setSelectedStudents(filtered.map(s => s._id));
    } else {
      setSelectedStudents([]);
    }
  };

  const toggleSingleSelect = (id: string) => {
    setSelectedStudents(prev =>
      prev.includes(id) ? prev.filter(x => x !== id) : [...prev, id]
    );
  };

  async function handleBulkDelete() {
    for (const id of selectedStudents) {
      await fetch(API, {
        method: "DELETE",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ id })
      });
    }
    setSelectedStudents([]);
    fetchStudents();
  }

  // ── FILTERING ────────────────────────────────────────────────────────────────
  const filtered = students.filter(s => {
    const matchesSearch =
      s.firstName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      s.lastName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      s.rollNo.includes(searchTerm);
    const levelOK =
      selectedClassLevel === "all" ||
      s.classLevel === parseInt(selectedClassLevel);
    return matchesSearch && levelOK;
  });

  // ── JSX BELOW ───────────────────────────────────────────────────────────────
  return (
    <div className="p-8">
      {/* Header */}
      <div className="flex justify-between mb-6">
        <h1 className="text-3xl font-bold text-[#0F6466]">Students Management</h1>
        <button
          className="bg-[#0F6466] text-white px-6 py-3 rounded-lg hover:bg-[#0D4B4C]"
          onClick={() => router.back()}
        >
          Back to Dashboard
        </button>
      </div>

      {/* Mode Buttons */}
      <div className="flex space-x-4 mb-6">
        <button
          className="bg-green-600 text-white px-4 py-2 rounded"
          onClick={() => {
            setShowAdd(true);
            setShowUpdate(false);
            setError(null);
            setSuccess(null);
          }}
        >
          Add New Student
        </button>
        <button
          className="bg-blue-600 text-white px-4 py-2 rounded"
          onClick={() => {
            setShowUpdate(true);
            setShowAdd(false);
            setError(null);
            setSuccess(null);
          }}
        >
          Update Student
        </button>
        {selectedStudents.length > 0 && (
          <button
            className="bg-red-600 text-white px-4 py-2 rounded"
            onClick={handleBulkDelete}
          >
            Delete Selected ({selectedStudents.length})
          </button>
        )}
      </div>

      {/* ADD FORM */}
      {showAdd && (
        <div className="mb-8 border p-6 rounded shadow">
          {error && <p className="text-red-500 mb-2">{error}</p>}
          {success && <p className="text-green-500 mb-2">{success}</p>}
          <div className="grid grid-cols-3 gap-4 mb-4">
            {[
              { name: "rollNo", placeholder: "Roll No (9 digits)" },
              { name: "firstName", placeholder: "First Name" },
              { name: "lastName", placeholder: "Last Name" },
              { name: "password", placeholder: "Password", type: "password" },
              { name: "email", placeholder: "Email", type: "email" },
              { name: "contactNumber", placeholder: "Contact Number" }
            ].map(fld => (
              <input
                key={fld.name}
                name={fld.name}
                type={(fld as any).type || "text"}
                placeholder={fld.placeholder}
                className="border p-3 rounded-lg"
                value={(newStudent as any)[fld.name]}
                onChange={e => {
                  const v = e.target.value;
                  setNewStudent(prev => ({
                    ...prev,
                    [fld.name]:
                      fld.name === "rollNo"
                        ? v.replace(/\D/g, "").slice(0, 9)
                        : fld.name === "classLevel"
                        ? Number(v)
                        : v
                  }));
                  setError(null);
                  setSuccess(null);
                }}
              />
            ))}
            <select
              value={newStudent.classLevel}
              onChange={e =>
                setNewStudent(prev => ({
                  ...prev,
                  classLevel: Number(e.target.value)
                }))
              }
              className="border p-3 rounded-lg"
            >
              {classLevels.map(lvl => (
                <option key={lvl} value={lvl}>
                  Class {lvl}
                </option>
              ))}
            </select>
          </div>
          <div className="flex gap-4">
            <button
              className="bg-[#0F6466] text-white px-6 py-2 rounded"
              onClick={handleAdd}
            >
              Save Student
            </button>
            <button
              className="bg-gray-400 text-white px-6 py-2 rounded"
              onClick={() => setShowAdd(false)}
            >
              Cancel
            </button>
          </div>
        </div>
      )}

      {/* UPDATE FORM */}
      {showUpdate && (
        <div className="mb-8 border p-6 rounded shadow">
          <h2 className="text-xl font-semibold mb-4">Search by Roll No</h2>
          {error && <p className="text-red-500 mb-2">{error}</p>}
          {success && <p className="text-green-500 mb-2">{success}</p>}
          <div className="flex items-center mb-4">
            <input
              type="text"
              placeholder="Roll No"
              value={updateRollNo}
              onChange={e =>
                setUpdateRollNo(e.target.value.replace(/\D/g, "").slice(0, 9))
              }
              className="border p-3 rounded-lg mr-2"
            />
            <button
              className="bg-blue-600 text-white px-4 py-2 rounded"
              onClick={handleSearch}
            >
              Search
            </button>
            <button
              className="ml-2 px-4 py-2 rounded bg-gray-200"
              onClick={() => {
                setUpdateStudent({});
                setUpdateRollNo("");
                setError(null);
                setSuccess(null);
              }}
            >
              Clear
            </button>
          </div>
          {updateStudent._id && (
            <>
              <h3 className="text-lg font-medium mb-3">Update Details</h3>
              <div className="grid grid-cols-3 gap-4 mb-4">
                <input
                  placeholder="First Name"
                  value={updateStudent.firstName || ""}
                  onChange={e =>
                    setUpdateStudent(prev => ({
                      ...prev,
                      firstName: e.target.value
                    }))
                  }
                  className="border p-3 rounded-lg"
                />
                <input
                  placeholder="Last Name"
                  value={updateStudent.lastName || ""}
                  onChange={e =>
                    setUpdateStudent(prev => ({
                      ...prev,
                      lastName: e.target.value
                    }))
                  }
                  className="border p-3 rounded-lg"
                />
                <select
                  value={updateStudent.classLevel || 1}
                  onChange={e =>
                    setUpdateStudent(prev => ({
                      ...prev,
                      classLevel: Number(e.target.value)
                    }))
                  }
                  className="border p-3 rounded-lg"
                >
                  {classLevels.map(lvl => (
                    <option key={lvl} value={lvl}>
                      Class {lvl}
                    </option>
                  ))}
                </select>
                <input
                  placeholder="Email"
                  type="email"
                  value={updateStudent.email || ""}
                  onChange={e =>
                    setUpdateStudent(prev => ({
                      ...prev,
                      email: e.target.value
                    }))
                  }
                  className="border p-3 rounded-lg"
                />
                <input
                  placeholder="Contact Number"
                  value={updateStudent.contactNumber || ""}
                  onChange={e =>
                    setUpdateStudent(prev => ({
                      ...prev,
                      contactNumber: e.target.value
                    }))
                  }
                  className="border p-3 rounded-lg"
                />
                <input
                  placeholder="New Password (optional)"
                  type="password"
                  value={updateStudent.password || ""}
                  onChange={e =>
                    setUpdateStudent(prev => ({
                      ...prev,
                      password: e.target.value
                    }))
                  }
                  className="border p-3 rounded-lg"
                />
                <input
                  placeholder="Roll No"
                  value={updateStudent.rollNo}
                  disabled
                  className="border p-3 rounded-lg bg-gray-100 cursor-not-allowed"
                />
              </div>
              <div className="flex gap-4">
                <button
                  className="bg-[#0F6466] text-white px-6 py-2 rounded"
                  onClick={handleUpdate}
                >
                  Save Changes
                </button>
                <button
                  className="bg-gray-400 text-white px-6 py-2 rounded"
                  onClick={() => {
                    setUpdateStudent({});
                    setError(null);
                    setSuccess(null);
                  }}
                >
                  Cancel
                </button>
              </div>
            </>
          )}
        </div>
      )}

      {/* FILTER + TABLE */}
      <div className="mb-6 flex gap-4">
        <input
          type="text"
          placeholder="Search students..."
          className="border p-3 rounded-lg w-64"
          value={searchTerm}
          onChange={e => setSearchTerm(e.target.value)}
        />
        <select
          className="border p-3 rounded-lg"
          value={selectedClassLevel}
          onChange={e => {
            setSelectedClassLevel(e.target.value as "all" | string);
            setSelectedStudents([]);
          }}
        >
          <option value="all">All Class Levels</option>
          {classLevels.map(lvl => (
            <option key={lvl} value={String(lvl)}>
              Class {lvl}
            </option>
          ))}
        </select>
      </div>

      <table className="w-full border-collapse shadow-lg">
        <thead className="bg-[#0F6466] text-white">
          <tr>
            <th className="p-4">
              <input
                type="checkbox"
                onChange={toggleSelectAll}
                checked={
                  selectedStudents.length === filtered.length &&
                  filtered.length > 0
                }
              />
            </th>
            <th className="p-4">#</th>
            <th className="p-4">Roll No</th>
            <th className="p-4">First Name</th>
            <th className="p-4">Last Name</th>
            <th className="p-4">Email</th>
            <th className="p-4">Contact</th>
            <th className="p-4">Class Level</th>
            <th className="p-4">Actions</th>
          </tr>
        </thead>
        <tbody>
          {filtered.map((s, idx) => (
            <tr key={s._id} className="border-b hover:bg-gray-50">
              <td className="p-4 text-center">
                <input
                  type="checkbox"
                  checked={selectedStudents.includes(s._id)}
                  onChange={() => toggleSingleSelect(s._id)}
                />
              </td>
              <td className="p-4 text-center">{idx + 1}</td>
              <td className="p-4 text-center font-semibold">{s.rollNo}</td>
              <td className="p-4 text-center">{s.firstName}</td>
              <td className="p-4 text-center">{s.lastName}</td>
              <td className="p-4 text-center">{s.email}</td>
              <td className="p-4 text-center">{s.contactNumber}</td>
              <td className="p-4 text-center">Class {s.classLevel}</td>
              <td className="p-4 text-center">
                <button
                  onClick={() => handleDelete(s._id)}
                  className="bg-red-500 text-white px-3 py-1 rounded hover:bg-red-600"
                >
                  Delete
                </button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
