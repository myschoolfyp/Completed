// app/Components/A/Timetable/Edit/page.tsx
"use client";
import { useState, useEffect } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import { Trash2, Plus } from "lucide-react";

interface ClassData {
  className:  string;
  classLevel: string;
  stream:     string;
  courses:    string[];
  teachers?:  { course: string; teacher: string }[];
}
interface Teacher {
  _id:        string;
  firstName:  string;
  lastName:   string;
  department: string;
}

interface Slot {
  startTime: string;
  endTime:   string;
  course:    string;
  teacher:   string;
  teacherId: string;
  room:      string;
}
interface Day {
  name:  string;
  slots: Slot[];
}
interface TimetableData {
  _id:          string;
  className:    string;
  classLevel:   string;
  department:   string;
  days:         Day[];
  breakTime:    { start: string; end: string };
}

export default function EditTimetable() {
  const router      = useRouter();
  const params      = useSearchParams();
  const timetableId = params.get("timetableId") || "";

  // --- State ---
  const [classes, setClasses]               = useState<ClassData[]>([]);
  const [teachers, setTeachers]             = useState<Teacher[]>([]);
  const [selectedDepartment, setDept]       = useState("");
  const [data, setData]                     = useState<TimetableData | null>(null);
  const [days, setDays]                     = useState<Day[]>([]);
  const [breakTime, setBreakTime]           = useState({ start: "", end: "" });
  const [editingSlot, setEditingSlot]       = useState<{ dayIndex: number; slotIndex: number } | null>(null);
  const [editingBreak, setEditingBreak]     = useState(false);
  const [saving, setSaving]                 = useState(false);
  const [status, setStatus]                 = useState<{ success: boolean; message: string } | null>(null);

  // --- Fetch classes once ---
  useEffect(() => {
    fetch("/api/Component/A/classes/newclass/assignteachers?action=fetchClasses")
      .then(r => r.json())
      .then(setClasses)
      .catch(console.error);
  }, []);

  // --- Fetch timetable data once ---
  useEffect(() => {
    if (!timetableId) return;
    fetch(`/api/Component/A/timetable/Edit?timetableId=${timetableId}`)
      .then(r => {
        if (!r.ok) throw new Error(`Status ${r.status}`);
        return r.json();
      })
      .then((t: TimetableData) => {
        setData(t);
        setDays(t.days);
        setBreakTime(t.breakTime);
        setDept(t.department);
      })
      .catch(err => setStatus({ success: false, message: err.message }));
  }, [timetableId]);

  // --- Fetch teachers live when department changes ---
  useEffect(() => {
    if (!selectedDepartment) return;
    fetch(
      `/api/Component/A/classes/newclass/assignteachers?action=fetchTeachers&department=${selectedDepartment}`
    )
      .then(r => r.json())
      .then(setTeachers)
      .catch(console.error);
  }, [selectedDepartment]);

  // --- Slot add/delete helpers ---
  const addSlotsToDay = (dayIndex: number) => {
    const n = parseInt(prompt("How many slots to add?") || "0", 10);
    if (isNaN(n) || n < 1) return;
    setDays(d =>
      d.map((day, i) =>
        i === dayIndex
          ? {
              ...day,
              slots: [
                ...day.slots,
                ...Array(n).fill({
                  startTime: "",
                  endTime:   "",
                  course:    "",
                  teacher:   "",
                  teacherId: "",
                  room:      "",
                }),
              ],
            }
          : day
      )
    );
  };
  const deleteSlot = (di: number, si: number) => {
    setDays(d =>
      d.map((day, i) =>
        i === di
          ? { ...day, slots: day.slots.filter((_, idx) => idx !== si) }
          : day
      )
    );
  };

  const handleSlotEdit = (
    di: number,
    si: number,
    field: keyof Slot,
    value: string
  ) => {
    setDays(d => {
      const copy = [...d];
      copy[di].slots[si] = { ...copy[di].slots[si], [field]: value };
      return copy;
    });
  };

  const generateRoomNumbers = () =>
    Array.from({ length: 20 }, (_, i) => `A-${String(i + 1).padStart(2, "0")}`);

  // --- Save updated timetable ---
  const handleSave = async () => {
    if (!data) return;
    setSaving(true);
    try {
      const payload = {
        _id:        data._id,
        className:  data.className,
        classLevel: data.classLevel,
        department: selectedDepartment,
        days,
        breakTime,
      };
      const res = await fetch("/api/Component/A/timetable/Edit", {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });
      const json = await res.json();
      if (!res.ok) throw new Error(json.error || "Update failed");
      setStatus({ success: true, message: "Timetable updated!" });
    } catch (err: any) {
      setStatus({ success: false, message: err.message });
    } finally {
      setSaving(false);
    }
  };

  if (!data) {
    return (
      <div className="p-8 text-center text-gray-600">
        {status ? status.message : "Loading timetable..."}
      </div>
    );
  }

  return (
    <div className="p-8 max-w-7xl mx-auto space-y-8">
      <h1 className="text-3xl font-bold text-[#0F6466] text-center">
        Edit Timetable: {data.className} ({data.classLevel})
      </h1>

      {/* Department Selector */}
      <div className="flex justify-center">
        <select
          value={selectedDepartment}
          onChange={(e) => setDept(e.target.value)}
          className="p-2 border rounded"
        >
          <option value="">Select Department</option>
          {["Arts","Maths","Chem","Physics","English","Urdu","Islamiat","History"].map((d) => (
            <option key={d} value={d}>{d}</option>
          ))}
        </select>
      </div>

      {/* Day Controls */}
      <div className="flex flex-wrap gap-4 justify-center">
        {days.map((day, i) => (
          <button
            key={day.name}
            onClick={() => addSlotsToDay(i)}
            className="px-4 py-2 bg-[#0F6466] text-white rounded hover:bg-[#0a4a4c]"
          >
            Add {day.name} Slot
          </button>
        ))}
      </div>

      {/* Timetable Grid */}
      <div className="grid grid-cols-6 gap-4">
        {days.map((day, di) => (
          <div key={day.name} className="bg-gray-50 p-4 rounded border">
            <h2 className="font-semibold text-[#0F6466] mb-2">{day.name}</h2>
            {day.slots.map((slot, si) => (
              <div
                key={si}
                className="relative mb-4 p-2 bg-white rounded shadow cursor-pointer"
                onClick={() => setEditingSlot({ dayIndex: di, slotIndex: si })}
              >
                {/* delete icon */}
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    deleteSlot(di, si);
                  }}
                  className="absolute top-1 right-1 text-red-600"
                >
                  <Trash2 size={14} />
                </button>
                <div className="text-sm text-[#0F6466]">
                  {slot.startTime}–{slot.endTime}
                </div>
                <div className="font-medium">{slot.course}</div>
                <div className="text-xs flex justify-between">
                  <span>{slot.teacher}</span>
                  <span>{slot.room}</span>
                </div>
              </div>
            ))}
          </div>
        ))}

        {/* Break */}
        <div
          className="bg-[#0F6466] text-white p-4 rounded text-center cursor-pointer"
          onClick={() => setEditingBreak(true)}
        >
          <h2 className="font-semibold mb-2">Break</h2>
          <p>{breakTime.start}–{breakTime.end}</p>
        </div>
      </div>

      {/* Save Button */}
      <div className="text-center">
        <button
          onClick={handleSave}
          disabled={saving}
          className="px-6 py-2 bg-gradient-to-r from-[#0F6466] to-[#2D9F9C] text-white rounded hover:opacity-90 disabled:opacity-50"
        >
          {saving ? "Saving…" : "Save Changes"}
        </button>
      </div>

      {/* Feedback */}
      {status && (
        <div className={`text-center p-3 rounded-md ${
          status.success ? "bg-green-100 text-green-700" : "bg-red-100 text-red-700"
        }`}>
          {status.message}
        </div>
      )}

      {/* Slot Edit Modal */}
      {editingSlot && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4">
          <div className="bg-white w-full max-w-md p-6 rounded shadow space-y-4">
            <h3 className="text-xl font-semibold text-[#0F6466]">Edit Slot</h3>
            {/* Time */}
            <div className="flex gap-2">
              <input
                type="time"
                value={days[editingSlot.dayIndex].slots[editingSlot.slotIndex].startTime}
                onChange={(e) => handleSlotEdit(editingSlot.dayIndex, editingSlot.slotIndex, "startTime", e.target.value)}
                className="flex-1 p-2 border rounded"
              />
              <input
                type="time"
                value={days[editingSlot.dayIndex].slots[editingSlot.slotIndex].endTime}
                onChange={(e) => handleSlotEdit(editingSlot.dayIndex, editingSlot.slotIndex, "endTime", e.target.value)}
                className="flex-1 p-2 border rounded"
              />
            </div>
            {/* Course */}
            <select
              className="w-full p-2 border rounded"
              value={days[editingSlot.dayIndex].slots[editingSlot.slotIndex].course}
              onChange={(e) => handleSlotEdit(editingSlot.dayIndex, editingSlot.slotIndex, "course", e.target.value)}
            >
              <option value="">Select Course</option>
              {classes.find(c => c.className === data.className)?.courses.map(c => (
                <option key={c} value={c}>{c}</option>
              ))}
            </select>
            {/* Teacher */}
            <select
              className="w-full p-2 border rounded"
              value={days[editingSlot.dayIndex].slots[editingSlot.slotIndex].teacherId}
              onChange={(e) => {
                const t = teachers.find(t => t._id === e.target.value);
                if (t) {
                  handleSlotEdit(editingSlot.dayIndex, editingSlot.slotIndex, "teacher", `${t.firstName} ${t.lastName}`);
                  handleSlotEdit(editingSlot.dayIndex, editingSlot.slotIndex, "teacherId", t._id);
                }
              }}
            >
              <option value="">Select Teacher</option>
              {teachers.map(t => (
                <option key={t._id} value={t._id}>
                  {t.firstName} {t.lastName}
                </option>
              ))}
            </select>
            {/* Room */}
            <select
              className="w-full p-2 border rounded"
              value={days[editingSlot.dayIndex].slots[editingSlot.slotIndex].room}
              onChange={(e) => handleSlotEdit(editingSlot.dayIndex, editingSlot.slotIndex, "room", e.target.value)}
            >
              <option value="">Select Room</option>
              {generateRoomNumbers().map(r => (
                <option key={r} value={r}>{r}</option>
              ))}
            </select>
            <button
              onClick={() => setEditingSlot(null)}
              className="w-full py-2 bg-[#0F6466] text-white rounded hover:bg-[#0a4a4c]"
            >
              Done
            </button>
          </div>
        </div>
      )}

      {/* Break Edit Modal */}
      {editingBreak && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4">
          <div className="bg-white w-full max-w-sm p-6 rounded shadow space-y-4">
            <h3 className="text-xl font-semibold text-[#0F6466]">Edit Break Time</h3>
            <div className="flex gap-2">
              <input
                type="time"
                value={breakTime.start}
                onChange={e => setBreakTime(bt => ({ ...bt, start: e.target.value }))}
                className="flex-1 p-2 border rounded"
              />
              <input
                type="time"
                value={breakTime.end}
                onChange={e => setBreakTime(bt => ({ ...bt, end: e.target.value }))}
                className="flex-1 p-2 border rounded"
              />
            </div>
            <button
              onClick={() => setEditingBreak(false)}
              className="w-full py-2 bg-[#0F6466] text-white rounded hover:bg-[#0a4a4c]"
            >
              Done
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
