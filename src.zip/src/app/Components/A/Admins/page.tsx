"use client";

import { useState, useEffect } from "react";
import { useRouter } from "next/navigation";

interface Admin {
  _id: string;
  cnic: string;
  firstName: string;
  lastName: string;
  email: string;
  contactNumber: string;
}

interface AdminForm {
  cnic: string;
  firstName: string;
  lastName: string;
  email: string;
  password: string;
  contactNumber: string;
}

const API = "/api/Component/A/Admins";

export default function Admins() {
  const router = useRouter();

  // Data + filters + selection
  const [admins, setAdmins] = useState<Admin[]>([]);
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedAdmins, setSelectedAdmins] = useState<string[]>([]);

  // Add form
  const [showAdd, setShowAdd] = useState(false);
  const [newAdmin, setNewAdmin] = useState<AdminForm>({
    cnic: "",
    firstName: "",
    lastName: "",
    email: "",
    password: "",
    contactNumber: ""
  });

  // Update form
  const [showUpdate, setShowUpdate] = useState(false);
  const [updateCnic, setUpdateCnic] = useState("");
  const [updateAdmin, setUpdateAdmin] = useState<Partial<AdminForm> & { _id?: string }>({});

  // Feedback
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);

  useEffect(() => {
    fetchAdmins();
  }, []);

  async function fetchAdmins() {
    try {
      const res = await fetch(API);
      if (res.ok) setAdmins(await res.json());
    } catch (e) {
      console.error(e);
    }
  }

  // ── ADD ADMIN ────────────────────────────────────────────────────────────────
  function validateAdd() {
    const { cnic, firstName, lastName, email, password, contactNumber } = newAdmin;
    if (![cnic, firstName, lastName, email, password, contactNumber].every(Boolean)) {
      setError("All fields are required.");
      return false;
    }
    if (!/^\d{13}$/.test(cnic)) {
      setError("CNIC must be exactly 13 digits.");
      return false;
    }
    if (!/^[A-Za-z]+$/.test(firstName) || !/^[A-Za-z]+$/.test(lastName)) {
      setError("Names must contain letters only.");
      return false;
    }
    if (!email.includes("@")) {
      setError("Email must include “@”.");
      return false;
    }
    setError(null);
    return true;
  }

  async function handleAdd() {
    if (!validateAdd()) return;
    try {
      const res = await fetch(API, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(newAdmin)
      });
      const data = await res.json();
      if (res.ok) {
        setSuccess("Admin added!");
        setNewAdmin({ cnic: "", firstName: "", lastName: "", email: "", password: "", contactNumber: "" });
        fetchAdmins();
      } else {
        setError(data.message || "Failed to add admin.");
      }
    } catch {
      setError("Unexpected error.");
    }
  }

  // ── UPDATE ADMIN ─────────────────────────────────────────────────────────────
  async function handleSearch() {
    setError(null);
    setSuccess(null);
    if (!/^\d{13}$/.test(updateCnic)) {
      setError("Enter a valid 13-digit CNIC.");
      return;
    }
    try {
      const res = await fetch(`${API}?cnic=${updateCnic}`);
      if (!res.ok) {
        const err = await res.json();
        setError(err.message || "Admin not found.");
        return;
      }
      const data: any = await res.json();
      setUpdateAdmin({ ...data, password: "" });
    } catch {
      setError("Error searching for admin.");
    }
  }

  function validateUpdate() {
    const { firstName, lastName, contactNumber, password } = updateAdmin;
    if (![firstName, lastName, contactNumber].every(Boolean)) {
      setError("First name, last name, and contact are required.");
      return false;
    }
    if (!/^[A-Za-z]+$/.test(firstName!) || !/^[A-Za-z]+$/.test(lastName!)) {
      setError("Names must contain letters only.");
      return false;
    }
    if (password && password.length < 6) {
      setError("Password must be at least 6 characters.");
      return false;
    }
    setError(null);
    return true;
  }

  async function handleUpdate() {
    if (!validateUpdate()) return;
    try {
      const payload: any = {
        id: updateAdmin._id,
        firstName: updateAdmin.firstName,
        lastName: updateAdmin.lastName,
        contactNumber: updateAdmin.contactNumber
      };
      if (updateAdmin.password) payload.password = updateAdmin.password;
      const res = await fetch(API, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload)
      });
      const data = await res.json();
      if (res.ok) {
        setSuccess("Admin updated!");
        setUpdateAdmin({});
        setUpdateCnic("");
        fetchAdmins();
      } else {
        setError(data.message || "Failed to update.");
      }
    } catch {
      setError("Server error.");
    }
  }

  // ── DELETE ───────────────────────────────────────────────────────────────────
  async function handleDelete(id: string) {
    await fetch(API, {
      method: "DELETE",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ id })
    });
    fetchAdmins();
  }

  function toggleSelectAll(e: React.ChangeEvent<HTMLInputElement>) {
    if (e.target.checked) {
      setSelectedAdmins(admins.map(a => a._id));
    } else {
      setSelectedAdmins([]);
    }
  }

  function toggleSingleSelect(id: string) {
    setSelectedAdmins(prev =>
      prev.includes(id) ? prev.filter(x => x !== id) : [...prev, id]
    );
  }

  async function handleBulkDelete() {
    for (const id of selectedAdmins) {
      await fetch(API, {
        method: "DELETE",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ id })
      });
    }
    setSelectedAdmins([]);
    fetchAdmins();
  }

  const filtered = admins.filter(a => {
    const lower = searchTerm.toLowerCase();
    return (
      a.firstName.toLowerCase().includes(lower) ||
      a.lastName.toLowerCase().includes(lower) ||
      a.cnic.includes(searchTerm)
    );
  });

  return (
    <div className="p-8">
      {/* Header */}
      <div className="flex justify-between mb-6">
        <h1 className="text-3xl font-bold text-[#0F6466]">Admins Management</h1>
        <button
          className="bg-[#0F6466] text-white px-6 py-3 rounded-lg hover:bg-[#0D4B4C]"
          onClick={() => router.back()}
        >
          Back to Dashboard
        </button>
      </div>

      {/* Mode Buttons */}
      <div className="flex space-x-4 mb-6">
        <button
          className="bg-green-600 text-white px-4 py-2 rounded"
          onClick={() => {
            setShowAdd(true);
            setShowUpdate(false);
            setError(null);
            setSuccess(null);
          }}
        >
          Add New Admin
        </button>
        <button
          className="bg-blue-600 text-white px-4 py-2 rounded"
          onClick={() => {
            setShowUpdate(true);
            setShowAdd(false);
            setError(null);
            setSuccess(null);
          }}
        >
          Update Admin
        </button>
        {selectedAdmins.length > 0 && (
          <button
            className="bg-red-600 text-white px-4 py-2 rounded"
            onClick={handleBulkDelete}
          >
            Delete Selected ({selectedAdmins.length})
          </button>
        )}
      </div>

      {/* ADD FORM */}
      {showAdd && (
        <div className="mb-8 border p-6 rounded shadow">
          {error && <p className="text-red-500 mb-2">{error}</p>}
          {success && <p className="text-green-500 mb-2">{success}</p>}
          <div className="grid grid-cols-3 gap-4 mb-4">
            {[
              { name: "cnic", placeholder: "CNIC (13 digits)" },
              { name: "firstName", placeholder: "First Name" },
              { name: "lastName", placeholder: "Last Name" },
              { name: "email", placeholder: "Email", type: "email" },
              { name: "password", placeholder: "Password", type: "password" },
              { name: "contactNumber", placeholder: "Contact Number" }
            ].map(fld => (
              <input
                key={fld.name}
                name={fld.name}
                type={(fld as any).type || "text"}
                placeholder={fld.placeholder}
                className="border p-3 rounded-lg"
                value={(newAdmin as any)[fld.name]}
                onChange={e => {
                  const v = e.target.value;
                  setNewAdmin(prev => ({
                    ...prev,
                    [fld.name]:
                      fld.name === "cnic"
                        ? v.replace(/\D/g, "").slice(0,13)
                        : v
                  }));
                  setError(null);
                  setSuccess(null);
                }}
              />
            ))}
          </div>
          <div className="flex gap-4">
            <button
              className="bg-[#0F6466] text-white px-6 py-2 rounded"
              onClick={handleAdd}
            >
              Save Admin
            </button>
            <button
              className="bg-gray-400 text-white px-6 py-2 rounded"
              onClick={() => setShowAdd(false)}
            >
              Cancel
            </button>
          </div>
        </div>
      )}

      {/* UPDATE FORM */}
      {showUpdate && (
        <div className="mb-8 border p-6 rounded shadow">
          <h2 className="text-xl font-semibold mb-4">Search by CNIC</h2>
          {error && <p className="text-red-500 mb-2">{error}</p>}
          {success && <p className="text-green-500 mb-2">{success}</p>}
          <div className="flex items-center mb-4">
            <input
              type="text"
              placeholder="CNIC"
              value={updateCnic}
              onChange={e => setUpdateCnic(e.target.value.replace(/\D/g, "").slice(0,13))}
              className="border p-3 rounded-lg mr-2"
            />
            <button
              className="bg-blue-600 text-white px-4 py-2 rounded"
              onClick={handleSearch}
            >
              Search
            </button>
            <button
              className="ml-2 px-4 py-2 rounded bg-gray-200"
              onClick={() => {
                setUpdateAdmin({});
                setUpdateCnic("");
                setError(null);
                setSuccess(null);
              }}
            >
              Clear
            </button>
          </div>
          {updateAdmin._id && (
            <>
              <h3 className="text-lg font-medium mb-3">Update Details</h3>
              <div className="grid grid-cols-3 gap-4 mb-4">
                <input
                  placeholder="First Name"
                  value={updateAdmin.firstName || ""}
                  onChange={e =>
                    setUpdateAdmin(prev => ({ ...prev, firstName: e.target.value }))
                  }
                  className="border p-3 rounded-lg"
                />
                <input
                  placeholder="Last Name"
                  value={updateAdmin.lastName || ""}
                  onChange={e =>
                    setUpdateAdmin(prev => ({ ...prev, lastName: e.target.value }))
                  }
                  className="border p-3 rounded-lg"
                />
                <input
                  placeholder="Contact Number"
                  value={updateAdmin.contactNumber || ""}
                  onChange={e =>
                    setUpdateAdmin(prev => ({ ...prev, contactNumber: e.target.value }))
                  }
                  className="border p-3 rounded-lg"
                />
                <input
                  placeholder="New Password (optional)"
                  type="password"
                  value={updateAdmin.password || ""}
                  onChange={e =>
                    setUpdateAdmin(prev => ({ ...prev, password: e.target.value }))
                  }
                  className="border p-3 rounded-lg"
                />
                <input
                  placeholder="CNIC"
                  value={updateAdmin.cnic}
                  disabled
                  className="border p-3 rounded-lg bg-gray-100 cursor-not-allowed"
                />
                <input
                  placeholder="Email"
                  type="email"
                  value={updateAdmin.email}
                  disabled
                  className="border p-3 rounded-lg bg-gray-100 cursor-not-allowed"
                />
              </div>
              <div className="flex gap-4">
                <button
                  className="bg-[#0F6466] text-white px-6 py-2 rounded"
                  onClick={handleUpdate}
                >
                  Save Changes
                </button>
                <button
                  className="bg-gray-400 text-white px-6 py-2 rounded"
                  onClick={() => {
                    setUpdateAdmin({});
                    setError(null);
                    setSuccess(null);
                  }}
                >
                  Cancel
                </button>
              </div>
            </>
          )}
        </div>
      )}

      {/* SEARCH + TABLE */}
      <div className="mb-6 flex gap-4">
        <input
          type="text"
          placeholder="Search by CNIC or name..."
          className="border p-3 rounded-lg w-64"
          value={searchTerm}
          onChange={e => setSearchTerm(e.target.value)}
        />
      </div>
      <table className="w-full border-collapse shadow-lg">
        <thead className="bg-[#0F6466] text-white">
          <tr>
            <th className="p-4">
              <input
                type="checkbox"
                onChange={toggleSelectAll}
                checked={selectedAdmins.length === filtered.length && filtered.length > 0}
              />
            </th>
            <th className="p-4">CNIC</th>
            <th className="p-4">First Name</th>
            <th className="p-4">Last Name</th>
            <th className="p-4">Email</th>
            <th className="p-4">Contact</th>
            <th className="p-4">Actions</th>
          </tr>
        </thead>
        <tbody>
          {filtered.map(admin => (
            <tr key={admin._id} className="border-b hover:bg-gray-50">
              <td className="p-4 text-center">
                <input
                  type="checkbox"
                  checked={selectedAdmins.includes(admin._id)}
                  onChange={() => toggleSingleSelect(admin._id)}
                />
              </td>
              <td className="p-4 text-center">{admin.cnic}</td>
              <td className="p-4 text-center">{admin.firstName}</td>
              <td className="p-4 text-center">{admin.lastName}</td>
              <td className="p-4 text-center">{admin.email}</td>
              <td className="p-4 text-center">{admin.contactNumber}</td>
              <td className="p-4 text-center">
                <button
                  onClick={() => handleDelete(admin._id)}
                  className="bg-red-500 text-white px-3 py-1 rounded hover:bg-red-600"
                >
                  Delete
                </button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
