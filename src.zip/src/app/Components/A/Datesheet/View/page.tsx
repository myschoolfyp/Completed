// app/Components/A/Datesheet/View/page.tsx
"use client";
import { useState, useEffect } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import { Trash2, Edit2 } from "lucide-react";

interface ExamSchedule {
  course:    string;
  date:      string;
  startTime: string;
  endTime:   string;
  roomNo?:   string;
}

interface Datesheet {
  _id:           string;
  datesheetName: string;
  className:     string;
  classLevel:    string;
  schedule:      ExamSchedule[];
  createdAt:     string;
}

export default function ViewDatesheets() {
  const [datesheets, setDatesheets] = useState<Datesheet[]>([]);
  const [loading,     setLoading]     = useState(true);
  const [error,       setError]       = useState("");
  const router = useRouter();

  // Load list
  useEffect(() => {
    fetch("/api/Component/A/Datesheet/View")
      .then(res => {
        if (!res.ok) throw new Error(`Status ${res.status}`);
        return res.json();
      })
      .then(setDatesheets)
      .catch(err => setError(err.message))
      .finally(() => setLoading(false));
  }, []);

  // Delete handler
  const handleDelete = async (id: string) => {
    if (!confirm("Delete this datesheet?")) return;
    const res = await fetch("/api/Component/A/Datesheet/View", {
      method: "DELETE",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ datesheetId: id }),
    });
    if (!res.ok) {
      // only parse JSON on error cases
      let errMsg = "Delete failed";
      try {
        const err = await res.json();
        errMsg = err.error || errMsg;
      } catch {}
      alert(errMsg);
      return;
    }
    // success → remove from UI
    setDatesheets(ds => ds.filter(d => d._id !== id));
  };

  if (loading) return <p className="p-8 text-center">Loading…</p>;
  if (error)   return <p className="p-8 text-center text-red-600">{error}</p>;

  const gradients = {
    primary:   "bg-gradient-to-r from-[#0F6466] to-[#2D9F9C]",
    secondary: "bg-gradient-to-r from-[#4C6EF5] to-[#748FFC]",
    purple:    "bg-gradient-to-r from-[#7950F2] to-[#9775FA]",
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-[#f0fdfa] to-[#e0f8f5] p-8">
      <div className="max-w-6xl mx-auto space-y-8">
        <header className={`${gradients.primary} p-6 rounded-2xl shadow-lg flex justify-between items-center`}>
          <div>
            <h1 className="text-4xl font-bold text-white">View Datesheets</h1>
            <p className="text-white/90 mt-1">Manage and review all exam schedules</p>
          </div>
          <button
            onClick={() => router.push("/Components/A/Datesheet/Create")}
            className={`${gradients.secondary} text-white px-5 py-2 rounded-xl shadow-md hover:opacity-90`}
          >
            Create New
          </button>
        </header>

        {datesheets.length === 0 ? (
          <div className="bg-white p-8 rounded-2xl shadow-lg text-center">
            <h3 className="text-2xl font-semibold text-[#0F6466]">No datesheets found</h3>
            <button
              onClick={() => router.push("/Components/A/Datesheet/Create")}
              className={`${gradients.primary} mt-4 text-white px-6 py-2 rounded-xl shadow-md hover:opacity-90`}
            >
              Create Datesheet
            </button>
          </div>
        ) : (
          datesheets.map(ds => (
            <div key={ds._id} className="bg-white rounded-2xl shadow-lg overflow-hidden">
              <div className={`${gradients.secondary} p-4 text-white flex justify-between items-center`}>
                <div>
                  <h3 className="text-2xl font-semibold">{ds.datesheetName}</h3>
                  <p className="opacity-90">{ds.classLevel} — {ds.className}</p>
                </div>
                <div className="text-sm">
                  Created: {new Date(ds.createdAt).toLocaleDateString()}
                </div>
              </div>

              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="bg-gray-50 text-[#0F6466]">
                      <th className="p-3 text-left">Course</th>
                      <th className="p-3 text-left">Date</th>
                      <th className="p-3 text-left">Time</th>
                      <th className="p-3 text-left">Room</th>
                    </tr>
                  </thead>
                  <tbody>
                    {ds.schedule.map((exam, i) => (
                      <tr key={i} className="border-t hover:bg-gray-50">
                        <td className="p-3">{exam.course}</td>
                        <td className="p-3">{new Date(exam.date).toLocaleDateString()}</td>
                        <td className="p-3">
                          {exam.startTime && exam.endTime
                            ? `${exam.startTime} – ${exam.endTime}`
                            : "-"}
                        </td>
                        <td className="p-3">{exam.roomNo || "-"}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>

              <div className="p-4 bg-gray-50 flex justify-end gap-2">
                <button
                  onClick={() => router.push(`/Components/A/Datesheet/Edit?datesheetId=${ds._id}`)}
                  className={`${gradients.purple} text-white px-4 py-2 rounded-lg hover:opacity-90`}
                >
                  <Edit2 className="inline-block mr-1" size={16}/> Edit
                </button>
                <button
                  onClick={() => handleDelete(ds._id)}
                  className="bg-red-500 text-white px-4 py-2 rounded-lg hover:opacity-90"
                >
                  <Trash2 className="inline-block mr-1" size={16}/> Delete
                </button>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
}
