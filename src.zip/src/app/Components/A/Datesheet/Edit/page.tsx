"use client";
import { useState, useEffect } from "react";
import { useRouter, useSearchParams } from "next/navigation";

interface ClassData {
  _id: string;
  className: string;
  classLevel: string;
  courses: string[];
}

export default function EditDatesheet() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const datesheetId = searchParams.get("datesheetId");


  const [datesheetName, setDatesheetName] = useState("");
  const [classes, setClasses] = useState<ClassData[]>([]);
  const [selectedClass, setSelectedClass] = useState<ClassData | null>(null);
  const [examSchedule, setExamSchedule] = useState<any[]>([]);
  const [error, setError] = useState("");
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [success, setSuccess] = useState(false);

  useEffect(() => {
    if (!datesheetId) {
      setError("Missing Datesheet ID");
      return;
    }

    const fetchDatesheet = async () => {
      try {
        const res = await fetch(`/api/Component/A/Datesheet/Edit?id=${datesheetId}`);
        const data = await res.json();
        if (res.ok) {
          setDatesheetName(data.datesheetName);
          setExamSchedule(
            data.schedule.map((exam: any) => ({
              course: exam.course,
              date: exam.date ? new Date(exam.date).toISOString().split('T')[0] : "",
              startTime: exam.startTime || "",
              endTime: exam.endTime || "",
              roomNo: exam.roomNo || "",
            }))
          );
          setSelectedClass({
            _id: data.classId,
            className: data.className,
            classLevel: data.classLevel,
            courses: data.schedule.map((exam: any) => exam.course),
          });
        } else {
          throw new Error(data.error || "Failed to fetch datesheet");
        }
      } catch (err: any) {
        setError(err.message);
      }
    };

    const fetchClasses = async () => {
      try {
        const res = await fetch("/api/Component/A/Datesheet/Create?action=fetchClasses");
        const data = await res.json();
        setClasses(data);
      } catch (err) {
        setError("Failed to fetch classes");
      }
    };

    fetchDatesheet();
    fetchClasses();
  }, [datesheetId]);

  const handleScheduleChange = (index: number, field: string, value: string) => {
    const updatedSchedule = [...examSchedule];
    updatedSchedule[index] = { ...updatedSchedule[index], [field]: value };
    setExamSchedule(updatedSchedule);
  };

  const handleSubmit = async () => {
    setIsSubmitting(true);
    setError("");
    setSuccess(false);

    if (!datesheetName || !selectedClass) {
      setError("Datesheet name and class are required");
      setIsSubmitting(false);
      return;
    }

    try {
      const response = await fetch("/api/Component/A/Datesheet/Edit", {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          datesheetId,
          datesheetName,
          className: selectedClass.className,
          classId: selectedClass._id,
          classLevel: selectedClass.classLevel,
          schedule: examSchedule,
        }),
      });

      const result = await response.json();

      if (!response.ok) {
        throw new Error(result.error || "Failed to update datesheet");
      }

      setSuccess(true);
      setTimeout(() => {
        router.push("/Components/A/Datesheet/View");
      }, 1500);
    } catch (err: any) {
      setError(err.message);
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-[#f0fdfa] to-[#e0f8f5] p-4 md:p-8">
      <div className="max-w-4xl mx-auto">
        <h1 className="text-3xl font-bold mb-6 text-[#0F6466]">Edit Datesheet</h1>

        {error && <p className="text-red-500 mb-4">{error}</p>}

        {selectedClass && (
          <>
            <div className="bg-white rounded-xl shadow-lg p-6 mb-8 border">
              <div className="space-y-6">
                <div>
                  <label className="block mb-2 text-[#0F6466] font-medium">Datesheet Name*</label>
                  <input
                    type="text"
                    className="w-full p-3 border rounded-md"
                    value={datesheetName}
                    onChange={(e) => setDatesheetName(e.target.value)}
                    required
                  />
                </div>

                {/* Exam Schedule */}
                <div>
                  <h3 className="text-lg font-semibold mb-2 text-[#0F6466]">
                    Exam Schedule for {selectedClass.classLevel} - {selectedClass.className}
                  </h3>

                  <div className="space-y-4">
                    {examSchedule.map((exam, index) => (
                      <div key={index} className="grid grid-cols-1 md:grid-cols-5 gap-4 items-center">
                        <span className="font-medium text-[#0F6466]">{exam.course}</span>
                        <input
                          type="date"
                          className="p-2 border rounded-md"
                          value={exam.date}
                          onChange={(e) => handleScheduleChange(index, "date", e.target.value)}
                          required
                        />
                        <input
                          type="time"
                          className="p-2 border rounded-md"
                          value={exam.startTime}
                          onChange={(e) => handleScheduleChange(index, "startTime", e.target.value)}
                          required
                        />
                        <input
                          type="time"
                          className="p-2 border rounded-md"
                          value={exam.endTime}
                          onChange={(e) => handleScheduleChange(index, "endTime", e.target.value)}
                          required
                        />
                        <input
                          type="text"
                          placeholder="Room No"
                          className="p-2 border rounded-md"
                          value={exam.roomNo}
                          onChange={(e) => handleScheduleChange(index, "roomNo", e.target.value)}
                        />
                      </div>
                    ))}
                  </div>
                </div>

                <button
                  onClick={handleSubmit}
                  disabled={isSubmitting}
                  className="bg-gradient-to-r from-[#0F6466] to-[#2D9F9C] text-white px-6 py-3 rounded-md mt-6 hover:opacity-90 transition"
                >
                  {isSubmitting ? "Updating..." : "Update Datesheet"}
                </button>

                {success && <p className="text-green-500 mt-4">Datesheet updated successfully!</p>}
              </div>
            </div>
          </>
        )}
      </div>
    </div>
  );
}
