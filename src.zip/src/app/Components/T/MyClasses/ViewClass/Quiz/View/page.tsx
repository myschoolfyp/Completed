// /Components/T/MyClasses/ViewClass/Quiz/View/page.tsx
"use client";

export default function ViewQuizSubmissions() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-[#fff6f0] to-[#ffe8e3] p-8">
      <div className="max-w-6xl mx-auto">
        <h1 className="text-4xl font-bold text-[#F27121] mb-6">Quiz Submissions</h1>
        <p className="text-lg text-gray-700">
          This is a sample page for viewing student quiz submissions.
        </p>
        <p className="mt-4 text-gray-600 italic">
          Replace this with a table or cards of submitted quizzes per student.
        </p>
      </div>
    </div>
  );
}
