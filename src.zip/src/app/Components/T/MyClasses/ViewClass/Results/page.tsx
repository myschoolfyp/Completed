// app/Components/T/Results/Mark/page.tsx
"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";

interface Datesheet {
  _id: string;
  datesheetName: string;
  className: string;
  classLevel: string;
}

interface ClassSlot {
  className: string;
  course: string;
  teacherId: string;
}

interface Student {
  _id: string;
  rollNo: string;
  firstName: string;
  lastName: string;
}

export default function MarkResults() {
  const router = useRouter();
  const [datesheets, setDatesheets] = useState<Datesheet[]>([]);
  const [selectedDS, setSelectedDS] = useState<Datesheet | null>(null);

  const [classes, setClasses] = useState<ClassSlot[]>([]);
  const [selectedClass, setSelectedClass] = useState<ClassSlot | null>(null);

  const [students, setStudents] = useState<Student[]>([]);
  const [totalMarks, setTotalMarks] = useState<number>(100);
  const [obtained, setObtained] = useState<Record<string, number>>({});

  const [error, setError] = useState("");
  const [saving, setSaving] = useState(false);

  // load datesheets
  useEffect(() => {
    fetch("/api/Component/A/Datesheet/View")
      .then(r => r.json())
      .then(setDatesheets)
      .catch(() => setError("Could not load datesheets"));
  }, []);

  // load teacher's classes
  useEffect(() => {
    const tid = localStorage.getItem("teacherId");
    if (!tid) return;
    fetch(`/api/Component/T/timetable?teacherId=${tid}`)
      .then(r => r.json())
      .then(setClasses)
      .catch(() => {/*silent*/});
  }, []);

  // load students when class chosen
  useEffect(() => {
    if (!selectedClass) return;
    fetch(
      `/api/Component/T/MyClasses/ViewClass/attendance?className=${encodeURIComponent(
        selectedClass.className
      )}`
    )
      .then(r => r.json())
      .then((list: Student[]) => {
        setStudents(list);
        const init: Record<string, number> = {};
        list.forEach(s => (init[s._id] = 0));
        setObtained(init);
      })
      .catch(() => setError("Failed to load students"));
  }, [selectedClass]);

  const gradeOf = (marks: number) => {
    const pct = (marks / totalMarks) * 100;
    if (pct >= 85) return "A+";
    if (pct >= 80) return "A";
    if (pct >= 75) return "B+";
    if (pct >= 70) return "B";
    if (pct >= 65) return "C+";
    if (pct >= 60) return "C";
    if (pct >= 50) return "D";
    return "F";
  };

  const handleSave = async () => {
    if (!selectedDS || !selectedClass || students.length === 0) {
      setError("Please complete all selections and enter marks");
      return;
    }
    setSaving(true);
    setError("");

    if (totalMarks > 100) {
      setError("Total marks cannot exceed 100");
      return;
    }
    for (let s of students) {
      const got = obtained[s._id] || 0;
      if (got > totalMarks) {
        setError(`Obtained marks for ${s.rollNo} can’t exceed ${totalMarks}`);
        return;
      }
    }
    const payload = {
      datesheetId: selectedDS._id,
      datesheetName: selectedDS.datesheetName,
      className: selectedClass.className,
      course: selectedClass.course,
      totalMarks,
      studentResults: students.map(s => ({
        studentId: s._id,
        rollNo: s.rollNo,
        name: `${s.firstName} ${s.lastName}`,
        totalMarks,
        obtainedMarks: obtained[s._id] || 0,
        grade: gradeOf(obtained[s._id] || 0),
      })),
    };

    try {
      const res = await fetch(
        "/api/Component/T/MyClasses/ViewClass/Results",
        {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(payload),
        }
      );
      const j = await res.json();
      if (!res.ok) throw new Error(j.error || "Save failed");
      alert("✅ Results saved");
      router.refresh();
    } catch (e: any) {
      setError(e.message);
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="p-8 max-w-4xl mx-auto space-y-8">
      <h1 className="text-3xl font-bold text-[#0F6466]">
        Mark Exam Results
      </h1>
      {error && <p className="text-red-500">{error}</p>}

      {/* 1) Datesheet */}
      <div>
        <label className="font-medium">Datesheet</label>
        <select
          className="w-full mt-1 p-2 border rounded"
          onChange={e => {
            const ds = datesheets.find(d => d._id === e.target.value) || null;
            setSelectedDS(ds);
            setSelectedClass(null);
            setStudents([]);
          }}
        >
          <option value="">-- select --</option>
          {datesheets.map(ds => (
            <option key={ds._id} value={ds._id}>
              {ds.datesheetName} ({ds.classLevel} – {ds.className})
            </option>
          ))}
        </select>
      </div>

      {/* 2) Class & Course */}
      {selectedDS && (
        <div>
          <label className="font-medium">Class & Course</label>
          <select
            className="w-full mt-1 p-2 border rounded"
            onChange={e => {
              const idx = Number(e.target.value);
              setSelectedClass(classes[idx] || null);
            }}
          >
            <option value="">-- select --</option>
            {classes.map((c, i) => (
              <option key={i} value={i}>
                {c.className} — {c.course}
              </option>
            ))}
          </select>
        </div>
      )}

      {/* 3) Result Details Summary */}
      {selectedDS && selectedClass && (
        <div className="bg-white p-4 rounded shadow">
          <h2 className="font-semibold mb-2">Result Details</h2>
          <p>
            <strong>Datesheet:</strong> {selectedDS.datesheetName}
          </p>
          <p>
            <strong>Class:</strong> {selectedClass.className}
          </p>
          <p>
            <strong>Course:</strong> {selectedClass.course}
          </p>
          <div className="mt-2">
            <label className="font-medium">Total Marks</label>
            <input
              type="number"
              min={1}
              max={100} 
              className="w-32 ml-2 p-1 border rounded"
              value={totalMarks}
              onChange={e => setTotalMarks(Number(e.target.value))}
            />
          </div>
        </div>
      )}

      {/* 4) Students table */}
      {students.length > 0 && selectedClass && (
        <div className="overflow-x-auto">
          <table className="w-full text-sm border-collapse">
            <thead>
              <tr className="bg-[#0F6466] text-white">
                <th className="p-2">Roll No</th>
                <th className="p-2">Name</th>
                <th className="p-2">Obtained</th>
                <th className="p-2">Grade</th>
              </tr>
            </thead>
            <tbody>
              {students.map(s => (
                <tr key={s._id} className="border-b">
                  <td className="p-2 text-center">{s.rollNo}</td>
                  <td className="p-2">
                    {s.firstName} {s.lastName}
                  </td>
                  <td className="p-2 text-center">
                    <input
                      type="number"
                      min={0}
                      max={totalMarks}
                      className="w-20 p-1 border rounded text-center"
                      value={obtained[s._id] || 0}
                      onChange={e => {
                        const v = Number(e.target.value) || 0;
                        setObtained(prev => ({ ...prev, [s._id]: v }));
                      }}
                    />
                  </td>
                  <td className="p-2 text-center">
                    {gradeOf(obtained[s._id] || 0)}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
          <button
            onClick={handleSave}
            disabled={saving}
            className="mt-4 bg-[#0F6466] text-white px-6 py-2 rounded hover:bg-[#0D4B4C]"
          >
            {saving ? "Saving…" : "Save Results"}
          </button>
        </div>
      )}
    </div>
  );
}
