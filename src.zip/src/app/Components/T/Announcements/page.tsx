// src/app/Component/T/Announcements/page.tsx
"use client";

import { useState, useEffect } from "react";

interface Reply {
  senderCnic: string;
  senderName: string;
  description: string;
  date: string;
}

interface Announcement {
  _id: string;
  description: string;
  date: string;
  replies: Reply[];
}

export default function TeacherAnnouncements() {
  const [cnic, setCnic] = useState<string>("");
  const [name, setName] = useState<string>("");
  const [announcements, setAnnouncements] = useState<Announcement[]>([]);
  const [replyText, setReplyText] = useState<Record<string, string>>({});

  // 1) Load from the *same* localStorage keys your profile page uses
  useEffect(() => {
    const storedCnic = localStorage.getItem("cnic") || "";
    const firstName = localStorage.getItem("firstName") || "";
    const lastName = localStorage.getItem("lastName") || "";
    console.log("[Announcements] loaded:", { storedCnic, firstName, lastName });

    setCnic(storedCnic);
    setName(firstName && lastName ? `${firstName} ${lastName}` : "");
  }, []);

  // 2) Fetch only once we have a cnic
  useEffect(() => {
    console.log("[Announcements] CNIC state:", cnic);
    if (!cnic) {
      console.warn("[Announcements] No CNIC found—won't fetch announcements");
      return;
    }

    const url = `/api/Component/T/Announcements?stream=teachers&recipient=${cnic}`;
    console.log("[Announcements] fetching from:", url);

    fetch(url)
      .then(res => {
        console.log("[Announcements] fetch status:", res.status);
        return res.json();
      })
      .then((data: Announcement[]) => {
        console.log("[Announcements] received:", data);
        setAnnouncements(data);
      })
      .catch(err => {
        console.error("[Announcements] fetch error:", err);
      });
  }, [cnic]);

  // 3) Send a reply
  const sendReply = async (annId: string) => {
    const text = (replyText[annId] || "").trim();
    if (!text) {
      alert("Reply cannot be empty");
      return;
    }

    const payload = {
      annId,
      senderCnic: cnic,
      senderName: name,
      description: text,
    };
    console.log("[Announcements] POST payload:", payload);

    const res = await fetch("/api/Component/T/Announcements", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload),
    });
    console.log("[Announcements] POST status:", res.status);

    if (!res.ok) {
      const err = await res.text();
      console.error("[Announcements] POST failed:", err);
      alert("Failed to send reply");
      return;
    }

    const newReply: Reply = await res.json();
    setAnnouncements(curr =>
      curr.map(a =>
        a._id === annId ? { ...a, replies: [...a.replies, newReply] } : a
      )
    );
    setReplyText(prev => ({ ...prev, [annId]: "" }));
  };

  return (
    <div className="p-6 space-y-6 bg-white rounded-lg shadow">
      <h1 className="text-2xl font-semibold">Announcements</h1>

      {/* Display CNIC & name for verification */}
      {!cnic ? (
        <div className="text-red-500">
          No CNIC found in localStorage. Please log in again.
        </div>
      ) : (
        <div className="text-gray-700">
          Logged in as <strong>{name || "(no name)"}</strong>, CNIC:{" "}
          <strong>{cnic}</strong>
        </div>
      )}

      {announcements.length === 0 && cnic && (
        <div className="text-gray-500">No announcements yet.</div>
      )}

      {announcements.map(ann => (
        <div key={ann._id} className="border p-4 rounded-lg space-y-3">
          <div className="text-sm text-gray-500">
            {new Date(ann.date).toLocaleString()}
          </div>
          <div className="font-medium">{ann.description}</div>

          {ann.replies.length > 0 && (
            <div className="space-y-2 pl-4 border-l">
              <div className="text-gray-600">Replies:</div>
              {ann.replies.map((r, i) => (
                <div key={i} className="text-sm">
                  <span className="italic">
                    [{new Date(r.date).toLocaleString()}]{" "}
                    <strong>{r.senderName}:</strong>
                  </span>{" "}
                  {r.description}
                </div>
              ))}
            </div>
          )}

          <div className="flex gap-2">
            <textarea
              rows={2}
              className="flex-1 border p-2 rounded-lg"
              placeholder="Write your reply..."
              value={replyText[ann._id] || ""}
              onChange={e =>
                setReplyText(t => ({ ...t, [ann._id]: e.target.value }))
              }
            />
            <button
              onClick={() => sendReply(ann._id)}
              className="bg-blue-600 hover:bg-blue-700 text-white px-4 rounded-lg"
            >
              Reply
            </button>
          </div>
        </div>
      ))}
    </div>
  );
}
