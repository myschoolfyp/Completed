// app/Components/P/Timetable/page.tsx
"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";

interface Period {
  time: string;
  subject: string;
  teacher: string;
  room: string;
}

interface TimetableDay {
  day: string;
  periods: Period[];
}

interface ChildWithTimetable {
  _id: string;
  firstName: string;
  lastName: string;
  className: string;
  timetable: TimetableDay[];
  error?: string;
}

export default function ParentTimetable() {
  const router = useRouter();
  const [parentName, setParentName] = useState("");
  const [children, setChildren] = useState<ChildWithTimetable[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [selectedIdx, setSelectedIdx] = useState(0);

  const cnic = typeof window !== "undefined" ? localStorage.getItem("cnic") : null;

  useEffect(() => {
    if (!cnic) {
      router.push("/Components/Login");
      return;
    }
    const fetchAll = async () => {
      try {
        const res = await fetch(
          `/api/Component/P/Timetable?cnic=${encodeURIComponent(cnic!)}`
        );
        if (!res.ok) {
          const err = await res.json();
          throw new Error(err.error || "Failed to load timetables");
        }
        const data = await res.json();
        setParentName(data.parentName);
        setChildren(data.children);
      } catch (err: any) {
        setError(err.message);
      } finally {
        setLoading(false);
      }
    };
    fetchAll();
  }, [cnic, router]);

  const dayGradients = [
    "from-[#0F6466] to-[#2D9F9C]",
    "from-[#4C6EF5] to-[#748FFC]",
    "from-[#7950F2] to-[#9775FA]",
    "from-[#F76707] to-[#FF922B]",
    "from-[#E64980] to-[#F783AC]",
  ];

  if (loading)
    return (
      <div className="text-center p-8 text-xl text-[#0F6466] animate-pulse">
        Loading timetables…
      </div>
    );
  if (error)
    return (
      <div className="text-red-500 text-center p-8">
        ⚠️ {error}
      </div>
    );
  if (children.length === 0)
    return (
      <div className="text-center p-8 text-gray-500">
        No children found.
      </div>
    );

  const active = children[selectedIdx];

  return (
    <div className="min-h-screen bg-gradient-to-br from-[#f0fdfa] to-[#e0f8f5] p-6">
      <div className="max-w-4xl mx-auto">
        <h1 className="text-3xl font-bold text-[#0F6466] mb-4 text-center">
          {parentName}’s Children Timetables
        </h1>

        {/* Tabs */}
        <div className="flex justify-center space-x-4 mb-8">
          {children.map((child, idx) => (
            <button
              key={child._id}
              onClick={() => setSelectedIdx(idx)}
              className={`px-4 py-2 rounded-full font-medium ${
                idx === selectedIdx
                  ? "bg-[#0F6466] text-white shadow-lg"
                  : "bg-white text-[#0F6466] border border-[#0F6466]/20"
              } transition`}
            >
              {child.firstName} {child.lastName}
            </button>
          ))}
        </div>

        {/* Timetable for selected child */}
        {active.error ? (
          <div className="text-center text-red-500">
            Could not load timetable for {active.firstName}.
          </div>
        ) : (
          <div>
            <h2 className="text-2xl font-semibold text-[#0F6466] mb-6 text-center">
              {active.firstName} {active.lastName} — {active.className}
            </h2>
            <div className="grid grid-cols-1 md:grid-cols-5 gap-4">
              {active.timetable.map((daySchedule, i) => (
                <div
                  key={daySchedule.day}
                  className={`rounded-xl p-4 shadow-lg border border-white/20
                              hover:shadow-xl transition-all duration-300
                              bg-gradient-to-br ${dayGradients[i % dayGradients.length]}
                              text-white backdrop-blur-sm`}
                >
                  <h3 className="text-lg font-semibold mb-3">
                    {daySchedule.day}
                  </h3>
                  <div className="space-y-2">
                    {daySchedule.periods.map((period) => (
                      <div
                        key={period.time}
                        className="p-3 rounded-lg bg-white/20 backdrop-blur-sm border border-white/20"
                      >
                        <div className="flex justify-between items-start mb-2">
                          <span className="text-sm font-medium">
                            {period.time}
                          </span>
                          <span className="text-sm bg-white/20 px-2 py-1 rounded">
                            {period.room}
                          </span>
                        </div>
                        <p className="font-medium">{period.subject}</p>
                        <p className="text-sm opacity-90">{period.teacher}</p>
                      </div>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
