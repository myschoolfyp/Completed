// app/Components/P/Courses/page.tsx
"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";

// same gradients as student version
const courseGradients = [
  "from-[#0F6466] to-[#2D9F9C]",
  "from-[#4C6EF5] to-[#748FFC]",
  "from-[#7950F2] to-[#9775FA]",
  "from-[#F76707] to-[#FF922B]",
  "from-[#E64980] to-[#F783AC]",
  "from-[#2F9E44] to-[#69DB7C]",
  "from-[#D6336C] to-[#F06595]",
  "from-[#1864AB] to-[#4DABF7]",
];

interface ChildWithCourses {
  _id: string;
  firstName: string;
  lastName: string;
  className: string;
  courses: string[];
  error?: string;
}

export default function ParentCourses() {
  const router = useRouter();
  const [parentName, setParentName] = useState("");
  const [children, setChildren] = useState<ChildWithCourses[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [selectedIdx, setSelectedIdx] = useState(0);

  const cnic =
    typeof window !== "undefined" ? localStorage.getItem("cnic") : null;

  useEffect(() => {
    if (!cnic) {
      router.push("/Components/Login");
      return;
    }
    const fetchAll = async () => {
      try {
        const res = await fetch(
          `/api/Component/P/Courses?cnic=${encodeURIComponent(cnic!)}`
        );
        if (!res.ok) {
          const err = await res.json();
          throw new Error(err.error || "Failed to load courses");
        }
        const data = await res.json();
        setParentName(data.parentName);
        setChildren(data.children);
      } catch (err: any) {
        setError(err.message);
      } finally {
        setLoading(false);
      }
    };
    fetchAll();
  }, [cnic, router]);

  if (loading)
    return (
      <div className="text-center p-8 text-xl text-[#0F6466] animate-pulse">
        Loading courses…
      </div>
    );
  if (error)
    return (
      <div className="text-red-500 text-center p-8">
        ⚠️ {error}
      </div>
    );
  if (children.length === 0)
    return (
      <div className="text-center p-8 text-gray-500">
        No children found.
      </div>
    );

  const active = children[selectedIdx];

  return (
    <div className="min-h-screen bg-gradient-to-br from-[#f0fdfa] to-[#e0f8f5] p-6">
      <div className="max-w-4xl mx-auto">
        <h1 className="text-3xl font-bold text-[#0F6466] mb-6 text-center">
          {parentName}’s Children Courses
        </h1>

        <div className="flex justify-center space-x-4 mb-8">
          {children.map((child, idx) => (
            <button
              key={child._id}
              onClick={() => setSelectedIdx(idx)}
              className={`px-4 py-2 rounded-full font-medium ${
                idx === selectedIdx
                  ? "bg-[#0F6466] text-white shadow-lg"
                  : "bg-white text-[#0F6466] border border-[#0F6466]/20"
              } transition`}
            >
              {child.firstName} {child.lastName}
            </button>
          ))}
        </div>

        {active.error ? (
          <div className="text-center text-red-500">
            Could not load courses for {active.firstName}.
          </div>
        ) : (
          <div>
            <div className="flex flex-col md:flex-row justify-between items-center mb-6">
              <h2 className="text-2xl font-semibold text-[#0F6466] mb-2 md:mb-0">
                {active.firstName} {active.lastName} — {active.className}
              </h2>
              <div className="bg-white px-6 py-2 rounded-full shadow-md flex items-center">
                <span className="text-[#0F6466] font-medium mr-2">
                  Total Courses:
                </span>
                <span className="text-2xl font-bold text-[#2D9F9C]">
                  {active.courses.length}
                </span>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
              {active.courses.map((course, idx) => (
                <div
                  key={idx}
                  className={`rounded-2xl p-8 min-h-[180px] flex items-center justify-center
                    transform transition-all duration-300 hover:scale-105 hover:shadow-xl
                    bg-gradient-to-br ${courseGradients[idx % courseGradients.length]}
                    shadow-md backdrop-blur-sm border border-white/20`}
                >
                  <div className="text-center">
                    <p className="text-2xl font-bold text-white mb-2">
                      {course.split("-")[0].trim()}
                    </p>
                    <p className="text-white/90 font-medium">
                      Code: {course.split("-")[1]?.trim() ?? "N/A"}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
