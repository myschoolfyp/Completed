"use client";
import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';

interface Student {
  _id: string;
  rollNo: string;
  firstName: string;
  lastName: string;
  classLevel: string;
  className: string;
  classType: string;
}

export default function Children() {
  const router = useRouter();
  const [parentName, setParentName] = useState('');
  const [students, setStudents] = useState<Student[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    const fetchParent = async () => {
      try {
        const cnic = localStorage.getItem('cnic');
        
        if (!cnic) {
          router.push('/Components/Login');
          return;
        }

        const response = await fetch(
          `/api/Component/P/Children?cnic=${encodeURIComponent(cnic)}`
        );
        
        if (!response.ok) {
          throw new Error('Failed to fetch data');
        }

        const data = await response.json();
        console.log('API Response:', data);
        setParentName(data.parentName);
        setStudents(data.students || []);
        setLoading(false);

      } catch (err) {
        setError(
          err instanceof Error 
            ? err.message 
            : 'Failed to load information'
        );
        setLoading(false);
      }
    };

    fetchParent();
  }, [router]);

  if (loading) return (
    <div className="text-center mt-8 animate-pulse">
      <div className="h-8 bg-[#0F6466]/20 rounded w-48 mx-auto mb-4"></div>
      <div className="h-4 bg-[#0F6466]/10 rounded w-32 mx-auto"></div>
    </div>
  );

  if (error) return (
    <div className="text-red-500 text-center mt-8 max-w-md mx-auto p-4 bg-red-50 rounded-lg border border-red-200">
      ⚠️ {error}
    </div>
  );

  return (
    <div className="min-h-screen bg-gradient-to-br from-[#0F6466]/90 to-[#0D4B4C]/90 p-8">
      <div className="max-w-4xl mx-auto bg-white rounded-xl shadow-2xl p-8">
       
        <section className="space-y-6">
          <h2 className="text-2xl font-bold text-[#0F6466] border-b pb-2">Children's Details</h2>
          
          {students.length === 0 ? (
            <div className="text-center p-8 bg-gray-50 rounded-xl">
              <p className="text-gray-500">No children registered yet</p>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {students.map((student) => (
                <div 
                  key={student._id} 
                  className="relative p-8 bg-gradient-to-br from-[#0F6466]/10 to-[#0D4B4C]/20 rounded-2xl border-2 border-[#0F6466]/20 hover:border-[#0F6466]/30 transition-all duration-300 group"
                >
                  {/* Student Header */}
                  <div className="text-center mb-6">
                    <h3 className="text-2xl font-bold text-[#0F6466] mb-1">
                      {student.firstName} {student.lastName}
                    </h3>
                    <span className="text-sm font-medium text-[#0D4B4C] bg-[#0F6466]/10 px-3 py-1 rounded-full">
                      {student.classType}
                    </span>
                  </div>
                  
                  {/* Student Details */}
                  <div className="space-y-3">
                    <div className="flex justify-between items-center p-3 bg-white/50 rounded-lg shadow-sm">
                      <span className="font-medium text-[#0F6466]">Roll Number</span>
                      <span className="text-gray-700 font-semibold">{student.rollNo}</span>
                    </div>
                    <div className="flex justify-between items-center p-3 bg-white/50 rounded-lg shadow-sm">
                      <span className="font-medium text-[#0F6466]">Class Level</span>
                      <span className="text-gray-700 font-semibold">{student.classLevel}</span>
                    </div>
                    <div className="flex justify-between items-center p-3 bg-white/50 rounded-lg shadow-sm">
                      <span className="font-medium text-[#0F6466]">Class Name</span>
                      <span className="text-gray-700 font-semibold">{student.className}</span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </section>
      </div>
    </div>
  );
}