"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";

interface ChildResult {
  _id: string;
  firstName: string;
  lastName: string;
  className: string;
  rollNo: string;
  results: Array<{
    datesheetName: string;
    course: string;
    date: string;
    totalMarks: number;
    obtainedMarks: number;
    grade: string;
  }>;
}

export default function ParentResults() {
  const router = useRouter();
  const [parentName, setParentName] = useState("");
  const [children, setChildren] = useState<ChildResult[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [childIdx, setChildIdx] = useState(0);

  const cnic =
    typeof window !== "undefined" ? localStorage.getItem("cnic") : null;

  useEffect(() => {
    if (!cnic) {
      router.push("/Components/Login");
      return;
    }
    const fetchResults = async () => {
      try {
        const res = await fetch(
          `/api/Component/P/Results?cnic=${encodeURIComponent(cnic!)}`
        );
        if (!res.ok) {
          const err = await res.json();
          throw new Error(err.error || "Failed to load results");
        }
        const data = await res.json();
        setParentName(data.parentName);
        setChildren(data.children);
      } catch (err: any) {
        setError(err.message);
      } finally {
        setLoading(false);
      }
    };
    fetchResults();
  }, [cnic, router]);

  if (loading)
    return (
      <div className="text-center p-8 text-xl text-[#0F6466] animate-pulse">
        Loading results…
      </div>
    );
  if (error)
    return (
      <div className="text-red-500 text-center p-8">⚠️ {error}</div>
    );
  if (children.length === 0)
    return (
      <div className="text-center p-8 text-gray-500">
        No children found.
      </div>
    );

  const child = children[childIdx];

  return (
    <div className="min-h-screen bg-gradient-to-br from-[#f0fdfa] to-[#e0f8f5] p-6">
      <div className="max-w-4xl mx-auto">
        <h1 className="text-3xl font-bold text-[#0F6466] mb-6 text-center">
          {parentName}’s Children Results
        </h1>

        {/* Child Tabs */}
        <div className="flex justify-center space-x-4 mb-8">
          {children.map((c, i) => (
            <button
              key={c._id}
              onClick={() => setChildIdx(i)}
              className={`px-4 py-2 rounded-full font-medium ${
                i === childIdx
                  ? "bg-[#0F6466] text-white shadow-lg"
                  : "bg-white text-[#0F6466] border border-[#0F6466]/20"
              } transition`}
            >
              {c.firstName} {c.lastName}
            </button>
          ))}
        </div>

        {/* Results Table */}
        {child.results.length === 0 ? (
          <div className="text-center p-8 text-gray-500">
            No results found for {child.firstName}.
          </div>
        ) : (
          <div className="bg-white rounded-lg shadow-md overflow-hidden">
            <table className="w-full">
              <thead className="bg-[#0F6466] text-white">
                <tr>
                  <th className="px-4 py-3">Datesheet</th>
                  <th className="px-4 py-3">Course</th>
                  <th className="px-4 py-3">Date</th>
                  <th className="px-4 py-3">Total</th>
                  <th className="px-4 py-3">Obtained</th>
                  <th className="px-4 py-3">Grade</th>
                </tr>
              </thead>
              <tbody>
                {child.results.map((r, idx) => (
                  <tr key={idx} className="border-b even:bg-gray-50">
                    <td className="px-4 py-3">{r.datesheetName}</td>
                    <td className="px-4 py-3">{r.course}</td>
                    <td className="px-4 py-3 text-center">
                      {new Date(r.date).toLocaleDateString()}
                    </td>
                    <td className="px-4 py-3 text-center">{r.totalMarks}</td>
                    <td className="px-4 py-3 text-center">{r.obtainedMarks}</td>
                    <td className="px-4 py-3 text-center font-semibold">
                      {r.grade}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}
