// app/Components/P/Datesheet/page.tsx
"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";

interface ExamSchedule {
  course: string;
  date: string;
  startTime: string;
  endTime: string;
  roomNo?: string;
}

interface Datesheet {
  _id: string;
  datesheetName: string;
  className: string;
  classLevel: string;
  schedule: ExamSchedule[];
  createdAt: string;
}

interface ChildBlock {
  _id: string;
  firstName: string;
  lastName: string;
  className: string;
  datesheets: Datesheet[];
}

export default function ParentDatesheet() {
  const router = useRouter();
  const [parentName, setParentName] = useState("");
  const [children, setChildren] = useState<ChildBlock[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [selectedIdx, setSelectedIdx] = useState(0);

  const cnic =
    typeof window !== "undefined" ? localStorage.getItem("cnic") : null;

  useEffect(() => {
    if (!cnic) {
      router.push("/Components/Login");
      return;
    }
    fetch(`/api/Component/P/Datesheet?cnic=${encodeURIComponent(cnic)}`)
      .then((res) => res.json())
      .then((data) => {
        if (data.error) throw new Error(data.error);
        setParentName(data.parentName);
        setChildren(data.children);
      })
      .catch((e) => setError(e.message))
      .finally(() => setLoading(false));
  }, [cnic, router]);

  const gradients = {
    primary: "bg-gradient-to-r from-[#0F6466] to-[#2D9F9C]",
    secondary: "bg-gradient-to-r from-[#4C6EF5] to-[#748FFC]",
    purple: "bg-gradient-to-r from-[#7950F2] to-[#9775FA]",
  };

  if (loading)
    return (
      <div className="min-h-screen bg-gradient-to-br from-[#f0fdfa] to-[#e0f8f5] p-8 flex items-center justify-center">
        <div className="animate-pulse text-[#0F6466] text-xl">
          Loading datesheets…
        </div>
      </div>
    );

  if (error)
    return (
      <div className="min-h-screen bg-gradient-to-br from-[#f0fdfa] to-[#e0f8f5] p-8 flex items-center justify-center">
        <div className="text-red-500 text-xl">{error}</div>
      </div>
    );

  if (children.length === 0)
    return (
      <div className="min-h-screen bg-gradient-to-br from-[#f0fdfa] to-[#e0f8f5] p-8 flex items-center justify-center">
        <div className="text-gray-500 text-xl">No children found.</div>
      </div>
    );

  const child = children[selectedIdx];

  return (
    <div className="min-h-screen bg-gradient-to-br from-[#f0fdfa] to-[#e0f8f5] p-4 md:p-8">
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <div className={`${gradients.primary} p-6 rounded-2xl shadow-lg mb-8`}>
          <div className="flex flex-col md:flex-row justify-between items-center">
            <div>
              <h1 className="text-3xl md:text-4xl font-bold text-white">
                {parentName}’s Children Datesheets
              </h1>
              <p className="text-white/90 mt-2">
                Select a child to view their exam schedule.
              </p>
            </div>
          </div>
        </div>

        {/* Child Tabs */}
        <div className="flex justify-center space-x-4 mb-8">
          {children.map((c, i) => (
            <button
              key={c._id}
              onClick={() => setSelectedIdx(i)}
              className={`px-4 py-2 rounded-full font-medium ${
                i === selectedIdx
                  ? "bg-[#0F6466] text-white shadow-lg"
                  : "bg-white text-[#0F6466] border border-[#0F6466]/20"
              } transition`}
            >
              {c.firstName} {c.lastName}
            </button>
          ))}
        </div>

        {/* Child Datesheets */}
        {child.datesheets.length === 0 ? (
          <div className="bg-white rounded-2xl shadow-lg p-8 text-center">
            <h3 className="text-xl text-[#0F6466] mb-2">
              No datesheets for {child.firstName}
            </h3>
            <p className="text-gray-600">
              There is no examination schedule available for{" "}
              {child.className}.
            </p>
          </div>
        ) : (
          child.datesheets.map((ds) => (
            <div
              key={ds._id}
              className="bg-white rounded-2xl shadow-lg overflow-hidden mb-8"
            >
              <div className={`${gradients.secondary} p-4 text-white`}>
                <div className="flex justify-between items-center">
                  <div>
                    <h3 className="text-xl font-semibold">
                      {ds.datesheetName}
                    </h3>
                    <p className="opacity-90">
                      {ds.classLevel} – {ds.className}
                    </p>
                  </div>
                  <div className="text-sm">
                    Created: {new Date(ds.createdAt).toLocaleDateString()}
                  </div>
                </div>
              </div>

              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="bg-gray-50 text-[#0F6466]">
                      <th className="p-3 text-left">Course</th>
                      <th className="p-3 text-left">Date</th>
                      <th className="p-3 text-left">Time</th>
                      <th className="p-3 text-left">Room</th>
                    </tr>
                  </thead>
                  <tbody>
                    {ds.schedule.map((exam, idx) => (
                      <tr
                        key={idx}
                        className="border-t border-gray-100 hover:bg-gray-50"
                      >
                        <td className="p-3">{exam.course}</td>
                        <td className="p-3">
                          {new Date(exam.date).toLocaleDateString()}
                        </td>
                        <td className="p-3">
                          {exam.startTime && exam.endTime
                            ? `${exam.startTime} – ${exam.endTime}`
                            : "-"}
                        </td>
                        <td className="p-3">{exam.roomNo || "-"}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
}
