// app/Components/S/Datesheets/page.tsx
"use client";
import { useState, useEffect } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";

interface ExamSchedule {
  course: string;
  date: Date;
  startTime: string;
  endTime: string;
  roomNo?: string;
}

interface Datesheet {
  _id: string;
  datesheetName: string;
  className: string;
  classLevel: string;
  classId: string;
  schedule: ExamSchedule[];
  createdAt: Date;
}

export default function StudentDatesheets() {
  const [datesheets, setDatesheets] = useState<Datesheet[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const router = useRouter();

  useEffect(() => {
    const className = localStorage.getItem("className");
    if (!className) {
      setError("Class information not found in local storage.");
      setLoading(false);
      return;
    }

    const fetchDatesheets = async () => {
      try {
        const response = await fetch(
          `/api/Component/S/Datesheets?className=${encodeURIComponent(className)}`
        );
        if (!response.ok) {
          throw new Error("Failed to fetch datesheets");
        }
        const data = await response.json();
        setDatesheets(data);
      } catch (err: any) {
        setError(err instanceof Error ? err.message : "An error occurred");
      } finally {
        setLoading(false);
      }
    };

    fetchDatesheets();
  }, []);

  const gradients = {
    primary: "bg-gradient-to-r from-[#0F6466] to-[#2D9F9C]",
    secondary: "bg-gradient-to-r from-[#4C6EF5] to-[#748FFC]",
    purple: "bg-gradient-to-r from-[#7950F2] to-[#9775FA]",
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-[#f0fdfa] to-[#e0f8f5] p-8 flex items-center justify-center">
        <div className="animate-pulse text-[#0F6466] text-xl">Loading datesheets...</div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-[#f0fdfa] to-[#e0f8f5] p-8 flex items-center justify-center">
        <div className="text-red-500 text-xl">{error}</div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-[#f0fdfa] to-[#e0f8f5] p-4 md:p-8">
      <div className="max-w-6xl mx-auto">
        <div className={`${gradients.primary} p-6 rounded-2xl shadow-lg mb-8`}>
          <div className="flex justify-between items-center">
            <div>
              <h1 className="text-3xl md:text-4xl font-bold text-white">View Datesheets</h1>
              <p className="text-white/90 mt-2">
                Your examination schedule for{" "}
                {localStorage.getItem("className")}
              </p>
            </div>
            {/* Optionally, you can include a button for additional actions */}
          </div>
        </div>

        <div className="space-y-6">
          {datesheets.length === 0 ? (
            <div className="bg-white rounded-2xl shadow-lg p-8 text-center">
              <h3 className="text-xl text-[#0F6466] mb-2">No datesheets found</h3>
              <p className="text-gray-600 mb-4">
                There is no examination schedule available for your class.
              </p>
            </div>
          ) : (
            datesheets.map((datesheet) => (
              <div key={datesheet._id} className="bg-white rounded-2xl shadow-lg overflow-hidden">
                <div className={`${gradients.secondary} p-4 text-white`}>
                  <div className="flex justify-between items-center">
                    <div>
                      <h3 className="text-xl font-semibold">{datesheet.datesheetName}</h3>
                      <p className="opacity-90">
                        {datesheet.classLevel} - {datesheet.className}
                      </p>
                    </div>
                    <div className="text-sm">
                      Created: {new Date(datesheet.createdAt).toLocaleDateString()}
                    </div>
                  </div>
                </div>

                <div className="overflow-x-auto">
                  <table className="w-full text-sm">
                    <thead>
                      <tr className="bg-gray-50 text-[#0F6466]">
                        <th className="p-3 text-left">Course</th>
                        <th className="p-3 text-left">Date</th>
                        <th className="p-3 text-left">Time</th>
                        <th className="p-3 text-left">Room</th>
                      </tr>
                    </thead>
                    <tbody>
                      {datesheet.schedule.map((exam, index) => (
                        <tr key={index} className="border-t border-gray-100 hover:bg-gray-50">
                          <td className="p-3">{exam.course}</td>
                          <td className="p-3">{new Date(exam.date).toLocaleDateString()}</td>
                          <td className="p-3">
                            {exam.startTime && exam.endTime
                              ? `${exam.startTime} - ${exam.endTime}`
                              : "-"}
                          </td>
                          <td className="p-3">{exam.roomNo || "-"}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>

                {/* Optionally, you can add action buttons like Edit/Delete here if needed */}
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
}
