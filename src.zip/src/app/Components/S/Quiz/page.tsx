// src/app/Components/S/Quiz/Select/page.tsx
"use client";

import React, { useEffect, useState } from "react";
import Link from "next/link";

// gradient classes
const courseGradients = [
  "from-[#0F6466] to-[#2D9F9C]",
  "from-[#4C6EF5] to-[#748FFC]",
  "from-[#7950F2] to-[#9775FA]",
  "from-[#F76707] to-[#FF922B]",
  "from-[#E64980] to-[#F783AC]",
  "from-[#2F9E44] to-[#69DB7C]",
  "from-[#D6336C] to-[#F06595]",
  "from-[#1864AB] to-[#4DABF7]",
];

interface ClassCourse {
  className: string;
  course: string;
}

interface QuizWithStatus {
  _id: string;
  quizTitle: string;
  description?: string;
  totalMarks: number;
  questionCount?: number;
  deadline: string;
  mode: "online";
  quizFile?: { fileName: string };
  submitted: boolean;
}

export default function StudentQuizzes() {
  // student info
  const [className, setClassName] = useState("");
  const [rollNo, setRollNo]       = useState("");
  // UI state
  const [courses, setCourses]     = useState<string[]>([]);
  const [selectedCourse, setSelectedCourse] = useState<ClassCourse | null>(null);
  const [quizzes, setQuizzes]     = useState<QuizWithStatus[]>([]);
  const [loading, setLoading]     = useState(false);
  const [error, setError]         = useState("");

  // 1) load student info once
  useEffect(() => {
    if (typeof window === "undefined") return;
    const cn = localStorage.getItem("className");
    const lvl = localStorage.getItem("classLevel");
    const typ = localStorage.getItem("classType");
    setClassName(
      cn ?? (lvl && typ ? `Grade ${lvl} ${typ}` : "")
    );
    setRollNo(localStorage.getItem("rollNo") ?? "");
  }, []);

  // 2) fetch courses after className+rollNo
  useEffect(() => {
    if (!className || !rollNo) return;
    setError("");
    fetch(`/api/Component/S/Courses?className=${encodeURIComponent(className)}`)
      .then(r => {
        if (!r.ok) throw new Error("Courses fetch failed");
        return r.json();
      })
      .then((data: { courses: string[] }) => setCourses(data.courses))
      .catch(e => setError(e.message));
  }, [className, rollNo]);

  // 3) pickCourse now passes the full rawCourse, not just the first segment
  const pickCourse = (rawCourse: string) => {
    setSelectedCourse({ className, course: rawCourse });
    setLoading(true);
    setError("");

    fetch(
      `/api/Component/S/Quiz?` +
      `className=${encodeURIComponent(className)}` +
      `&course=${encodeURIComponent(rawCourse.trim())}` +
      `&rollNo=${encodeURIComponent(rollNo)}`
    )
      .then(r => {
        if (!r.ok) throw new Error(`Fetch failed: ${r.statusText}`);
        return r.json();
      })
      .then((data: { quizzes: QuizWithStatus[] }) => {
        setQuizzes(data.quizzes);
      })
      .catch(e => setError(e.message))
      .finally(() => setLoading(false));
  };

  const pending   = quizzes.filter(q => !q.submitted);
  const completed = quizzes.filter(q => q.submitted);

  return (
    <div className="min-h-screen p-6 bg-gradient-to-br from-[#f0fdfa] to-[#e0f8f5]">
      <div className="max-w-6xl mx-auto">
        {!selectedCourse ? (
          <>
            <h1 className="text-3xl font-bold text-[#0F6466] mb-6">
              {className} — Select Course
            </h1>
            {error && <p className="text-red-600 mb-4">{error}</p>}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
              {courses.map((c,i) => (
                <button
                  key={i}
                  onClick={() => pickCourse(c)}
                  className={`rounded-xl p-6 flex items-center justify-center
                    transform hover:scale-105 transition
                    bg-gradient-to-br ${courseGradients[i % courseGradients.length]}
                    text-white font-medium text-center`}
                >
                  <div>
                    <p className="text-lg">{c.split("-")[0].trim()}</p>
                    <p className="text-sm opacity-90">{c.split("-")[1]?.trim()}</p>
                  </div>
                </button>
              ))}
            </div>
          </>
        ) : (
          <>
            <button
              onClick={() => { setSelectedCourse(null); setQuizzes([]); }}
              className="mb-6 px-4 py-2 bg-[#0F6466] text-white rounded-lg"
            >
              ← Back to Courses
            </button>
            <h2 className="text-2xl font-bold text-[#0F6466] mb-4">
              Quizzes — {selectedCourse.course}
            </h2>
            {loading && <p>Loading quizzes…</p>}
            {error   && <p className="text-red-600">{error}</p>}
            {!loading && quizzes.length === 0 && !error && (
              <p>No quizzes published yet.</p>
            )}

            {pending.length > 0 && (
              <>
                <h3 className="mt-6 text-xl font-semibold text-[#0F6466]">
                  Pending
                </h3>
                <div className="space-y-6">
                  {pending.map(q => <QuizCard key={q._id} quiz={q} />)}
                </div>
              </>
            )}
            {completed.length > 0 && (
              <>
                <h3 className="mt-6 text-xl font-semibold text-gray-700">
                  Completed
                </h3>
                <div className="space-y-6">
                  {completed.map(q => <QuizCard key={q._id} quiz={q} completed />)}
                </div>
              </>
            )}
          </>
        )}
      </div>
    </div>
  );
}

function QuizCard({ quiz, completed = false }: {
  quiz: QuizWithStatus;
  completed?: boolean;
}) {
  return (
    <div className={`
      relative overflow-hidden rounded-lg shadow-lg p-6
      bg-gradient-to-r from-[#4C6EF5] to-[#748FFC]
      text-white
    `}>
      <h3 className="text-2xl font-semibold">{quiz.quizTitle}</h3>
      <div className="mt-4 space-y-1 text-sm">
        <p><strong>Marks:</strong> {quiz.totalMarks}</p>
        <p><strong>Deadline:</strong>{" "}
          {new Date(quiz.deadline).toLocaleDateString()}
        </p>
        {quiz.questionCount != null && (
          <p><strong>Questions:</strong> {quiz.questionCount}</p>
        )}
      </div>
      <Link
        href={`/Components/S/Quiz/Submit?quizId=${quiz._id}`}
        className="absolute bottom-4 right-4 px-4 py-2 bg-white text-[#4C6EF5] rounded shadow hover:bg-gray-100"
      >
        {completed ? "Review" : "Open"}
      </Link>
    </div>
  );
}
