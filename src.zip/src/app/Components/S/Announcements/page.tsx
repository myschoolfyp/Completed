// src/app/Component/S/Announcements/page.tsx
"use client";

import { useState, useEffect } from "react";

interface Reply {
  senderRollNo: string;
  senderName: string;
  description: string;
  date: string;
}

interface Announcement {
  _id: string;
  description: string;
  date: string;
  replies: Reply[];
}

export default function StudentAnnouncements() {
  const [rollNo, setRollNo] = useState("");
  const [name, setName] = useState("");
  const [announcements, setAnnouncements] = useState<Announcement[]>([]);
  const [replyText, setReplyText] = useState<Record<string, string>>({});

  // Load rollNo + name from localStorage
  useEffect(() => {
    const r = localStorage.getItem("rollNo") || "";
    const first = localStorage.getItem("firstName") || "";
    const last = localStorage.getItem("lastName") || "";
    setRollNo(r);
    setName(first && last ? `${first} ${last}` : "");
  }, []);

  // Fetch announcements once we have a rollNo
  useEffect(() => {
    if (!rollNo) return console.warn("No rollNo—skipping fetch");
    const url = `/api/Component/S/Announcements?stream=students&recipient=${rollNo}`;
    fetch(url)
      .then((r) => r.json())
      .then((data: Announcement[]) => setAnnouncements(data))
      .catch(console.error);
  }, [rollNo]);

  // Post a reply
  const sendReply = async (annId: string) => {
    const text = (replyText[annId] || "").trim();
    if (!text) return alert("Reply cannot be empty");

    const payload = {
      annId,
      senderRollNo: rollNo,
      senderName: name,
      description: text,
    };

    const res = await fetch("/api/Component/S/Announcements", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload),
    });

    if (!res.ok) {
      const err = await res.text();
      console.error("Student POST failed:", err);
      return alert("Failed to send reply");
    }

    const newR: Reply = await res.json();
    setAnnouncements((a) =>
      a.map((ann) =>
        ann._id === annId ? { ...ann, replies: [...ann.replies, newR] } : ann
      )
    );
    setReplyText((p) => ({ ...p, [annId]: "" }));
  };

  return (
    <div className="p-6 space-y-6 bg-white rounded-lg shadow">
      <h1 className="text-2xl font-semibold">Announcements</h1>

      {!rollNo ? (
        <div className="text-red-500">
          No roll number found—please log in again.
        </div>
      ) : (
        <div className="text-gray-700">
          Logged in as <strong>{name || "(no name)"}</strong>, Roll No:{" "}
          <strong>{rollNo}</strong>
        </div>
      )}

      {announcements.length === 0 && rollNo && (
        <div className="text-gray-500">No announcements yet.</div>
      )}

      {announcements.map((ann) => (
        <div key={ann._id} className="border p-4 rounded-lg space-y-3">
          <div className="text-sm text-gray-500">
            {new Date(ann.date).toLocaleString()}
          </div>
          <div className="font-medium">{ann.description}</div>

          {ann.replies.length > 0 && (
            <div className="space-y-2 pl-4 border-l">
              <div className="text-gray-600">Replies:</div>
              {ann.replies.map((r, i) => (
                <div key={i} className="text-sm">
                  <span className="italic">
                    [{new Date(r.date).toLocaleString()}]{" "}
                    <strong>{r.senderName}:</strong>
                  </span>{" "}
                  {r.description}
                </div>
              ))}
            </div>
          )}

          <div className="flex gap-2">
            <textarea
              rows={2}
              className="flex-1 border p-2 rounded-lg"
              placeholder="Write your reply..."
              value={replyText[ann._id] || ""}
              onChange={(e) =>
                setReplyText((p) => ({ ...p, [ann._id]: e.target.value }))
              }
            />
            <button
              onClick={() => sendReply(ann._id)}
              className="bg-blue-600 hover:bg-blue-700 text-white px-4 rounded-lg"
            >
              Reply
            </button>
          </div>
        </div>
      ))}
    </div>
  );
}
