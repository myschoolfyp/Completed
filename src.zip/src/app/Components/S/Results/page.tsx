"use client";

import { useEffect, useState } from "react";

const courseGradients = [
  "from-[#0F6466] to-[#2D9F9C]",
  "from-[#4C6EF5] to-[#748FFC]",
  "from-[#7950F2] to-[#9775FA]",
  "from-[#F76707] to-[#FF922B]",
  "from-[#E64980] to-[#F783AC]",
  "from-[#2F9E44] to-[#69DB7C]",
  "from-[#D6336C] to-[#F06595]",
  "from-[#1864AB] to-[#4DABF7]"
];

interface ResultDoc {
  _id: string;
  datesheetName: string;
  course: string;
  totalMarks: number;
  studentResults: Array<{
    rollNo: string;
    obtainedMarks: number;
    grade: string;
  }>;
  createdAt: string;
}

export default function StudentResults() {
  const [courses, setCourses] = useState<string[]>([]);
  const [selectedCourse, setSelectedCourse] = useState<string | null>(null);
  const [results, setResults] = useState<ResultDoc[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [showAll, setShowAll] = useState(false);

  const className = localStorage.getItem("className") || "";
  const rollNo = localStorage.getItem("rollNo") || "";

  // load courses
  useEffect(() => {
    (async () => {
      try {
        const resp = await fetch(
          `/api/Component/S/Courses?className=${encodeURIComponent(className)}`
        );
        if (!resp.ok) throw new Error("Could not load courses");
        const data = await resp.json();
        setCourses(data.courses || []);
      } catch (e: any) {
        setError(e.message);
      }
    })();
  }, [className]);

  // fetch results (either single course or all)
  const fetchResults = async (course?: string) => {
    setLoading(true);
    setError(null);
    try {
      const url = new URL("/api/Component/S/Results", location.origin);
      url.searchParams.set("className", className);
      if (course) url.searchParams.set("course", course);
      const resp = await fetch(url.toString());
      if (!resp.ok) throw new Error("Failed to load results");
      const docs: ResultDoc[] = await resp.json();
      const filtered = docs
        .map(doc => ({
          ...doc,
          studentResults: doc.studentResults.filter(r => r.rollNo === rollNo)
        }))
        .filter(doc => doc.studentResults.length > 0);
      setResults(filtered);
    } catch (e: any) {
      setError(e.message);
    } finally {
      setLoading(false);
    }
  };

  // when a course is picked
  const handleCourseSelect = (course: string) => {
    setShowAll(false);
    setSelectedCourse(course);
    fetchResults(course);
  };

  // when “Show All” clicked
  const handleShowAll = () => {
    setSelectedCourse(null);
    setShowAll(true);
    fetchResults(); // no course param => all
  };

  return (
    <div className="p-6 min-h-screen bg-gradient-to-br from-[#f5faff] to-[#e0f4ff]">
      <div className="max-w-5xl mx-auto space-y-6">
        <h1 className="text-3xl font-bold text-[#0F6466] text-center">
          {className} • Your Exam Results
        </h1>
        {error && <div className="text-red-500 text-center">{error}</div>}

        <div className="flex justify-center gap-4">
          <button
            onClick={handleShowAll}
            className="px-4 py-2 bg-[#0F6466] text-white rounded hover:bg-[#2D9F9C]"
          >
            Show All Results
          </button>
          <button
            onClick={() => {
              setShowAll(false);
              setSelectedCourse(null);
              setResults([]);
            }}
            className="px-4 py-2 bg-gray-300 text-gray-800 rounded hover:bg-gray-400"
          >
            Reset
          </button>
        </div>

        {/* course selector */}
        {!showAll && !selectedCourse && (
          <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
            {courses.map((course, i) => (
              <button
                key={i}
                onClick={() => handleCourseSelect(course)}
                className={`
                  bg-gradient-to-br ${courseGradients[i % courseGradients.length]}
                  text-white p-6 rounded-xl shadow-lg
                  hover:scale-105 transform transition
                `}
              >
                <div className="text-center">
                  <p className="text-xl font-semibold">
                    {course.split("-")[0].trim()}
                  </p>
                  <p className="text-sm opacity-90">
                    {course.split("-")[1]?.trim()}
                  </p>
                </div>
              </button>
            ))}
          </div>
        )}

        {/* results table */}
        {(showAll || selectedCourse) && (
          <>
            {loading ? (
              <div className="text-center text-lg text-[#0F6466]">Loading…</div>
            ) : results.length === 0 ? (
              <div className="text-center text-gray-600">
                No results found.
              </div>
            ) : (
              <div className="overflow-x-auto bg-white rounded-lg shadow-md p-4">
                <table className="w-full">
                  <thead className="bg-[#0F6466] text-white">
                    <tr>
                      <th className="p-2">Datesheet</th>
                      <th className="p-2">Course</th>
                      <th className="p-2">Date</th>
                      <th className="p-2">Total</th>
                      <th className="p-2">You</th>
                      <th className="p-2">Grade</th>
                    </tr>
                  </thead>
                  <tbody>
                    {results.map(doc => {
                      const rec = doc.studentResults[0];
                      return (
                        <tr key={doc._id} className="border-b hover:bg-gray-50">
                          <td className="p-2">{doc.datesheetName}</td>
                          <td className="p-2">{doc.course}</td>
                          <td className="p-2">
                            {new Date(doc.createdAt).toLocaleDateString()}
                          </td>
                          <td className="p-2 text-center">{doc.totalMarks}</td>
                          <td className="p-2 text-center">{rec.obtainedMarks}</td>
                          <td className="p-2 text-center font-semibold">
                            {rec.grade}
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            )}
          </>
        )}
      </div>
    </div>
  );
}
