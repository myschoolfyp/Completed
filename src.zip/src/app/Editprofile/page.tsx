// app/Editprofile/page.tsx
"use client";

import React, { useState, useEffect } from "react";
import { useRouter } from "next/navigation";
import { Camera, User } from "lucide-react";

type UserType = "Admin" | "Teacher" | "Parent" | "Student";

interface UserData {
  firstName: string;
  lastName: string;
  email: string;
  contactNumber: string;
  profilePicture?: string;
  cnic?: string;
  rollNo?: string;
  classLevel?: string;
  classType?: string;
  className?: string;
  department?: string;
}

export default function EditProfile() {
  const router = useRouter();
  const [stage, setStage] = useState<"auth" | "edit">("auth");
  const [userType, setUserType] = useState<UserType | "">("");
  const [identifier, setIdentifier] = useState(""); // CNIC or RollNo
  const [password, setPassword] = useState("");
  const [authError, setAuthError] = useState("");

  const [userData, setUserData] = useState<UserData | null>(null);

  const [firstName, setFirstName] = useState("");
  const [lastName, setLastName] = useState("");
  const [email, setEmail] = useState("");
  const [contactNumber, setContactNumber] = useState("");
  const [profilePicture, setProfilePicture] = useState<string | null>(null);
  const [profilePreview, setProfilePreview] = useState<string | null>(null);
  const [newPassword, setNewPassword] = useState("");
  const [confirmNewPassword, setConfirmNewPassword] = useState("");
  const [updateError, setUpdateError] = useState("");
  const [updateSuccess, setUpdateSuccess] = useState("");

  // Restrict identifier to digits & max length
  const handleIdentifierChange = (val: string) => {
    const digits = val.replace(/\D/g, "");
    const max = userType === "Student" ? 9 : 13;
    setIdentifier(digits.slice(0, max));
  };

  const handlePictureUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onloadend = () => {
      setProfilePicture(reader.result as string);
      setProfilePreview(reader.result as string);
    };
    reader.readAsDataURL(file);
  };

  const handleAuth = async (e: React.FormEvent) => {
    e.preventDefault();
    setAuthError("");
    if (!userType) {
      setAuthError("Please select a role");
      return;
    }
    if (identifier.length !== (userType === "Student" ? 9 : 13)) {
      setAuthError(
        userType === "Student"
          ? "Roll number must be 9 digits"
          : "CNIC must be 13 digits"
      );
      return;
    }
    try {
      const res = await fetch("/api/editprofile", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ userType, identifier, password }),
      });
      const body = await res.json();
      if (!res.ok) throw new Error(body.error || "Invalid credentials");
      setUserData(body.user);
      setFirstName(body.user.firstName);
      setLastName(body.user.lastName);
      setEmail(body.user.email);
      setContactNumber(body.user.contactNumber);
      setProfilePreview(body.user.profilePicture || null);
      setStage("edit");
    } catch (err: any) {
      setAuthError(err.message);
    }
  };

  const handleUpdate = async (e: React.FormEvent) => {
    e.preventDefault();
    setUpdateError("");
    setUpdateSuccess("");
    if (newPassword && newPassword !== confirmNewPassword) {
      setUpdateError("New passwords do not match.");
      return;
    }
    try {
      const payload: any = {
        userType,
        identifier,
        password,
        updates: {
          firstName,
          lastName,
          email,
          contactNumber,
          profilePicture,
        },
      };
      if (newPassword) payload.updates.password = newPassword;

      const res = await fetch("/api/editprofile", {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });
      const body = await res.json();
      if (!res.ok) throw new Error(body.error || "Update failed");
      setUpdateSuccess("Profile updated successfully!");
      setNewPassword("");
      setConfirmNewPassword("");
    } catch (err: any) {
      setUpdateError(err.message);
    }
  };

  useEffect(() => {
    if (stage === "edit" && !userData) router.push("/");
  }, [stage, userData, router]);

  return (
    <div className="min-h-screen bg-gradient-to-br from-[#E0F7FA] to-[#FFEBEE] flex items-center justify-center p-6">
      <div className="w-full max-w-2xl bg-white shadow-xl rounded-lg overflow-hidden">
        {stage === "auth" ? (
          <div className="p-8">
            <h2 className="text-3xl font-bold text-center text-[#0F6466] mb-6">
              Verify Your Identity
            </h2>
            {authError && (
              <p className="text-red-500 text-center mb-4">{authError}</p>
            )}
            <form onSubmit={handleAuth} className="space-y-5">
              <div>
                <label className="block font-medium mb-1">Role</label>
                <select
                  value={userType}
                  onChange={(e) => {
                    setUserType(e.target.value as UserType);
                    setIdentifier("");
                  }}
                  required
                  className="w-full border rounded px-4 py-2 focus:ring-[#0F6466]"
                >
                  <option value="">Select role</option>
                  <option>Admin</option>
                  <option>Teacher</option>
                  <option>Parent</option>
                  <option>Student</option>
                </select>
              </div>
              <div>
                <label className="block font-medium mb-1">
                  {userType === "Student" ? "Roll Number" : "CNIC"}
                </label>
                <input
                  type="text"
                  value={identifier}
                  onChange={(e) => handleIdentifierChange(e.target.value)}
                  maxLength={userType === "Student" ? 9 : 13}
                  pattern={userType === "Student" ? "\\d{9}" : "\\d{13}"}
                  placeholder={
                    userType === "Student" ? "9 digits" : "13 digits"
                  }
                  required
                  className="w-full border rounded px-4 py-2 focus:ring-[#0F6466]"
                />
              </div>
              <div>
                <label className="block font-medium mb-1">Password</label>
                <input
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  required
                  className="w-full border rounded px-4 py-2 focus:ring-[#0F6466]"
                />
              </div>
              <button
                type="submit"
                className="w-full bg-gradient-to-r from-[#4C6EF5] to-[#2DD4BF] text-white py-3 rounded-lg font-semibold hover:opacity-95 transition"
              >
                Verify
              </button>
            </form>
          </div>
        ) : (
          <>
            {/* Header */}
            <div className="bg-gradient-to-r from-[#4C6EF5] to-[#2DD4BF] p-6 flex items-center space-x-6">
              <div className="relative">
                {profilePreview ? (
                  <img
                    src={profilePreview}
                    alt="Avatar"
                    className="w-24 h-24 rounded-full border-4 border-white shadow-lg"
                  />
                ) : (
                  <div className="w-24 h-24 rounded-full bg-white flex items-center justify-center border-4 border-white shadow-lg">
                    <User size={48} className="text-[#4C6EF5]" />
                  </div>
                )}
                <div className="absolute bottom-0 right-0 bg-white p-1 rounded-full border border-gray-200">
                  <Camera size={18} className="text-gray-700" />
                </div>
              </div>
              <div>
                <h3 className="text-2xl font-bold text-white">
                  {userData!.firstName} {userData!.lastName}
                </h3>
                <p className="text-white/90">{userType} Profile</p>
              </div>
            </div>

            {/* Form */}
            <div className="p-8">
              {updateError && (
                <p className="text-red-500 text-center mb-4">{updateError}</p>
              )}
              {updateSuccess && (
                <p className="text-green-600 text-center mb-4">
                  {updateSuccess}
                </p>
              )}
              <form onSubmit={handleUpdate} className="space-y-6">
                {/* Identifier & Locks */}
                <div className="grid grid-cols-2 gap-6">
                  <div>
                    <label className="block font-medium mb-1">
                      {userType === "Student" ? "Roll Number" : "CNIC"}
                    </label>
                    <input
                      type="text"
                      value={identifier}
                      disabled
                      className="w-full bg-gray-100 border rounded px-4 py-2"
                    />
                  </div>
                  {userType === "Student" && (
                    <>
                      <div>
                        <label className="block font-medium mb-1">
                          Class Level
                        </label>
                        <input
                          type="text"
                          value={userData!.classLevel}
                          disabled
                          className="w-full bg-gray-100 border rounded px-4 py-2"
                        />
                      </div>
                      <div>
                        <label className="block font-medium mb-1">
                          Class Type
                        </label>
                        <input
                          type="text"
                          value={userData!.classType}
                          disabled
                          className="w-full bg-gray-100 border rounded px-4 py-2"
                        />
                      </div>
                      <div className="col-span-2">
                        <label className="block font-medium mb-1">
                          Class Name
                        </label>
                        <input
                          type="text"
                          value={userData!.className || ""}
                          disabled
                          className="w-full bg-gray-100 border rounded px-4 py-2"
                        />
                      </div>
                    </>
                  )}
                  {userType === "Teacher" && (
                    <div className="col-span-2">
                      <label className="block font-medium mb-1">
                        Department
                      </label>
                      <input
                        type="text"
                        value={userData!.department!}
                        disabled
                        className="w-full bg-gray-100 border rounded px-4 py-2"
                      />
                    </div>
                  )}
                </div>

                {/* Editable fields */}
                <div className="grid grid-cols-2 gap-6">
                  <input
                    type="text"
                    value={firstName}
                    onChange={(e) => setFirstName(e.target.value)}
                    required
                    placeholder="First Name"
                    className="w-full border rounded px-4 py-2 focus:ring-[#0F6466]"
                  />
                  <input
                    type="text"
                    value={lastName}
                    onChange={(e) => setLastName(e.target.value)}
                    required
                    placeholder="Last Name"
                    className="w-full border rounded px-4 py-2 focus:ring-[#0F6466]"
                  />
                </div>
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  required
                  placeholder="Email Address"
                  className="w-full border rounded px-4 py-2 focus:ring-[#0F6466]"
                />
                <input
                  type="text"
                  value={contactNumber}
                  onChange={(e) => setContactNumber(e.target.value)}
                  required
                  placeholder="Contact Number"
                  className="w-full border rounded px-4 py-2 focus:ring-[#0F6466]"
                />

                {/* Profile Picture */}
                <div>
                  <label className="flex items-center cursor-pointer">
                    <span className="mr-4">Change Photo:</span>
                    <div className="relative">
                      {profilePreview ? (
                        <img
                          src={profilePreview}
                          alt="Avatar"
                          className="w-16 h-16 rounded-full border"
                        />
                      ) : (
                        <div className="w-16 h-16 rounded-full bg-gray-100 flex items-center justify-center border">
                          <User size={32} className="text-gray-400" />
                        </div>
                      )}
                      <div className="absolute bottom-0 right-0 bg-white p-1 rounded-full border">
                        <Camera size={14} className="text-gray-700" />
                      </div>
                      <input
                        type="file"
                        accept="image/*"
                        onChange={handlePictureUpload}
                        className="hidden"
                      />
                    </div>
                  </label>
                </div>

                {/* Password Change */}
                <div className="grid grid-cols-2 gap-6">
                  <input
                    type="password"
                    value={newPassword}
                    onChange={(e) => setNewPassword(e.target.value)}
                    placeholder="New Password"
                    className="w-full border rounded px-4 py-2 focus:ring-[#0F6466]"
                  />
                  <input
                    type="password"
                    value={confirmNewPassword}
                    onChange={(e) => setConfirmNewPassword(e.target.value)}
                    placeholder="Confirm New Password"
                    className="w-full border rounded px-4 py-2 focus:ring-[#0F6466]"
                  />
                </div>

                <button
                  type="submit"
                  className="w-full bg-gradient-to-r from-[#4C6EF5] to-[#2DD4BF] text-white py-3 rounded-lg font-semibold hover:opacity-95 transition"
                >
                  Save Changes
                </button>
              </form>
            </div>
          </>
        )}
      </div>
    </div>
  );
}
