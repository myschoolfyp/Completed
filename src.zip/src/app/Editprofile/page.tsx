"use client";

import React, { useState, useEffect } from "react";
import { useRouter } from "next/navigation";
import { Camera, User } from "lucide-react";

type UserType = "Admin" | "Teacher" | "Parent" | "Student";

interface UserData {
  firstName: string;
  lastName: string;
  email: string;
  contactNumber: string;
  profilePicture?: string;
  cnic?: string;
  rollNo?: string;
  classLevel?: string;
  classType?: string;
  className?: string;
  department?: string;
}

export default function EditProfile() {
  const router = useRouter();
  const [stage, setStage] = useState<"auth" | "edit">("auth");
  const [userType, setUserType] = useState<UserType | "">("");
  const [identifier, setIdentifier] = useState("");
  const [password, setPassword] = useState("");
  const [authError, setAuthError] = useState("");

  const [userData, setUserData] = useState<UserData | null>(null);
  const [firstName, setFirstName] = useState("");
  const [lastName, setLastName] = useState("");
  const [email, setEmail] = useState("");
  const [contactNumber, setContactNumber] = useState("");
  const [profilePicture, setProfilePicture] = useState<string | null>(null);
  const [profilePreview, setProfilePreview] = useState<string | null>(null);
  const [newPassword, setNewPassword] = useState("");
  const [confirmNewPassword, setConfirmNewPassword] = useState("");
  const [updateError, setUpdateError] = useState("");
  const [updateSuccess, setUpdateSuccess] = useState("");

  const handleIdentifierChange = (val: string) => {
    const digits = val.replace(/\D/g, "");
    const max = userType === "Student" ? 9 : 13;
    setIdentifier(digits.slice(0, max));
  };

  const handlePictureUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onloadend = () => {
      setProfilePicture(reader.result as string);
      setProfilePreview(reader.result as string);
    };
    reader.readAsDataURL(file);
  };

  const handleAuth = async (e: React.FormEvent) => {
    e.preventDefault();
    setAuthError("");
    if (!userType) {
      setAuthError("Please select a role");
      return;
    }
    if (identifier.length !== (userType === "Student" ? 9 : 13)) {
      setAuthError(
        userType === "Student"
          ? "Roll number must be 9 digits"
          : "CNIC must be 13 digits"
      );
      return;
    }
    try {
      const res = await fetch("/api/editprofile", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ userType, identifier, password }),
      });
      const body = await res.json();
      if (!res.ok) throw new Error(body.error || "Invalid credentials");
      setUserData(body.user);
      setFirstName(body.user.firstName);
      setLastName(body.user.lastName);
      setEmail(body.user.email);
      setContactNumber(body.user.contactNumber);
      setProfilePreview(body.user.profilePicture || null);
      setStage("edit");
    } catch (err: any) {
      setAuthError(err.message);
    }
  };

  const handleUpdate = async (e: React.FormEvent) => {
    e.preventDefault();
    setUpdateError("");
    setUpdateSuccess("");
    if (newPassword && newPassword !== confirmNewPassword) {
      setUpdateError("New passwords do not match.");
      return;
    }
    try {
      const payload: any = {
        userType,
        identifier,
        password,
        updates: {
          firstName,
          lastName,
          email,
          contactNumber,
          profilePicture,
        },
      };
      if (newPassword) payload.updates.password = newPassword;

      const res = await fetch("/api/editprofile", {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });
      const body = await res.json();
      if (!res.ok) throw new Error(body.error || "Update failed");
      setUpdateSuccess("Profile updated successfully!");
      setNewPassword("");
      setConfirmNewPassword("");
    } catch (err: any) {
      setUpdateError(err.message);
    }
  };

  useEffect(() => {
    if (stage === "edit" && !userData) router.push("/");
  }, [stage, userData, router]);

  return (
    <div className="flex justify-center items-center min-h-screen bg-gradient-to-br from-[#0F6466]/10 to-[#2C3532]/5 p-4">
      <div className="w-full max-w-4xl bg-white rounded-xl shadow-2xl overflow-hidden border border-[#0F6466]/20">
        {/* Common header */}
        <div className="bg-gradient-to-r from-[#0F6466] to-[#2C3532] p-6 text-center">
          <h2 className="text-3xl font-bold text-white">
            {stage === "auth" ? "Verify Your Identity" : "Update Profile"}
          </h2>
          <p className="text-white/90 mt-2">
            {stage === "auth" ? "Authentication required for profile changes" : "Edit your account information"}
          </p>
        </div>

        <div className="p-8 grid grid-cols-1 lg:grid-cols-2 gap-8">
          {stage === "auth" ? (
            <div className="lg:col-span-2">
              {authError && (
                <div className="mb-6 p-3 bg-red-50 border-l-4 border-red-500 text-red-700 rounded">
                  <p className="text-center font-medium">{authError}</p>
                </div>
              )}
              <form onSubmit={handleAuth} className="space-y-6">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Role</label>
                  <select
                    value={userType}
                    onChange={(e) => {
                      setUserType(e.target.value as UserType);
                      setIdentifier("");
                    }}
                    required
                    className="w-full px-3 py-2.5 rounded-lg border-2 border-gray-200 focus:border-[#0F6466] focus:ring-2 focus:ring-[#0F6466]/30 transition-all appearance-none"
                  >
                    <option value="">Select role</option>
                    <option>Admin</option>
                    <option>Teacher</option>
                    <option>Parent</option>
                    <option>Student</option>
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    {userType === "Student" ? "Roll Number" : "CNIC"}
                  </label>
                  <input
                    type="text"
                    value={identifier}
                    onChange={(e) => handleIdentifierChange(e.target.value)}
                    maxLength={userType === "Student" ? 9 : 13}
                    pattern={userType === "Student" ? "\\d{9}" : "\\d{13}"}
                    placeholder={userType === "Student" ? "9 digits" : "13 digits"}
                    required
                    className="w-full px-3 py-2.5 rounded-lg border-2 border-gray-200 focus:border-[#0F6466] focus:ring-2 focus:ring-[#0F6466]/30 transition-all"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Password</label>
                  <input
                    type="password"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    required
                    className="w-full px-3 py-2.5 rounded-lg border-2 border-gray-200 focus:border-[#0F6466] focus:ring-2 focus:ring-[#0F6466]/30 transition-all"
                  />
                </div>

                <button
                  type="submit"
                  className="w-full py-3 bg-gradient-to-r from-[#0F6466] to-[#2C3532] text-white rounded-lg shadow-lg hover:from-[#2C3532] hover:to-[#0F6466] transition-all duration-300 text-lg font-semibold transform hover:scale-[1.01]"
                >
                  Verify
                </button>
              </form>
            </div>
          ) : (
            <>
              {/* Left side - Profile Preview */}
              <div className="hidden lg:flex flex-col justify-center items-center bg-gradient-to-br from-[#0F6466]/10 to-[#2C3532]/10 rounded-lg p-6">
                <div className="w-full h-full flex items-center justify-center">
                  <div className="text-center space-y-4">
                    <label htmlFor="profileUpload" className="cursor-pointer relative group">
                      <div className="relative">
                        {profilePreview ? (
                          <img
                            src={profilePreview}
                            alt="Profile Preview"
                            className="w-32 h-32 object-cover rounded-full border-4 border-white shadow-md group-hover:border-[#0F6466] transition-all duration-300"
                          />
                        ) : (
                          <div className="w-32 h-32 rounded-full border-4 border-white bg-gradient-to-br from-[#0F6466]/10 to-[#2C3532]/10 flex items-center justify-center shadow-md group-hover:border-[#0F6466] transition-all duration-300">
                            <User size={60} className="text-[#0F6466]/60" />
                          </div>
                        )}
                        <div className="absolute bottom-0 right-0 bg-white rounded-full p-1.5 border-2 border-[#0F6466] group-hover:bg-[#0F6466] group-hover:text-white transition-colors duration-300">
                          <Camera size={20} className="text-[#0F6466] group-hover:text-white" />
                        </div>
                      </div>
                      <input
                        type="file"
                        id="profileUpload"
                        accept="image/*"
                        onChange={handlePictureUpload}
                        className="hidden"
                      />
                    </label>
                    <h3 className="text-2xl font-semibold text-[#0F6466]">
                      {userData?.firstName} {userData?.lastName}
                    </h3>
                    <p className="text-gray-600">{userType} Profile</p>
                  </div>
                </div>
              </div>

              {/* Right side - Edit Form */}
              <div>
                {updateError && (
                  <div className="mb-6 p-3 bg-red-50 border-l-4 border-red-500 text-red-700 rounded">
                    <p className="text-center font-medium">{updateError}</p>
                  </div>
                )}
                {updateSuccess && (
                  <div className="mb-6 p-3 bg-green-50 border-l-4 border-green-500 text-green-700 rounded">
                    <p className="text-center font-medium">{updateSuccess}</p>
                  </div>
                )}

                <form onSubmit={handleUpdate} className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">First Name</label>
                      <input
                        type="text"
                        value={firstName}
                        onChange={(e) => setFirstName(e.target.value)}
                        required
                        className="w-full px-3 py-2.5 rounded-lg border-2 border-gray-200 focus:border-[#0F6466] focus:ring-2 focus:ring-[#0F6466]/30 transition-all"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">Last Name</label>
                      <input
                        type="text"
                        value={lastName}
                        onChange={(e) => setLastName(e.target.value)}
                        required
                        className="w-full px-3 py-2.5 rounded-lg border-2 border-gray-200 focus:border-[#0F6466] focus:ring-2 focus:ring-[#0F6466]/30 transition-all"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">Email</label>
                      <input
                        type="email"
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                        required
                        className="w-full px-3 py-2.5 rounded-lg border-2 border-gray-200 focus:border-[#0F6466] focus:ring-2 focus:ring-[#0F6466]/30 transition-all"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">Contact</label>
                      <input
                        type="text"
                        value={contactNumber}
                        onChange={(e) => setContactNumber(e.target.value)}
                        required
                        className="w-full px-3 py-2.5 rounded-lg border-2 border-gray-200 focus:border-[#0F6466] focus:ring-2 focus:ring-[#0F6466]/30 transition-all"
                      />
                    </div>
                  </div>

                  {userType === "Student" && (
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">Roll Number</label>
                        <input
                          type="text"
                          value={identifier}
                          disabled
                          className="w-full px-3 py-2.5 rounded-lg border-2 border-gray-200 bg-gray-100"
                        />
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">Class Level</label>
                        <input
                          type="text"
                          value={userData?.classLevel || ""}
                          disabled
                          className="w-full px-3 py-2.5 rounded-lg border-2 border-gray-200 bg-gray-100"
                        />
                      </div>
                    </div>
                  )}

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">New Password</label>
                      <input
                        type="password"
                        value={newPassword}
                        onChange={(e) => setNewPassword(e.target.value)}
                        className="w-full px-3 py-2.5 rounded-lg border-2 border-gray-200 focus:border-[#0F6466] focus:ring-2 focus:ring-[#0F6466]/30 transition-all"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">Confirm Password</label>
                      <input
                        type="password"
                        value={confirmNewPassword}
                        onChange={(e) => setConfirmNewPassword(e.target.value)}
                        className="w-full px-3 py-2.5 rounded-lg border-2 border-gray-200 focus:border-[#0F6466] focus:ring-2 focus:ring-[#0F6466]/30 transition-all"
                      />
                    </div>
                  </div>

                  <button
                    type="submit"
                    className="w-full py-3 bg-gradient-to-r from-[#0F6466] to-[#2C3532] text-white rounded-lg shadow-lg hover:from-[#2C3532] hover:to-[#0F6466] transition-all duration-300 text-lg font-semibold transform hover:scale-[1.01]"
                  >
                    Save Changes
                  </button>
                </form>
              </div>
            </>
          )}
        </div>
      </div>
    </div>
  );
}