"use client";
import { useState } from "react";
import { Camera, User } from "lucide-react";

const departments = [
  'Arts', 'Maths', 'Chem', 'Physics', 
  'English', 'Urdu', 'Islamiat', 'History'
];

export default function Register() {
  // All state declarations remain the same
  const [firstName, setFirstName] = useState("");
  const [lastName, setLastName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [contactNumber, setContactNumber] = useState("");
  const [userType, setUserType] = useState("");
  const [classLevel, setClassLevel] = useState<number | null>(null);
  const [classType, setClassType] = useState("");
  const [department, setDepartment] = useState("");
  const [cnic, setCnic] = useState("");
  const [rollNo, setRollNo] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [profilePicture, setProfilePicture] = useState<string | null>(null);
  const [profilePicturePreview, setProfilePicturePreview] = useState<string | null>(null);

  // All handler functions remain exactly the same
  const handleProfilePictureUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onloadend = () => {
      setProfilePicture(reader.result as string);
      setProfilePicturePreview(reader.result as string);
    };
    reader.readAsDataURL(file);
  };

  const validateForm = () => {
    const nameRegex = /^[A-Za-z]+(?:[' -][A-Za-z]+)*$/;
  
    if (!nameRegex.test(firstName) || !nameRegex.test(lastName)) {
      setError("Names must contain only letters and be 1-20 characters long");
      return false;
    }

    if (firstName.length > 20 || lastName.length > 20) {
      setError("Names cannot exceed 20 characters");
      return false;
    }
    
    if (firstName.length < 2 || lastName.length < 2) {
      setError("First and Last name must be at least 2 characters long.");
      return false;
    }

    if (!/^\w+([.-]?\w+)*@\w+([.-]?\w+)*(\.\w{2,3})+$/.test(email)) {
      setError("Please enter a valid email address.");
      return false;
    }

    if (password.length < 8) {
      setError("Password must be at least 8 characters long.");
      return false;
    }

    if (password !== confirmPassword) {
      setError("Passwords do not match.");
      return false;
    }

    if (!/^\d{11}$/.test(contactNumber)) {
      setError("Contact number must be 11 digits.");
      return false;
    }
    
    if (userType === "Teacher" && !department) {
      setError("Please select a department");
      return false;
    }
    
    if (userType === "Teacher" && !/^\d{13}$/.test(cnic)) {
      setError("CNIC must be 13 digits");
      return false;
    }
    
    if (userType === "Student" && !/^\d{9}$/.test(rollNo)) {
      setError("Roll number must be 9 digits");
      return false;
    }

    if ((userType === "Admin" || userType === "Teacher" || userType === "Parent") && !/^\d{13}$/.test(cnic)) {
      setError("CNIC must be 13 digits");
      return false;
    }
    
    return true;
  };

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
  
    if (!validateForm()) return;
  
    try {
      const formData = {
        firstName,
        lastName,
        email,
        password,
        userType,
        contactNumber,
        department: userType === "Teacher" ? department : undefined,
        classLevel: userType === "Student" ? classLevel : undefined,
        classType: userType === "Student" ? classType : undefined,
        rollNo: userType === "Student" ? rollNo : undefined,
        cnic: userType === "Admin" || userType === "Teacher" || userType === "Parent" ? cnic.replace(/-/g, '') : undefined,
        profilePicture,
      };
  
      const response = await fetch("/api/register", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(formData),
      });
  
      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.message || "Failed to register user.");
      }
  
      alert("Registration successful!");
  
      // Reset form fields
      setFirstName("");
      setLastName("");
      setEmail("");
      setPassword("");
      setConfirmPassword("");
      setUserType("");
      setContactNumber("");
      setClassLevel(null);
      setClassType("");
      setDepartment("");
      setProfilePicture(null);
      setProfilePicturePreview(null);
    } catch (error) {
      console.error("Registration error:", error);
      if (error instanceof Error) {
        setError(error.message || "An error occurred during registration.");
      } else {
        setError("An unknown error occurred during registration.");
      }
    }
  };

  return (
    <div className="flex justify-center items-center min-h-screen bg-gradient-to-br from-[#0F6466]/10 to-[#2C3532]/5 p-4">
      <div className="w-full max-w-4xl bg-white rounded-xl shadow-2xl overflow-hidden border border-[#0F6466]/20">
        {/* Header with gradient */}
        <div className="bg-gradient-to-r from-[#0F6466] to-[#2C3532] p-6 text-center">
          <h2 className="text-3xl font-bold text-white">Create Your Account</h2>
          <p className="text-white/90 mt-2">Join our educational community</p>
        </div>

        <div className="p-8 grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Left side - Visual element */}
          <div className="hidden lg:flex flex-col justify-center items-center bg-gradient-to-br from-[#0F6466]/10 to-[#2C3532]/10 rounded-lg p-6">
            <div className="w-full h-full flex items-center justify-center">
              <div className="text-center">
                <User className="mx-auto h-24 w-24 text-[#0F6466] mb-4" />
                <h3 className="text-2xl font-semibold text-[#0F6466]">Student Registration</h3>
                <p className="mt-2 text-gray-600">Complete your profile to get started</p>
              </div>
            </div>
          </div>

          {/* Right side - Form */}
          <div>
            {/* Profile Picture Upload */}
            <div className="flex justify-center items-center mb-6">
              <label htmlFor="profilePicture" className="cursor-pointer relative group">
                <div className="relative">
                  {profilePicturePreview ? (
                    <img
                      src={profilePicturePreview}
                      alt="Profile Preview"
                      className="w-20 h-20 object-cover rounded-full border-4 border-white shadow-md group-hover:border-[#0F6466] transition-all duration-300"
                    />
                  ) : (
                    <div className="w-20 h-20 rounded-full border-4 border-white bg-gradient-to-br from-[#0F6466]/10 to-[#2C3532]/10 flex items-center justify-center shadow-md group-hover:border-[#0F6466] transition-all duration-300">
                      <User size={40} className="text-[#0F6466]/60" />
                    </div>
                  )}
                  <div className="absolute bottom-0 right-0 bg-white rounded-full p-1.5 border-2 border-[#0F6466] group-hover:bg-[#0F6466] group-hover:text-white transition-colors duration-300">
                    <Camera size={16} className="text-[#0F6466] group-hover:text-white" />
                  </div>
                </div>
                <input
                  type="file"
                  id="profilePicture"
                  accept="image/*"
                  onChange={handleProfilePictureUpload}
                  className="hidden"
                />
              </label>
            </div>

            {error && (
              <div className="mb-6 p-3 bg-red-50 border-l-4 border-red-500 text-red-700 rounded">
                <p className="text-center font-medium">{error}</p>
              </div>
            )}

            <form onSubmit={handleSubmit} className="space-y-4">
              {/* First and Last Name */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label htmlFor="firstName" className="block text-sm font-medium text-gray-700 mb-1">
                    First Name
                  </label>
                  <input
                    type="text"
                    id="firstName"
                    placeholder="First Name"
                    value={firstName}
                    onChange={(e) => setFirstName(e.target.value.replace(/[^A-Za-z' -]/g, ''))}
                    pattern="^[A-Za-z]+(?:[' -][A-Za-z]+)*$"
                    maxLength={20}
                    required
                    className="w-full px-3 py-2.5 rounded-lg border-2 border-gray-200 focus:border-[#0F6466] focus:ring-2 focus:ring-[#0F6466]/30 transition-all"
                  />
                </div>
                <div>
                  <label htmlFor="lastName" className="block text-sm font-medium text-gray-700 mb-1">
                    Last Name
                  </label>
                  <input
                    type="text"
                    id="lastName"
                    placeholder="Last Name"
                    value={lastName}
                    onChange={(e) => setLastName(e.target.value.replace(/[^A-Za-z' -]/g, ''))}
                    pattern="^[A-Za-z]+(?:[' -][A-Za-z]+)*$"
                    maxLength={20}
                    required
                    className="w-full px-3 py-2.5 rounded-lg border-2 border-gray-200 focus:border-[#0F6466] focus:ring-2 focus:ring-[#0F6466]/30 transition-all"
                  />
                </div>
              </div>

              {/* Email and Contact */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label htmlFor="email" className="block text-sm font-medium text-gray-700 mb-1">
                    Email Address
                  </label>
                  <input
                    type="email"
                    id="email"
                    placeholder="Email Address"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    required
                    className="w-full px-3 py-2.5 rounded-lg border-2 border-gray-200 focus:border-[#0F6466] focus:ring-2 focus:ring-[#0F6466]/30 transition-all"
                  />
                </div>
                <div>
                  <label htmlFor="contactNumber" className="block text-sm font-medium text-gray-700 mb-1">
                    Contact Number
                  </label>
                  <input
                    type="text"
                    id="contactNumber"
                    placeholder="Contact Number"
                    value={contactNumber}
                    onChange={(e) => setContactNumber(e.target.value)}
                    required
                    className="w-full px-3 py-2.5 rounded-lg border-2 border-gray-200 focus:border-[#0F6466] focus:ring-2 focus:ring-[#0F6466]/30 transition-all"
                  />
                </div>
              </div>

              {/* Passwords */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label htmlFor="password" className="block text-sm font-medium text-gray-700 mb-1">
                    Password
                  </label>
                  <input
                    type="password"
                    id="password"
                    placeholder="Password"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    required
                    className="w-full px-3 py-2.5 rounded-lg border-2 border-gray-200 focus:border-[#0F6466] focus:ring-2 focus:ring-[#0F6466]/30 transition-all"
                  />
                </div>
                <div>
                  <label htmlFor="confirmPassword" className="block text-sm font-medium text-gray-700 mb-1">
                    Confirm Password
                  </label>
                  <input
                    type="password"
                    id="confirmPassword"
                    placeholder="Confirm Password"
                    value={confirmPassword}
                    onChange={(e) => setConfirmPassword(e.target.value)}
                    required
                    className="w-full px-3 py-2.5 rounded-lg border-2 border-gray-200 focus:border-[#0F6466] focus:ring-2 focus:ring-[#0F6466]/30 transition-all"
                  />
                </div>
              </div>

              {/* User Type and Roll Number */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label htmlFor="userType" className="block text-sm font-medium text-gray-700 mb-1">
                    User Type
                  </label>
                  <select
                    id="userType"
                    value={userType}
                    onChange={(e) => setUserType(e.target.value)}
                    required
                    className="w-full px-3 py-2.5 rounded-lg border-2 border-gray-200 focus:border-[#0F6466] focus:ring-2 focus:ring-[#0F6466]/30 transition-all appearance-none"
                  >
                    <option value="" disabled>Select User Type</option>
                    <option value="Teacher">Teacher</option>
                    <option value="Admin">Admin</option>
                    <option value="Parent">Parent</option>
                    <option value="Student">Student</option>
                  </select>
                </div>
                {userType === "Student" && (
                  <div>
                    <label htmlFor="rollNo" className="block text-sm font-medium text-gray-700 mb-1">
                      Roll Number
                    </label>
                    <input
                      type="text"
                      id="rollNo"
                      placeholder="Roll Number (9 digits)"
                      value={rollNo}
                      onChange={(e) => {
                        const value = e.target.value.replace(/\D/g, '').slice(0, 9);
                        setRollNo(value);
                      }}
                      required
                      className="w-full px-3 py-2.5 rounded-lg border-2 border-gray-200 focus:border-[#0F6466] focus:ring-2 focus:ring-[#0F6466]/30 transition-all"
                    />
                  </div>
                )}
              </div>

              {/* Student-specific fields */}
              {userType === "Student" && (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label htmlFor="classLevel" className="block text-sm font-medium text-gray-700 mb-1">
                      Class Level
                    </label>
                    <select
                      id="classLevel"
                      value={classLevel || ""}
                      onChange={(e) => setClassLevel(Number(e.target.value))}
                      required
                      className="w-full px-3 py-2.5 rounded-lg border-2 border-gray-200 focus:border-[#0F6466] focus:ring-2 focus:ring-[#0F6466]/30 transition-all appearance-none"
                    >
                      <option value="" disabled>Select Class</option>
                      {[...Array(12)].map((_, i) => {
                        const classNum = i + 1;
                        return (
                          <option key={classNum} value={classNum}>{`Class ${classNum}`}</option>
                        );
                      })}
                    </select>
                  </div>
                  <div>
                    <label htmlFor="classType" className="block text-sm font-medium text-gray-700 mb-1">
                      Stream
                    </label>
                    <select
                      id="classType"
                      value={classType}
                      onChange={(e) => setClassType(e.target.value)}
                      required
                      className="w-full px-3 py-2.5 rounded-lg border-2 border-gray-200 focus:border-[#0F6466] focus:ring-2 focus:ring-[#0F6466]/30 transition-all appearance-none"
                    >
                      <option value="" disabled>Select Stream</option>
                      {[9, 10].includes(Number(classLevel)) ? (
                        <>
                          <option value="Science">Science</option>
                          <option value="Arts">Arts</option>
                          <option value="Computer">Computer</option>
                        </>
                      ) : (
                        <option value="General">General</option>
                      )}
                    </select>
                  </div>
                </div>
              )}

              {/* CNIC Field */}
              {(userType === "Admin" || userType === "Teacher" || userType === "Parent") && (
                <div>
                  <label htmlFor="cnic" className="block text-sm font-medium text-gray-700 mb-1">
                    CNIC (Without dashes)
                  </label>
                  <input
                    type="text"
                    id="cnic"
                    placeholder="3420112345678"
                    value={cnic}
                    onChange={(e) => {
                      const value = e.target.value.replace(/\D/g, '').slice(0, 13);
                      setCnic(value);
                    }}
                    required
                    className="w-full px-3 py-2.5 rounded-lg border-2 border-gray-200 focus:border-[#0F6466] focus:ring-2 focus:ring-[#0F6466]/30 transition-all"
                  />
                </div>
              )}

              {/* Teacher-specific fields */}
              {userType === "Teacher" && (
                <div>
                  <label htmlFor="department" className="block text-sm font-medium text-gray-700 mb-1">
                    Department
                  </label>
                  <select
                    id="department"
                    value={department}
                    onChange={(e) => setDepartment(e.target.value)}
                    required
                    className="w-full px-3 py-2.5 rounded-lg border-2 border-gray-200 focus:border-[#0F6466] focus:ring-2 focus:ring-[#0F6466]/30 transition-all appearance-none"
                  >
                    <option value="">Select Department</option>
                    {departments.map((dept) => (
                      <option key={dept} value={dept}>{dept}</option>
                    ))}
                  </select>
                </div>
              )}

              <div className="pt-2">
                <button
                  type="submit"
                  className="w-full py-3 bg-gradient-to-r from-[#0F6466] to-[#2C3532] text-white rounded-lg shadow-lg hover:from-[#2C3532] hover:to-[#0F6466] transition-all duration-300 text-lg font-semibold transform hover:scale-[1.01]"
                >
                  Register Now
                </button>
              </div>

              <div className="text-center text-sm text-gray-600">
                Already have an account?{" "}
                <a href="Login#" className="font-semibold text-[#0F6466] hover:text-[#2C3532] transition-colors">
                  Login here
                </a>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
  );
}