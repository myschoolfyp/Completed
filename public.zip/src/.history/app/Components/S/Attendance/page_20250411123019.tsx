"use client";
import React, { useEffect, useState } from 'react';

interface Course {
  course: string;
  teacher: string;
  teacherId: string;
}

interface AttendanceRecord {
  date: string;
  time: string;
  status: string;
  course: string;
  room: string;
}

interface AttendanceStats {
  totalClasses: number;
  presents: number;
  absents: number;
  leaves: number;
  percentage: number;
}

export default function Attendance() {
  const [courses, setCourses] = useState<Course[]>([]);
  const [selectedCourse, setSelectedCourse] = useState("");
  const [attendance, setAttendance] = useState<AttendanceRecord[]>([]);
  const [stats, setStats] = useState<AttendanceStats | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [profile, setProfile] = useState<{ className: string; rollNo: string } | null>(null);

  useEffect(() => {
    const getLocalStorageData = () => {
      try {
        const className = localStorage.getItem("className");
        const rollNo = localStorage.getItem("rollNo");
        
        if (!className || !rollNo) {
          setError("Please complete your profile first");
          return;
        }

        setProfile({ className, rollNo });
      } catch (error) {
        setError("Error accessing browser storage");
      }
    };

    getLocalStorageData();
  }, []);

  useEffect(() => {
    const fetchCourses = async () => {
      try {
        if (!profile) return;
        
        const response = await fetch("/api/Component/S/Courses", {
          headers: { 
            className: profile.className 
          }
        });
        
        const data = await response.json();
        setCourses(data);
      } catch (err: any) {
        setError(err.message);
      }
    };

    if (profile) fetchCourses();
  }, [profile]);

  useEffect(() => {
    const fetchAttendance = async () => {
      try {
        if (!selectedCourse || !profile) return;
        
        setLoading(true);
        const response = await fetch(
          `/api/Component/S/Attendance?className=${encodeURIComponent(profile.className)}&rollNo=${profile.rollNo}&course=${encodeURIComponent(selectedCourse)}`
        );

        const { stats, records } = await response.json();
        setStats(stats);
        setAttendance(records);
      } catch (err: any) {
        setError(err.message);
      } finally {
        setLoading(false);
      }
    };

    fetchAttendance();
  }, [selectedCourse, profile]);

  if (!profile) {
    return <div className="text-red-500 text-center p-8">Please complete your profile first</div>;
  }


  return (
    <div className="min-h-screen p-8 bg-gradient-to-br from-[#f0fdfa] to-[#e0f8f5]">
      <div className="max-w-7xl mx-auto">
        <h1 className="text-3xl font-bold text-[#0F6466] mb-4 text-center">
          Attendance Portal
        </h1>
        <div className="text-center mb-8 text-gray-600">
          <p>Class: {profile.className}</p>
          <p>Roll Number: {profile.rollNo}</p>
        </div>

        {/* Course Selection */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mb-8">
          {courses.map((course, index) => (
            <button
              key={course.course}
              onClick={() => setSelectedCourse(course.course)}
              className={`p-3 rounded-lg transition-all transform ${
                selectedCourse === course.course
                  ? "ring-2 ring-[#0F6466] scale-[1.02]"
                  : "hover:scale-95"
              } bg-gradient-to-br ${
                [
                  "from-[#0F6466] to-[#2D9F9C]",
                  "from-[#4C6EF5] to-[#748FFC]",
                  "from-[#7950F2] to-[#9775FA]",
                  "from-[#F76707] to-[#FF922B]"
                ][index % 4]
              }`}
            >
              <h2 className="text-white font-medium text-sm md:text-base text-center">
                {course.course}
              </h2>
            </button>
          ))}
        </div>

        {/* Attendance Display */}
        {selectedCourse && (
          <div className="bg-white rounded-xl shadow-lg p-4 md:p-6">
            {loading ? (
              <div className="text-center text-[#0F6466] py-4">Loading attendance data...</div>
            ) : error ? (
              <div className="text-red-500 text-center p-4">{error}</div>
            ) : (
              <>
                {/* Stats Card */}
                <div className="mb-6 p-4 bg-gradient-to-br from-[#0F6466] to-[#2D9F9C] rounded-xl text-white">
                  <div className="flex flex-col md:flex-row items-center justify-between gap-4">
                    <div className="relative w-28 h-28">
                      <div 
                        className="absolute inset-0 rounded-full"
                        style={{
                          background: `conic-gradient(#2D9F9C ${(stats?.percentage || 0) * 3.6}deg, #f0fdfa 0deg)`
                        }}
                      >
                        <div className="absolute inset-1.5 bg-white rounded-full flex items-center justify-center">
                          <span className="text-xl font-bold text-[#0F6466]">
                            {stats?.percentage}%
                          </span>
                        </div>
                      </div>
                    </div>

                    <div className="space-y-1 text-center md:text-left">
                      <p className="text-sm">Total Classes: {stats?.totalClasses}</p>
                      <p className="text-sm">Present: {stats?.presents}</p>
                      <p className="text-sm">Absent: {stats?.absents}</p>
                      <p className="text-sm">Leaves: {stats?.leaves}</p>
                    </div>
                  </div>
                </div>

                {/* Attendance Records */}
                <div className="space-y-3">
                  {attendance.map((record, index) => (
                    <div 
                      key={`${record.date}-${index}`}
                      className="p-3 rounded-lg border border-[#0F6466]/10 hover:bg-gray-50 transition-colors"
                    >
                      <div className="flex justify-between items-center">
                        <div>
                          <p className="font-medium text-[#0F6466] text-sm">
                            {new Date(record.date).toLocaleDateString()}
                          </p>
                          <p className="text-xs text-gray-500">{record.time}</p>
                          <p className="text-xs text-gray-600 mt-1">{record.room}</p>
                        </div>
                        <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                          record.status === "P" 
                            ? "bg-green-100 text-green-800"
                            : record.status === "A"
                            ? "bg-red-100 text-red-800"
                            : "bg-yellow-100 text-yellow-800"
                        }`}>
                          {record.status === "P" ? "Present" : record.status === "A" ? "Absent" : "Leave"}
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              </>
            )}
          </div>
        )}
      </div>
    </div>
  );
}