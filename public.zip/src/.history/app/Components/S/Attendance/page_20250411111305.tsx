"use client";

import React, { useEffect, useState } from "react";

interface Course {
  course: string;
  teacher: string;
  teacherId: string;
}

interface AttendanceRecord {
  date: string;
  time: string;
  status: string;
  course: string;
  room: string;
}

interface AttendanceStats {
  totalClasses: number;
  presents: number;
  absents: number;
  leaves: number;
  percentage: number;
}

export default function Attendance() {
  const [courses, setCourses] = useState<Course[]>([]);
  const [selectedCourse, setSelectedCourse] = useState("");
  const [attendance, setAttendance] = useState<AttendanceRecord[]>([]);
  const [stats, setStats] = useState<AttendanceStats | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  // Get student information from localStorage
  const classLevel = localStorage.getItem("classLevel");
  const classType = localStorage.getItem("classType");
  const rollNo = localStorage.getItem("rollNo");
  const className = classType;

  // Fetch enrolled courses
  useEffect(() => {
    const fetchCourses = async () => {
      try {
        const response = await fetch("/api/Component/S/Courses", {
          headers: { classLevel: classLevel || "", classType: classType || "" }
        });
        
        if (!response.ok) throw new Error("Failed to fetch courses");
        const data = await response.json();
        setCourses(data);
      } catch (err: any) {
        setError(err.message);
      }
    };

    if (classLevel && classType) fetchCourses();
  }, [classLevel, classType]);

  // Fetch attendance when course is selected
  useEffect(() => {
    const fetchAttendance = async () => {
      try {
        if (!selectedCourse || !className || !rollNo) return;
        
        setLoading(true);
        const response = await fetch(
          `/api/Component/S/Attendance?className=${encodeURIComponent(className)}&rollNo=${rollNo}&course=${encodeURIComponent(selectedCourse)}`
        );

        if (!response.ok) throw new Error("Failed to fetch attendance");
        const { stats, records } = await response.json();
        
        setStats(stats);
        setAttendance(records);
      } catch (err: any) {
        setError(err.message);
      } finally {
        setLoading(false);
      }
    };

    fetchAttendance();
  }, [selectedCourse, className, rollNo]);

  if (!classLevel || !classType || !rollNo) {
    return <div className="text-red-500 text-center p-8">Please login first</div>;
  }

  return (
    <div className="min-h-screen p-8 bg-gradient-to-br from-[#f0fdfa] to-[#e0f8f5]">
      <h1 className="text-3xl font-bold text-[#0F6466] mb-8 text-center">
        Attendance Portal
      </h1>

      {/* Course Selection */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
        {courses.map((course, index) => (
          <button
            key={index}
            onClick={() => setSelectedCourse(course.course)}
            className={`p-4 rounded-xl transition-all ${
              selectedCourse === course.course
                ? "ring-4 ring-[#0F6466] scale-105"
                : "hover:scale-95"
            } bg-gradient-to-br ${
              [
                "from-[#0F6466] to-[#2D9F9C]",
                "from-[#4C6EF5] to-[#748FFC]",
                "from-[#7950F2] to-[#9775FA]",
                "from-[#F76707] to-[#FF922B]"
              ][index % 4]
            }`}
          >
            <h2 className="text-white font-medium text-center">
              {course.course}
            </h2>
          </button>
        ))}
      </div>

      {/* Attendance Display */}
      {selectedCourse && (
        <div className="bg-white rounded-xl shadow-lg p-6">
          {loading ? (
            <div className="text-center text-[#0F6466]">Loading attendance...</div>
          ) : error ? (
            <div className="text-red-500 text-center">{error}</div>
          ) : (
            <>
              {/* Stats Card */}
              <div className="mb-8 p-6 bg-gradient-to-br from-[#0F6466] to-[#2D9F9C] rounded-xl text-white">
                <div className="flex flex-col md:flex-row items-center justify-between">
                  {/* Percentage Circle */}
                  <div className="relative w-32 h-32 mb-4 md:mb-0">
                  <div 
  className="absolute inset-0 rounded-full"
  style={{
    background: `conic-gradient(#2D9F9C ${(stats?.percentage || 0) * 3.6}deg, #f0fdfa 0deg)`
  }}
>
                      <div className="absolute inset-2 bg-white rounded-full flex items-center justify-center">
                        <span className="text-2xl font-bold text-[#0F6466]">
                          {stats?.percentage}%
                        </span>
                      </div>
                    </div>
                  </div>

                  {/* Stats Details */}
                  <div className="space-y-2 text-center md:text-left">
                    <p>Total Classes: {stats?.totalClasses}</p>
                    <p>Present: {stats?.presents}</p>
                    <p>Absent: {stats?.absents}</p>
                    <p>Leaves: {stats?.leaves}</p>
                  </div>
                </div>
              </div>

              {/* Attendance Records */}
              <div className="space-y-4">
                {attendance.map((record, index) => (
                  <div 
                    key={index}
                    className="p-4 rounded-lg border border-[#0F6466]/20"
                  >
                    <div className="flex justify-between items-center">
                      <div>
                        <p className="font-semibold text-[#0F6466]">
                          {record.date}
                        </p>
                        <p className="text-sm text-gray-600">{record.time}</p>
                      </div>
                      <span className={`px-3 py-1 rounded-full text-sm ${
                        record.status === "P" 
                          ? "bg-green-100 text-green-800"
                          : record.status === "A"
                          ? "bg-red-100 text-red-800"
                          : "bg-yellow-100 text-yellow-800"
                      }`}>
                        {record.status}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            </>
          )}
        </div>
      )}
    </div>
  );
}