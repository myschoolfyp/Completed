import { NextResponse } from 'next/server';
import mongoose from 'mongoose';

export async function GET(request: Request) {
  try {
    await mongoose.connect(process.env.MONGODB_URI!);
    
    const { searchParams } = new URL(request.url);
    const className = searchParams.get("className")?.trim();
    const rollNo = searchParams.get("rollNo")?.trim();
    const course = searchParams.get("course")?.trim();

    if (!className || !rollNo || !course) {
      return NextResponse.json(
        { error: "Missing parameters" },
        { status: 400 }
      );
    }

    const attendanceRecords = await mongoose.models.Attendance.find({
      className: { $regex: new RegExp(`^${className}$`, "i") },
      course: { $regex: new RegExp(`^${course}$`, "i") }
    }).lean();

    const studentAttendance = attendanceRecords.flatMap((record) => 
      record.students
        .filter(student => student.rollNo.trim() === rollNo)
        .map(student => ({
          date: new Date(record.date).toISOString().split("T")[0],
          time: `${record.startTime} - ${record.endTime}`,
          status: student.status,
          course: record.course,
          room: record.room
        }))
    );


    // Calculate statistics
    const totalClasses = studentAttendance.length;
    const presents = studentAttendance.filter(a => a.status === "P").length;
    const absents = studentAttendance.filter(a => a.status === "A").length;
    const leaves = studentAttendance.filter(a => a.status === "L").length;
    const percentage = totalClasses > 0 
      ? Math.round((presents / totalClasses) * 100)
      : 0;

    return NextResponse.json({
      stats: { totalClasses, presents, absents, leaves, percentage },
      records: studentAttendance
    });

  } catch (error) {
    console.error("Database Error:", error);
    return NextResponse.json(
      { error: "Internal Server Error" },
      { status: 500 }
    );
  }
}