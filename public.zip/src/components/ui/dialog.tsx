"use client";

import React, { ReactNode } from "react";

export interface DialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  children: ReactNode;
}
export function Dialog({ open, onOpenChange, children }: DialogProps) {
  // Stub implementation—swap for a real modal if you like
  return <>{children}</>;
}

export interface DialogTriggerProps {
  asChild?: boolean;
  children: ReactNode;
}
export function DialogTrigger({ asChild, children }: DialogTriggerProps) {
  return <>{children}</>;
}

export interface DialogContentProps {
  className?: string;
  children: ReactNode;
}
export function DialogContent({ className = "", children }: DialogContentProps) {
  return <div className={className}>{children}</div>;
}

export interface DialogHeaderProps {
  children: ReactNode;
}
export function DialogHeader({ children }: DialogHeaderProps) {
  return <div className="pb-4 border-b">{children}</div>;
}

export interface DialogTitleProps {
  children: ReactNode;
}
export function DialogTitle({ children }: DialogTitleProps) {
  return <h2 className="text-xl font-bold">{children}</h2>;
}
