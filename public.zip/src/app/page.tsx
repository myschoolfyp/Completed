// src/app/page.tsx
import Image from "next/image";
import Link from "next/link";

export default function Home() {
  return (
    <div className="min-h-screen flex items-center bg-gradient-to-r from-[#D2E8E3] to-[#A8D5BA]">
      <div className="container mx-auto px-5 py-14 flex flex-col lg:flex-row items-center gap-11">
        {/* Image Section (Right Side) */}
        <div className="w-full lg:w-5/12 flex justify-center">
          <div className="relative w-72 md:w-80 lg:w-96 shadow-xl rounded-2xl overflow-hidden">
            <Image
              src="/images/image.png"
              alt="Children happily playing"
              width={600}
              height={440}
              quality={90}
              className="object-cover"
            />
          </div>
        </div>

        {/* Text Section (Left Side) */}
        <div className="w-full lg:w-7/12 text-center lg:text-left lg:pl-10 space-y-6">
          <h1 className="text-5xl font-extrabold text-[#0F6466] drop-shadow-lg leading-tight">
            School Management System
          </h1>
          <p className="text-base lg:text-lg text-gray-700 leading-relaxed max-w-xl">
            The ultimate platform for educators and parents to collaborate in nurturing student success.
          </p>
          <ul className="text-gray-700 list-disc list-inside space-y-2 text-base max-w-xl">
            <li>📋 Manage student records, attendance, and schedules</li>
            <li>📚 Share assignments, resources, and announcements</li>
            <li>🛡️ Parents can view all their children’s performance</li>
            <li>🔔 Instant notifications and feedback channels</li>
          </ul>
          <div className="mt-5 flex flex-col sm:flex-row justify-center lg:justify-start gap-5">
            <Link
              href="/Register"
              className="inline-block bg-gradient-to-r from-green-500 to-blue-500 hover:from-green-600 hover:to-blue-600 text-white font-semibold px-7 py-3.5 rounded-xl shadow-md transition-transform transform hover:scale-105"
            >
              Get Started
            </Link>
            <Link
              href="/Login"
              className="inline-block text-[#0F6466] font-semibold px-7 py-3.5 rounded-xl border-2 border-[#0F6466] hover:bg-[#0F6466] hover:text-white transition-colors"
            >
              Learn More
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
}
