// src/app/api/Component/S/Quiz/Submit/route.ts
import { NextResponse } from "next/server";
import mongoose from "mongoose";
import QuizModel from "@/models/Quiz";

const connectDB = async () => {
  if (mongoose.connection.readyState === 0) {
    await mongoose.connect(process.env.MONGODB_URI!);
  }
};

export async function GET(req: Request) {
  await connectDB();
  const { searchParams } = new URL(req.url);
  const quizId = searchParams.get("quizId");
  const rollNo = searchParams.get("rollNo") || "";
  if (!quizId) return NextResponse.error();

  // Note: we cast to `any` after lean()
  const quiz: any = await QuizModel.findById(quizId)
    .select([
      "quizTitle",
      "description",
      "totalMarks",
      "deadline",
      "key",   
      "mode",
      "questionCount",
      "timeLimit",
      "shortNote",
      "quizFile.fileName",
      "correctAnswers",
      "submissions",
    ])
    .lean();

  if (!quiz) {
    return NextResponse.json({ error: "Quiz not found" }, { status: 404 });
  }

  let submitted = false;
  let result: any = null;

  // find this student's submission
  const sub = Array.isArray(quiz.submissions)
    ? quiz.submissions.find((s: any) => s.rollNo === rollNo)
    : null;

  if (sub && Array.isArray(sub.answers)) {
    submitted = true;
    // grade
    const details = (quiz.correctAnswers as any[]).map((ca: any) => {
      const studentAns = sub.answers.find((a: any) => a.question === ca.question)
        ?.answer || "";
      return {
        question: ca.question,
        correctAnswer: ca.answer,
        studentAnswer: studentAns,
        isCorrect: studentAns === ca.answer,
      };
    });
    const obtainedMarks = details.filter((d: any) => d.isCorrect).length;
    result = { details, obtainedMarks, totalMarks: quiz.totalMarks };
  }

  return NextResponse.json({ quiz, submitted, result });
}

export async function POST(req: Request) {
  await connectDB();
  const contentType = req.headers.get("content-type") || "";

  if (contentType.includes("application/json")) {
    const body = await req.json();
    const { quizId, rollNo, studentName, answers } = body;
    if (
      !quizId ||
      !rollNo ||
      !studentName ||
      !Array.isArray(answers) ||
      answers.some((a: any) => typeof a.question !== "number" || typeof a.answer !== "string")
    ) {
      return NextResponse.json({ error: "Missing or invalid fields" }, { status: 400 });
    }

    // save submission
    const submission = { rollNo, studentName, submittedAt: new Date(), answers };
    const updated: any = await QuizModel.findByIdAndUpdate(
      quizId,
      { $push: { submissions: submission } },
      { new: true }
    ).lean();
    if (!updated) {
      return NextResponse.json({ error: "Quiz not found" }, { status: 404 });
    }

    // grade immediately
    const correctArr: any[] = updated.correctAnswers || [];
    const details = correctArr.map((ca: any) => {
      const stu = answers.find((a: any) => a.question === ca.question);
      const studentAnswer = stu?.answer || "";
      return {
        question: ca.question,
        correctAnswer: ca.answer,
        studentAnswer,
        isCorrect: studentAnswer === ca.answer,
      };
    });
    const obtainedMarks = details.filter((d: any) => d.isCorrect).length;

    return NextResponse.json({
      message: "Submission saved",
      result: { details, obtainedMarks, totalMarks: updated.totalMarks },
    }, { status: 201 });
  }

  // multipart/form-data (offline)
  const form = await req.formData();
  const quizId = form.get("quizId")?.toString();
  const rollNo = form.get("rollNo")?.toString();
  const studentName = form.get("studentName")?.toString();
  const submissionText = form.get("submissionText")?.toString();
  const fileField = form.get("submissionFile");

  if (!quizId || !rollNo || !studentName) {
    return NextResponse.json({ error: "Missing fields" }, { status: 400 });
  }

  let fileData;
  if (fileField instanceof Blob && (fileField as any).size > 0) {
    const buf = Buffer.from(await fileField.arrayBuffer());
    fileData = {
      data: buf,
      contentType: fileField.type,
      fileName: (fileField as any).name,
    };
  }

  const submissionOffline: any = { rollNo, studentName, submittedAt: new Date() };
  if (submissionText) submissionOffline.submissionText = submissionText;
  if (fileData) submissionOffline.file = fileData;

  const updatedOffline: any = await QuizModel.findByIdAndUpdate(
    quizId,
    { $push: { submissions: submissionOffline } },
    { new: true }
  ).lean();
  if (!updatedOffline) {
    return NextResponse.json({ error: "Quiz not found" }, { status: 404 });
  }

  return NextResponse.json({ message: "Offline submission saved" }, { status: 201 });
}
