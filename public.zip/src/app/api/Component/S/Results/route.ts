import { NextResponse } from "next/server";
import mongoose from "mongoose";
import ResultModel from "@/models/Result";

const connectDB = async () => {
  if (mongoose.connection.readyState === 0) {
    await mongoose.connect(process.env.MONGODB_URI!);
  }
};

export async function GET(request: Request) {
  try {
    await connectDB();
    const { searchParams } = new URL(request.url);
    const className = searchParams.get("className");
    const course = searchParams.get("course");

    if (!className) {
      return NextResponse.json(
        { error: "Missing className" },
        { status: 400 }
      );
    }

    // If course provided, filter by both; otherwise return all for className
    
    const filter: any = { className };
    if (course) filter.course = course;

    const docs = await ResultModel
      .find(filter)
      .sort({ createdAt: -1 })
      .lean();

    return NextResponse.json(docs, { status: 200 });
  } catch (err: any) {
    console.error("GET /Component/S/Results error:", err);
    return NextResponse.json(
      { error: err.message || "Server error" },
      { status: 500 }
    );
  }
}
