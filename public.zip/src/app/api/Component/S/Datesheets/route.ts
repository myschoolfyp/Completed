// app/api/Component/S/Datesheets/route.ts
import { NextResponse } from "next/server";
import DatesheetModel from "@/models/Datesheet";
import connectDB from "@/lib/mongodb";

export async function GET(request: Request) {
  try {
    await connectDB();
    const { searchParams } = new URL(request.url);
    const className = searchParams.get("className");

    // If className is provided, filter the datesheets; otherwise, return an empty list.
    const datesheets = className
      ? await DatesheetModel.find({ className })
          .sort({ createdAt: -1 })
          .populate("classId", "className classLevel")
      : [];
      
    return NextResponse.json(datesheets);
  } catch (error) {
    return NextResponse.json(
      { error: "Failed to fetch datesheets" },
      { status: 500 }
    );
  }
}
