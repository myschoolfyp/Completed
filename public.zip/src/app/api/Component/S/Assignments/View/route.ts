// src/app/api/Component/S/Assignments/View/route.ts
import { NextResponse } from "next/server";
import mongoose, { Types } from "mongoose";
import AssignmentModel from "@/models/Assignment";

// --- adjust your URI as needed ---
const MONGO_URI = process.env.MONGODB_URI!;

// --- Typed shapes for lean() results ---
export interface Submission {
  rollNo: string;
  description: string;
  file?: {
    fileName: string;
    contentType: string;
    data: Buffer;
  };
  obtainedMarks?: number;
  submittedAt: string;
}

export interface AssignmentDoc {
  _id: Types.ObjectId;
  submissions: Submission[];
  // any other fields you expect on the assignment:
  [key: string]: any;
}

async function connectDB() {
  if (mongoose.connection.readyState === 0) {
    await mongoose.connect(MONGO_URI);
  }
}

export async function PUT(request: Request) {
  try {
    await connectDB();
    const formData = await request.formData();

    const assignmentId = formData.get("assignmentId")?.toString();
    const rollNo       = formData.get("rollNo")?.toString();

    if (!assignmentId || !rollNo) {
      return NextResponse.json(
        { error: "Missing required fields" },
        { status: 400 }
      );
    }

    // Process optional file upload
    let fileData: { data: Buffer; contentType: string; fileName: string } | undefined;
    const submissionFile = formData.get("submissionFile");
    if (submissionFile instanceof Blob) {
      const buf = Buffer.from(await submissionFile.arrayBuffer());
      fileData = {
        data: buf,
        contentType: submissionFile.type,
        fileName: submissionFile.name,
      };
    }

    // Build $set payload
    const updateData: Record<string, any> = {
      "submissions.$.description": formData.get("submissionText")?.toString(),
    };
    if (fileData) {
      updateData["submissions.$.file"] = fileData;
    }

    const updated = await AssignmentModel.findOneAndUpdate(
      {
        _id: new Types.ObjectId(assignmentId),
        "submissions.rollNo": rollNo,
      },
      { $set: updateData },
      { new: true }
    ).lean<AssignmentDoc>();

    if (!updated) {
      return NextResponse.json(
        { error: "Submission not found" },
        { status: 404 }
      );
    }

    // TS now knows `updated.submissions` exists
    const submission = updated.submissions.find((sub) => sub.rollNo === rollNo);

    return NextResponse.json({
      success: true,
      submission,
    });
  } catch (err) {
    console.error("PUT /View error:", err);
    return NextResponse.json(
      { error: "Internal Server Error" },
      { status: 500 }
    );
  }
}

export async function GET(request: Request) {
  try {
    await connectDB();
    const { searchParams } = new URL(request.url);
    const assignmentId = searchParams.get("assignmentId");
    const rollNo       = searchParams.get("rollNo");

    if (!assignmentId || !rollNo) {
      return NextResponse.json(
        { error: "Missing required parameters" },
        { status: 400 }
      );
    }

    const assignment = await AssignmentModel.findOne(
      {
        _id: new Types.ObjectId(assignmentId),
        "submissions.rollNo": rollNo,
      }
    )
      .lean<AssignmentDoc>();

    if (!assignment) {
      return NextResponse.json(
        { error: "Submission not found" },
        { status: 404 }
      );
    }

    const submission = assignment.submissions.find((sub) => sub.rollNo === rollNo);

    return NextResponse.json({ submission });
  } catch (err) {
    console.error("GET /View error:", err);
    return NextResponse.json(
      { error: "Internal Server Error" },
      { status: 500 }
    );
  }
}
