// app/api/Component/P/Attendance/route.ts

import { NextResponse } from "next/server";

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url);
    const cnic = searchParams.get("cnic");
    if (!cnic) {
      return NextResponse.json(
        { error: "cnic query parameter is required" },
        { status: 400 }
      );
    }

    const origin = new URL(request.url).origin;

    // 1) Get children
    const childrenRes = await fetch(
      `${origin}/api/Component/P/Children?cnic=${encodeURIComponent(cnic)}`
    );
    if (!childrenRes.ok) {
      const err = await childrenRes.json();
      return NextResponse.json(
        { error: err.message || "Failed to fetch children" },
        { status: childrenRes.status }
      );
    }
    const { parentName, students } = await childrenRes.json();

    // 2) Get courses per child
    const coursesRes = await fetch(
      `${origin}/api/Component/P/Courses?cnic=${encodeURIComponent(cnic)}`
    );
    if (!coursesRes.ok) {
      const err = await coursesRes.json();
      return NextResponse.json(
        { error: err.error || "Failed to fetch courses" },
        { status: coursesRes.status }
      );
    }
    const { children: courseData } = await coursesRes.json();
    const courseMap = new Map<string, string[]>();
    courseData.forEach((c: any) => {
      courseMap.set(c._id, c.courses);
    });

    // 3) For each child × each course, fetch attendance and compute %
    const childrenAttendance = await Promise.all(
      students.map(async (stu: any) => {
        const stuCourses = courseMap.get(stu._id) || [];
        const attendances = await Promise.all(
          stuCourses.map(async (course: string) => {
            const attRes = await fetch(
              `${origin}/api/Component/S/Attendance?className=${encodeURIComponent(
                stu.className
              )}&course=${encodeURIComponent(course)}`
            );
            if (!attRes.ok) {
              return { course, records: [], percentage: 0 };
            }
            const sessions = await attRes.json(); // array of { date, startTime, endTime, students: [{rollNo,status}] }

            // Build this student’s per‑session status
            const records = sessions.map((s: any) => ({
              date: s.date,
              startTime: s.startTime,
              endTime: s.endTime,
              status: s.students.find((x: any) => x.rollNo === stu.rollNo)?.status || "A",
            }));

            const presentCount = records.filter((r: { status: string }) => r.status === "P").length;
            const pct =
              sessions.length > 0
                ? Math.round((presentCount / sessions.length) * 100)
                : 0;

            return { course, records, percentage: pct };
          })
        );
        return { ...stu, courses: attendances };
      })
    );

    return NextResponse.json({ parentName, children: childrenAttendance });
  } catch (error: any) {
    console.error("P/Attendance Error:", error);
    return NextResponse.json(
      { error: "Internal Server Error" },
      { status: 500 }
    );
  }
}
