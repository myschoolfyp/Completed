// app/api/Component/P/Courses/route.ts

import { NextResponse } from "next/server";

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url);
    const cnic = searchParams.get("cnic");
    if (!cnic) {
      return NextResponse.json(
        { error: "cnic query parameter is required" },
        { status: 400 }
      );
    }

    const origin = new URL(request.url).origin;

    // 1) fetch the list of children
    const childrenRes = await fetch(
      `${origin}/api/Component/P/Children?cnic=${encodeURIComponent(cnic)}`
    );
    if (!childrenRes.ok) {
      const err = await childrenRes.json();
      return NextResponse.json(
        { error: err.error || "Failed to fetch children" },
        { status: childrenRes.status }
      );
    }
    const { parentName, students } = await childrenRes.json();

    // 2) for each child, fetch their courses
    const childrenCourses = await Promise.all(
      students.map(async (stu: any) => {
        const crRes = await fetch(
          `${origin}/api/Component/S/Courses?className=${encodeURIComponent(
            stu.className
          )}`
        );
        if (!crRes.ok) {
          return { ...stu, courses: [], error: "Not found" };
        }
        const { courses } = await crRes.json();
        return { ...stu, courses };
      })
    );

    return NextResponse.json({
      parentName,
      children: childrenCourses,
    });
  } catch (error: any) {
    console.error("P/Courses Error:", error);
    return NextResponse.json(
      { error: "Internal Server Error" },
      { status: 500 }
    );
  }
}
