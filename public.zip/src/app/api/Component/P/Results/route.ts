import { NextResponse } from "next/server";
import mongoose from "mongoose";

const ResultModel = require("@/models/Result").default;

const connectDB = async () => {
  if (mongoose.connection.readyState === 0) {
    await mongoose.connect(process.env.MONGODB_URI!);
  }
};

export async function GET(request: Request) {
  try {
    await connectDB();
    const { searchParams } = new URL(request.url);
    const cnic = searchParams.get("cnic");
    if (!cnic) {
      return NextResponse.json(
        { error: "cnic query parameter is required" },
        { status: 400 }
      );
    }

    const origin = new URL(request.url).origin;

    // 1) fetch children via existing endpoint
    const childrenRes = await fetch(
      `${origin}/api/Component/P/Children?cnic=${encodeURIComponent(cnic)}`
    );
    if (!childrenRes.ok) {
      const err = await childrenRes.json();
      return NextResponse.json(
        { error: err.error || "Failed to fetch children" },
        { status: childrenRes.status }
      );
    }
    const { parentName, students } = await childrenRes.json();

    // 2) for each child, grab all results for their class, then filter to their rollNo
    const childrenResults = await Promise.all(
      students.map(async (stu: any) => {
        const resDocs = await fetch(
          `${origin}/api/Component/S/Results?className=${encodeURIComponent(
            stu.className
          )}`
        );
        if (!resDocs.ok) {
          return { ...stu, results: [] };
        }
        const docs = (await resDocs.json()) as any[];
        const filtered = docs
          .map(doc => {
            const rec = doc.studentResults.find(
              (r: any) => r.rollNo === stu.rollNo
            );
            if (!rec) return null;
            return {
              datesheetName: doc.datesheetName,
              course: doc.course,
              date: doc.createdAt,
              totalMarks: doc.totalMarks,
              obtainedMarks: rec.obtainedMarks,
              grade: rec.grade,
            };
          })
          .filter(x => x !== null);

        return {
          _id: stu._id,
          firstName: stu.firstName,
          lastName: stu.lastName,
          className: stu.className,
          rollNo: stu.rollNo,
          results: filtered,
        };
      })
    );

    return NextResponse.json({ parentName, children: childrenResults });
  } catch (error: any) {
    console.error("P/Results Error:", error);
    return NextResponse.json(
      { error: "Internal Server Error" },
      { status: 500 }
    );
  }
}
