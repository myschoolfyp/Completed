// app/api/Component/P/Assignments/route.ts

import { NextResponse } from "next/server";

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url);
    const cnic = searchParams.get("cnic");
    if (!cnic) {
      return NextResponse.json(
        { error: "cnic query parameter is required" },
        { status: 400 }
      );
    }
    const origin = new URL(request.url).origin;

    // 1) fetch all children
    const kidsRes = await fetch(
      `${origin}/api/Component/P/Children?cnic=${encodeURIComponent(cnic)}`
    );
    if (!kidsRes.ok) {
      const e = await kidsRes.json();
      return NextResponse.json({ error: e.message || "Failed to fetch children" }, { status: kidsRes.status });
    }
    const { parentName, students } = await kidsRes.json();

    // 2) fetch their courses
    const coursesRes = await fetch(
      `${origin}/api/Component/P/Courses?cnic=${encodeURIComponent(cnic)}`
    );
    if (!coursesRes.ok) {
      const e = await coursesRes.json();
      return NextResponse.json({ error: e.error || "Failed to fetch courses" }, { status: coursesRes.status });
    }
    const { children: coursesData } = await coursesRes.json();
    const courseMap = new Map<string, string[]>();
    coursesData.forEach((c: any) => {
      courseMap.set(c._id, c.courses);
    });

    // 3) for each student × each course, pull assignments
    const childrenAssignments = await Promise.all(
      students.map(async (stu: any) => {
        const stuCourses = courseMap.get(stu._id) || [];
        const coursesWithAssignments = await Promise.all(
          stuCourses.map(async (course) => {
            const aRes = await fetch(
              `${origin}/api/Component/S/Assignments?className=${encodeURIComponent(
                stu.className
              )}&course=${encodeURIComponent(course)}`
            );
            if (!aRes.ok) {
              return { course, assignments: [] };
            }
            const assignments = await aRes.json();
            return { course, assignments };
          })
        );
        return { ...stu, courses: coursesWithAssignments };
      })
    );

    return NextResponse.json({ parentName, children: childrenAssignments });
  } catch (err: any) {
    console.error("P/Assignments Error:", err);
    return NextResponse.json(
      { error: "Internal Server Error" },
      { status: 500 }
    );
  }
}
