import { NextResponse } from 'next/server';
import mongoose from 'mongoose';
import Parent from '@/models/Parent';

// Define TypeScript interfaces for Parent and Student
interface Student {
  _id: string;
  rollNo: string;
  firstName: string;
  lastName: string;
  classLevel: string;
  className: string;
  classType: string;
}

interface ParentDocument extends mongoose.Document {
  firstName: string;
  lastName: string;
  cnic: string;
  students: Student[];
}

// Connect to the database
const connectToDatabase = async () => {
  if (mongoose.connection.readyState === 0) {
    await mongoose.connect(process.env.MONGODB_URI!);
  }
};

export async function GET(req: Request) {
  try {
    const { searchParams } = new URL(req.url);
    const cnic = searchParams.get('cnic');
    
    if (!cnic) {
      return NextResponse.json({ message: 'CNIC is required' }, { status: 400 });
    }

    await connectToDatabase();
    
    // Find the parent with students data
    const parent = await Parent.findOne({ cnic })
      .select('firstName lastName students')
      .lean<ParentDocument>(); // Add type hint for better TypeScript support

    if (!parent) {
      return NextResponse.json({ message: 'Parent not found' }, { status: 404 });
    }

    // Format students data
    const formattedStudents = parent.students.map((student: Student) => ({
      _id: student._id.toString(),
      rollNo: student.rollNo,
      firstName: student.firstName,
      lastName: student.lastName,
      classLevel: student.classLevel,
      className: student.className,
      classType: student.classType
    }));

    return NextResponse.json({
      parentName: `${parent.firstName} ${parent.lastName}`,
      students: formattedStudents
    });

  } catch (error) {
    console.error('Error fetching parent:', error);
    return NextResponse.json(
      { message: 'Internal server error' },
      { status: 500 }
    );
  }
}
