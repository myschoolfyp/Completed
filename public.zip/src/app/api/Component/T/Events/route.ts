// src/app/api/Component/T/Events/route.ts
import { NextResponse } from "next/server";
import dbConnect from "@/lib/mongodb"; // ✅ Correct path and usage
import Event from "@/models/Events";   // Ensure this path is valid

export async function GET(request: Request) {
  try {
    await dbConnect();

    const events = await Event.find().sort({ start: 1 }).lean();
    return NextResponse.json(events);
  } catch (error) {
    console.error("Error fetching events:", error);
    return NextResponse.json({ error: "Internal Server Error" }, { status: 500 });
  }
}
