// src/app/api/Component/T/Complain/route.ts
import { NextResponse } from "next/server";
import mongoose, { Types } from "mongoose";
import Complain from "@/models/Complain";

const MONGO_URI = "mongodb://localhost:27017";
const DB_NAME = "myschool";

async function connectDb() {
  if (mongoose.connection.readyState < 1) {
    await mongoose.connect(MONGO_URI, { dbName: DB_NAME });
  }
}

// --- Interfaces to type lean results ---
interface Reply {
  senderCnic: string;
  senderName: string;
  description: string;
  date: Date;
}

interface ComplainDoc {
  _id: Types.ObjectId;
  studentName: string;
  rollNo: string;
  className: string;
  description: string;
  createdAt: Date;
  parentReplies?: Reply[];
  teacherReplies?: Reply[];
}

export async function GET(request: Request) {
  const url = new URL(request.url);
  const teacherId = url.searchParams.get("teacherId");
  const sent = url.searchParams.get("sent");
  const replies = url.searchParams.get("replies");
  const classLevel = url.searchParams.get("classLevel");
  const className = url.searchParams.get("className");

  await connectDb();

  // --- Replies tab ---
  if (replies === "true") {
    if (!teacherId) {
      return NextResponse.json({ message: "teacherId required" }, { status: 400 });
    }
    const docs = await Complain.find({
      teacherId: new Types.ObjectId(teacherId),
      parentReplies: { $exists: true, $ne: [] }
    })
      .sort({ createdAt: -1 })
      .lean<ComplainDoc[]>();

    const out = docs.map(c => ({
      _id: c._id.toString(),
      studentName: c.studentName,
      rollNo: c.rollNo,
      className: c.className,
      description: c.description,
      createdAt: c.createdAt.toISOString(),
      parentReplies: (c.parentReplies || []).map((r: Reply) => ({
        senderCnic: r.senderCnic,
        senderName: r.senderName,
        description: r.description,
        date: r.date.toISOString()
      })),
      teacherReplies: (c.teacherReplies || []).map((r: Reply) => ({
        senderCnic: r.senderCnic,
        senderName: r.senderName,
        description: r.description,
        date: r.date.toISOString()
      }))
    }));

    return NextResponse.json(out);
  }

  // --- Sent tab ---
  if (sent === "true") {
    if (!teacherId) {
      return NextResponse.json({ message: "teacherId required" }, { status: 400 });
    }

    const docs = await Complain.find({
      teacherId: new Types.ObjectId(teacherId)
    })
      .sort({ createdAt: -1 })
      .lean<ComplainDoc[]>();

    const out = docs.map(c => ({
      _id: c._id.toString(),
      studentName: c.studentName,
      rollNo: c.rollNo,
      className: c.className,
      description: c.description,
      createdAt: c.createdAt.toISOString()
    }));

    return NextResponse.json(out);
  }

  // --- New entries for complaint creation ---
  if (classLevel && className) {
    const levelNum = parseInt(classLevel, 10);
    if (isNaN(levelNum)) {
      return NextResponse.json({ message: "classLevel must be a number" }, { status: 400 });
    }

    const db = mongoose.connection.db;
    if (!db) {
      return NextResponse.json({ message: "Database not connected" }, { status: 500 });
    }

    const parents = await db
      .collection("parents")
      .find({ "students.classLevel": levelNum })
      .toArray();

    const entries = parents.flatMap((p: any) =>
      p.students
        .filter((s: any) => s.classLevel === levelNum)
        .map((s: any) => ({
          studentId: s._id.toString(),
          rollNo: s.rollNo,
          studentName: `${s.firstName} ${s.lastName}`,
          parentName: `${p.firstName} ${p.lastName}`,
          parentCnic: p.cnic
        }))
    );

    return NextResponse.json(entries);
  }

  return NextResponse.json({ message: "Invalid query" }, { status: 400 });
}

export async function POST(request: Request) {
  const url = new URL(request.url);
  await connectDb();

  // --- Reply handler ---
  if (url.pathname.endsWith("/Reply")) {
    const { complaintId, teacherId, teacherName, description } = await request.json();
    if (!complaintId || !teacherId || !teacherName || !description) {
      return NextResponse.json(
        { message: "complaintId, teacherId, teacherName & description required" },
        { status: 400 }
      );
    }
    const reply = {
      senderCnic: teacherId,
      senderName: teacherName,
      description,
      date: new Date()
    };
    await Complain.updateOne(
      { _id: new Types.ObjectId(complaintId) },
      { $push: { teacherReplies: reply } }
    );
    return NextResponse.json({ ...reply, date: reply.date.toISOString() }, { status: 201 });
  }

  // --- New complaints handler ---
  const {
    studentIds,
    description,
    classLevel,
    className,
    teacherId,
    teacherName
  } = await request.json();

  if (
    !studentIds?.length ||
    !description ||
    !classLevel ||
    !className ||
    !teacherId ||
    !teacherName
  ) {
    return NextResponse.json({ message: "Missing required fields" }, { status: 400 });
  }

  const db = mongoose.connection.db;
  if (!db) {
    return NextResponse.json({ message: "Database not connected" }, { status: 500 });
  }

  const students = await db
    .collection("students")
    .find({
      _id: { $in: studentIds.map((id: string) => new Types.ObjectId(id)) }
    })
    .toArray();

  const complaints = await Promise.all(
    students.map(async (student: any) => {
      const parent = await db
        .collection("parents")
        .findOne({ "students._id": student._id });
      if (!parent) throw new Error(`Parent not found for student ${student._id}`);
      return new Complain({
        studentId: student._id,
        studentName: `${student.firstName} ${student.lastName}`,
        rollNo: student.rollNo,
        className,
        parentName: `${parent.firstName} ${parent.lastName}`,
        parentCnic: parent.cnic,
        teacherId: new Types.ObjectId(teacherId),
        teacherName,
        description,
        createdAt: new Date()
      }).save();
    })
  );

  return NextResponse.json({ success: true, count: complaints.length });
}

export async function DELETE(request: Request) {
  await connectDb();
  const { complaintId, teacherId } = await request.json();
  if (!complaintId || !teacherId) {
    return NextResponse.json({ message: "complaintId and teacherId required" }, { status: 400 });
  }
  const res = await Complain.deleteOne({
    _id: new Types.ObjectId(complaintId),
    teacherId: new Types.ObjectId(teacherId)
  });
  if (res.deletedCount === 0) {
    return NextResponse.json({ message: "Not found or not yours" }, { status: 404 });
  }
  return NextResponse.json({ success: true });
}
