import { NextResponse } from "next/server";
import mongoose from "mongoose";
import ResultModel from "@/models/Result";
import DatesheetModel from "@/models/Datesheet";
import ClassModel from "@/models/Class";

// inline DB connect to avoid a missing import
const connectDB = async () => {
  if (mongoose.connection.readyState === 0) {
    await mongoose.connect(process.env.MONGODB_URI!);
  }
};

export async function GET(req: Request) {
  try {
    await connectDB();
    const { searchParams } = new URL(req.url);
    const action = searchParams.get("action");

    if (action === "fetchDatesheets") {
      const datesheets = await DatesheetModel.find(
        {},
        "datesheetName className"
      )
        .lean();
      return NextResponse.json(datesheets);
    }

    if (action === "fetchClasses") {
      const datesheetName = searchParams.get("datesheetName");
      if (!datesheetName) {
        return NextResponse.json(
          { error: "Datesheet name is required" },
          { status: 400 }
        );
      }
      const ds = await DatesheetModel.findOne({ datesheetName });
      if (!ds) {
        return NextResponse.json(
          { error: "Datesheet not found" },
          { status: 404 }
        );
      }
      const classes = await ClassModel.find({
        className: ds.className,
      })
        .lean();
      return NextResponse.json(classes);
    }

    return NextResponse.json(
      { error: "Invalid action parameter" },
      { status: 400 }
    );
  } catch (err) {
    console.error("GET error:", err);
    return NextResponse.json(
      { error: "Failed to fetch data" },
      { status: 500 }
    );
  }
}

export async function POST(req: Request) {
  try {
    await connectDB();
    const { datesheetName, className, rollNo } = await req.json();

    if (!datesheetName || !className || !rollNo) {
      return NextResponse.json(
        { error: "Missing required parameters" },
        { status: 400 }
      );
    }

    const ds = await DatesheetModel.findOne({ datesheetName });
    if (!ds) {
      return NextResponse.json(
        { error: "Datesheet not found" },
        { status: 404 }
      );
    }

    const cls = await ClassModel.findOne({ className });
    if (!cls) {
      return NextResponse.json(
        { error: "Class not found" },
        { status: 404 }
      );
    }

    const results = await ResultModel.find({
      datesheetName,
      className,
    }).lean();

    if (results.length === 0) {
      return NextResponse.json(
        { error: "No results found for this datesheet and class" },
        { status: 404 }
      );
    }

    // filter down to just the one student's records
    const studentRecords = results
      .map((res) => {
        const found = res.studentResults.find(
          (r: any) => r.rollNo === rollNo
        );
        return (
          found && {
            course: res.course,
            totalMarks: res.totalMarks,
            obtainedMarks: found.obtainedMarks,
            grade: found.grade,
          }
        );
      })
      .filter(Boolean);

    if (studentRecords.length === 0) {
      return NextResponse.json(
        {
          error: `No results found for student with roll number ${rollNo}`,
        },
        { status: 404 }
      );
    }

    return NextResponse.json({ records: studentRecords });
  } catch (err) {
    console.error("POST error:", err);
    return NextResponse.json(
      { error: "Failed to fetch student result" },
      { status: 500 }
    );
  }
}
