// /api/Component/A/Students/route.ts

import { NextResponse } from "next/server";
import { MongoClient, ObjectId } from "mongodb";
import bcrypt from "bcryptjs";

const mongoUri = "mongodb://localhost:27017/myschool";

export async function GET(request: Request) {
  let client: MongoClient | null = null;
  try {
    client = new MongoClient(mongoUri);
    await client.connect();
    const db = client.db();

    const url = new URL(request.url);
    const rollNoParam = url.searchParams.get("rollNo");
    if (rollNoParam) {
      // Lookup by rollNo
      const student = await db
        .collection("students")
        .findOne(
          { rollNo: rollNoParam },
          { projection: { password: 0, profilePicture: 0 } }
        );
      if (!student) {
        return NextResponse.json(
          { message: "Student not found", error: true },
          { status: 404 }
        );
      }
      const serialized = { ...student, _id: student._id.toString() };
      return NextResponse.json(serialized, { status: 200 });
    }

    // Return all (exclude password & profilePicture)
    const all = await db
      .collection("students")
      .find({}, { projection: { password: 0, profilePicture: 0 } })
      .toArray();
    const serializedAll = all.map(s => ({ ...s, _id: s._id.toString() }));
    return NextResponse.json(serializedAll, { status: 200 });
  } catch (err: any) {
    console.error("GET /Students error:", err);
    return NextResponse.json(
      { message: "Internal server error", error: true },
      { status: 500 }
    );
  } finally {
    client?.close();
  }
}

export async function POST(request: Request) {
  let client: MongoClient | null = null;
  try {
    const { rollNo, firstName, lastName, password, email, contactNumber, classLevel } =
      await request.json();

    // Validation
    if (
      !rollNo || !firstName || !lastName ||
      !password || !email || !contactNumber || !classLevel
    ) {
      return NextResponse.json(
        { message: "All fields are required", error: true },
        { status: 400 }
      );
    }
    if (!/^\d{9}$/.test(rollNo)) {
      return NextResponse.json(
        { message: "Roll No must be 9 digits", error: true },
        { status: 400 }
      );
    }
    if (!/^[A-Za-z]+$/.test(firstName) || !/^[A-Za-z]+$/.test(lastName)) {
      return NextResponse.json(
        { message: "Names must contain letters only", error: true },
        { status: 400 }
      );
    }
    if (!email.includes("@")) {
      return NextResponse.json(
        { message: "Email must include @", error: true },
        { status: 400 }
      );
    }

    client = new MongoClient(mongoUri);
    await client.connect();
    const db = client.db();

    // Duplicate check
    const exists = await db.collection("students").findOne({ rollNo });
    if (exists) {
      return NextResponse.json(
        { message: "Roll No already exists", error: true },
        { status: 409 }
      );
    }

    // **HASH THE PASSWORD**
    const hashedPassword = await bcrypt.hash(password, 10);

    // Default classType = "General"
    const result = await db.collection("students").insertOne({
      rollNo,
      firstName,
      lastName,
      password: hashedPassword,
      email,
      contactNumber,
      classLevel,
      classType: "General"
    });

    return NextResponse.json(
      { message: "Student added", id: result.insertedId.toString(), error: false },
      { status: 201 }
    );
  } catch (err) {
    console.error("POST /Students error:", err);
    return NextResponse.json(
      { message: "Internal server error", error: true },
      { status: 500 }
    );
  } finally {
    client?.close();
  }
}

export async function DELETE(request: Request) {
  let client: MongoClient | null = null;
  try {
    const { id } = await request.json();
    if (!id) {
      return NextResponse.json(
        { message: "Student ID is required", error: true },
        { status: 400 }
      );
    }
    client = new MongoClient(mongoUri);
    await client.connect();
    const result = await client
      .db()
      .collection("students")
      .deleteOne({ _id: new ObjectId(id) });
    if (result.deletedCount === 0) {
      return NextResponse.json(
        { message: "Student not found", error: true },
        { status: 404 }
      );
    }
    return NextResponse.json(
      { message: "Student deleted", error: false },
      { status: 200 }
    );
  } catch (err) {
    console.error("DELETE /Students error:", err);
    return NextResponse.json(
      { message: "Internal server error", error: true },
      { status: 500 }
    );
  } finally {
    client?.close();
  }
}

export async function PUT(request: Request) {
  let client: MongoClient | null = null;
  try {
    const { id, firstName, lastName, password, email, contactNumber, classLevel } =
      await request.json();

    if (!id || !firstName || !lastName || !email || !contactNumber || !classLevel) {
      return NextResponse.json(
        { message: "Missing required fields", error: true },
        { status: 400 }
      );
    }

    client = new MongoClient(mongoUri);
    await client.connect();

    // Build update object
    const updateObj: any = { firstName, lastName, email, contactNumber, classLevel };

    // **HASH NEW PASSWORD IF PROVIDED**
    if (password) {
      updateObj.password = await bcrypt.hash(password, 10);
    }

    const result = await client
      .db()
      .collection("students")
      .updateOne({ _id: new ObjectId(id) }, { $set: updateObj });

    if (result.matchedCount === 0) {
      return NextResponse.json(
        { message: "Student not found", error: true },
        { status: 404 }
      );
    }

    return NextResponse.json(
      { message: "Student updated", error: false },
      { status: 200 }
    );
  } catch (err) {
    console.error("PUT /Students error:", err);
    return NextResponse.json(
      { message: "Internal server error", error: true },
      { status: 500 }
    );
  } finally {
    client?.close();
  }
}
