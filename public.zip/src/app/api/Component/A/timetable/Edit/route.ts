import { NextResponse } from "next/server";
import mongoose from "mongoose";
import TimetableModel from "@/models/Timetable";

const connectDB = async () => {
  if (mongoose.connection.readyState === 0) {
    await mongoose.connect(process.env.MONGODB_URI!);
  }
};

export async function GET(request: Request) {
  await connectDB();
  const { searchParams } = new URL(request.url);
  const id = searchParams.get("timetableId");
  if (!id) {
    return NextResponse.json({ error: "Missing timetableId" }, { status: 400 });
  }
  const tt = await TimetableModel.findById(id).lean();
  if (!tt) {
    return NextResponse.json({ error: "Not found" }, { status: 404 });
  }
  return NextResponse.json(tt);
}

export async function PUT(request: Request) {
  await connectDB();
  const body = await request.json();
  const { _id, days, breakTime } = body;
  if (!_id || !Array.isArray(days) || !breakTime) {
    return NextResponse.json({ error: "Invalid payload" }, { status: 400 });
  }
  const updated = await TimetableModel.findByIdAndUpdate(
    _id,
    { $set: { days, breakTime } },
    { new: true, runValidators: true }
  );
  if (!updated) {
    return NextResponse.json({ error: "Update failed" }, { status: 500 });
  }
  return NextResponse.json({ success: true, message: "Updated!", timetable: updated });
}
