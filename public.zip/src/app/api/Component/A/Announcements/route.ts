// src/app/api/Component/A/Announcements/route.ts
import { NextResponse } from "next/server";
import { MongoClient, ObjectId } from "mongodb";

const MONGO_URI = "mongodb://localhost:27017";
const DB_NAME   = "myschool";
const COLL_NAME = "announcements";

async function connectDb() {
  const client = new MongoClient(MONGO_URI);
  await client.connect();
  return client.db(DB_NAME);
}

export async function GET(request: Request) {
  const url    = new URL(request.url);
  const sender = url.searchParams.get("sender") || undefined;
  const db     = await connectDb();
  const filter = sender ? { sender } : {};
  const docs   = await db
    .collection(COLL_NAME)
    .find(filter)
    .sort({ date: -1 })
    .toArray();

  // ensure dates are serialized to ISO strings
  const out = docs.map(d => ({
    _id: d._id.toString(),
    stream: d.stream,
    sender: d.sender,
    description: d.description,
    recipients: d.recipients,
    date: d.date.toISOString(),
    replies: Array.isArray(d.replies)
      ? d.replies.map(r => ({
          senderCnic: r.senderCnic,
          senderName: r.senderName,
          description: r.description,
          date: (r.date as Date).toISOString(),
        }))
      : [],
  }));

  return NextResponse.json(out);
}

export async function POST(request: Request) {
  const db   = await connectDb();
  const form = await request.formData();

  const stream      = form.get("stream") as string;
  const sender      = form.get("sender") as string;
  const description = form.get("description") as string;
  const recipients  = JSON.parse(form.get("recipients") as string) as string[];

  let attachment: { data: Buffer; name: string } | undefined;
  const file = form.get("attachment") as Blob | null;
  if (file && file.size > 0) {
    const buf = await file.arrayBuffer();
    attachment = {
      data: Buffer.from(buf),
      name: (file as any).name || "attachment",
    };
  }

  const doc: any = {
    stream,
    sender,
    description,
    recipients,
    date: new Date(),
    ...(attachment ? { attachment } : {}),
  };

  const result = await db.collection(COLL_NAME).insertOne(doc);
  return NextResponse.json(
    { ...doc, _id: result.insertedId.toString() },
    { status: 201 }
  );
}

export async function DELETE(request: Request) {
  const { id } = await request.json();
  if (!id) {
    return NextResponse.json(
      { message: "Announcement ID required", error: true },
      { status: 400 }
    );
  }
  const db     = await connectDb();
  const result = await db
    .collection(COLL_NAME)
    .deleteOne({ _id: new ObjectId(id) });

  if (result.deletedCount === 0) {
    return NextResponse.json(
      { message: "Announcement not found", error: true },
      { status: 404 }
    );
  }
  return NextResponse.json({ message: "Deleted", error: false }, { status: 200 });
}
