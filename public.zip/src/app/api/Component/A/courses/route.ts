// app/Components/A/Courses/route.ts
import { NextResponse } from "next/server";
import mongoose from "mongoose";
import Course from "@/models/Courses";

const connectToDatabase = async () => {
  if (mongoose.connection.readyState === 0) {
    await mongoose.connect(process.env.MONGODB_URI!);
  }
};

export async function GET(request: Request) {
  try {
    await connectToDatabase();
    const { action } = Object.fromEntries(new URL(request.url).searchParams);
    if (action === "fetchCourses") {
      const courses = await Course.find().exec();
      return NextResponse.json(courses);
    }
    return NextResponse.json({ error: "Invalid action" }, { status: 400 });
  } catch {
    return NextResponse.json({ error: "Server error" }, { status: 500 });
  }
}

export async function POST(request: Request) {
  try {
    await connectToDatabase();
    const { educationLevel, classLevel, newCourses } = await request.json();
    if (!educationLevel || !classLevel || !Array.isArray(newCourses)) {
      return NextResponse.json({ error: "Missing fields" }, { status: 400 });
    }
    if (newCourses.length > 10) {
      return NextResponse.json({ error: "Max 10 at once" }, { status: 400 });
    }
    const updated = await Course.findOneAndUpdate(
      { educationLevel, classLevel },
      { $addToSet: { courses: { $each: newCourses } } },
      { new: true, upsert: true }
    ).exec();
    return NextResponse.json({ success: true, data: updated });
  } catch {
    return NextResponse.json({ error: "Server error" }, { status: 500 });
  }
}

export async function DELETE(request: Request) {
  try {
    await connectToDatabase();
    const { educationLevel, classLevel, course } = await request.json();
    if (!educationLevel || !classLevel || !course) {
      return NextResponse.json({ error: "Missing fields" }, { status: 400 });
    }
    const updated = await Course.findOneAndUpdate(
      { educationLevel, classLevel },
      { $pull: { courses: course } },
      { new: true }
    ).exec();
    return NextResponse.json({ success: true, data: updated });
  } catch {
    return NextResponse.json({ error: "Server error" }, { status: 500 });
  }
}
