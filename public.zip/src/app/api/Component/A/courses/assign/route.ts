// src/app/Component/A/courses/assign/route.ts
import { NextResponse } from "next/server";
import mongoose from "mongoose";
import ClassModel from "@/models/Class";

// Connect to MongoDB once
async function connectToDatabase() {
  if (mongoose.connection.readyState === 0) {
    await mongoose.connect(process.env.MONGODB_URI!);
  }
}

// GET: return all classes (without students)
export async function GET() {
  try {
    await connectToDatabase();
    const classes = await ClassModel.find({}, { students: 0 }).exec();
    return NextResponse.json(classes);
  } catch (error) {
    console.error("Error fetching classes:", error);
    return NextResponse.json({ error: "Failed to fetch classes" }, { status: 500 });
  }
}

// POST: merge new courses into existing ones
export async function POST(request: Request) {
  try {
    await connectToDatabase();
    const body = await request.json();
    const updates = Array.isArray(body) ? body : [body];

    const ops = updates.map(async (cData) => {
      const { classLevel, className, stream, courses } = cData;
      if (!classLevel || !className || !stream || !Array.isArray(courses)) {
        throw new Error(`Invalid data for class ${className}`);
      }
      // Use addToSet with $each to avoid duplicates
      const updated = await ClassModel.findOneAndUpdate(
        { classLevel, className, stream },
        { $addToSet: { courses: { $each: courses } } },
        { new: true, runValidators: true }
      );
      if (!updated) {
        throw new Error(`Class not found: ${className}`);
      }
      return updated;
    });

    const updatedClasses = await Promise.all(ops);
    return NextResponse.json(
      {
        success: true,
        message:
          updatedClasses.length > 1
            ? "Courses merged into multiple classes!"
            : "Courses merged successfully!",
        updatedClasses,
      },
      { status: 200 }
    );
  } catch (err) {
    console.error("Error in POST:", err);
    const msg = err instanceof Error ? err.message : "Unexpected error";
    return NextResponse.json({ success: false, error: msg }, { status: 500 });
  }
}
