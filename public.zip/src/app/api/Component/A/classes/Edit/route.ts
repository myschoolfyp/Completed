import { NextResponse } from "next/server";
import { MongoClient, ObjectId } from "mongodb";

const mongoUri = "mongodb://localhost:27017/myschool";

async function connectDB() {
  const client = new MongoClient(mongoUri);
  await client.connect();
  return client.db();
}

export async function GET(req: Request) {
  try {
    const { searchParams } = new URL(req.url);
    const classId = searchParams.get("classId");
    if (!classId) {
      return NextResponse.json({ message: "Missing classId" }, { status: 400 });
    }

    const db = await connectDB();
    const cls = await db
      .collection("classes")
      .findOne({ _id: new ObjectId(classId) });
    if (!cls) {
      return NextResponse.json({ message: "Class not found" }, { status: 404 });
    }

    return NextResponse.json({
      classLevel: cls.classLevel,
      className:  cls.className,
      stream:     cls.stream,
      students:   cls.students,
      courses:    cls.courses || [],
    });
  } catch (error: any) {
    return NextResponse.json(
      { message: "Server error: " + error.message },
      { status: 500 }
    );
  }
}

export async function PUT(req: Request) {
  try {
    const body = await req.json();
    const { classId, classLevel, className, stream, students, courses } = body;

    if (!classId || !classLevel || !className) {
      return NextResponse.json(
        { message: "Missing required fields" },
        { status: 400 }
      );
    }

    const db = await connectDB();

    // 1. Update the class document
    const update: any = { classLevel, className, stream, updatedAt: new Date() };
    if (Array.isArray(students)) {
      update.students = await Promise.all(
        students.map(async (rollNo: string) => {
          const s = await db
            .collection("students")
            .findOne({ rollNo }, { projection: { firstName:1, lastName:1 } });
          return {
            _id:    s!._id,
            rollNo,
            name:   `${s!.firstName} ${s!.lastName}`
          };
        })
      );
    }
    if (Array.isArray(courses)) {
      update.courses = courses;
    }

    const result = await db
      .collection("classes")
      .updateOne({ _id: new ObjectId(classId) }, { $set: update });

    if (result.matchedCount === 0) {
      return NextResponse.json({ message: "Class not found" }, { status: 404 });
    }

    // 2. **New**: update the student documents themselves
    if (Array.isArray(students) && students.length > 0) {
      await db.collection("students").updateMany(
        { rollNo: { $in: students } },
        {
          $set: {
            classLevel,
            className,
            classType: stream,    // if `stream` maps to your `classType`
          }
        }
      );
    }

    return NextResponse.json({ message: "Updated successfully" });
  } catch (error: any) {
    return NextResponse.json(
      { message: "Server error: " + error.message },
      { status: 500 }
    );
  }
}
