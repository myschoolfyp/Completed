// @ts-nocheck
import { NextResponse } from "next/server";
import mongoose from "mongoose";
// @ts-ignore
import { v2 as cloudinary } from "cloudinary";
import Event from "@/models/Events";

const connectDB = async () => {
  if (mongoose.connection.readyState === 0) {
    await mongoose.connect(process.env.MONGODB_URI!);
  }
};

export async function GET() {
  await connectDB();
  try {
    const docs = await Event.find({}).lean();
    // convert buffer -> base64 dataURI
    const events = docs.map((e) => {
      let imageUrl = "";
      if (e.image?.data && e.image.contentType) {
        const b64 = Buffer.from(e.image.data).toString("base64");
        imageUrl = `data:${e.image.contentType};base64,${b64}`;
      }
      return {
        ...e,
        imageUrl,
      };
    });
    return NextResponse.json(events);
  } catch (err) {
    console.error("Fetch Events Error:", err);
    return NextResponse.json({ error: "Failed to fetch events" }, { status: 500 });
  }
}
export async function POST(req: Request) {
  await connectDB();

  const formData = await req.formData();
  const title = formData.get("title") as string;
  const description = formData.get("description") as string;
  const location = formData.get("location") as string;
  const time = formData.get("time") as string;
  const start = new Date(formData.get("start") as string);
  const end = new Date(formData.get("end") as string);

  const imageFile = formData.get("image") as File;

  let image = null;
  if (imageFile && imageFile.size > 0) {
    const arrayBuffer = await imageFile.arrayBuffer();
    image = {
      data: Buffer.from(arrayBuffer),
      contentType: imageFile.type,
    };
  }

  try {
    await Event.create({ title, description, location, time, start, end, image });
    return NextResponse.json({ success: true });
  } catch (err) {
    console.error("Event Create Error:", err);
    return NextResponse.json({ error: "Event creation failed" }, { status: 500 });
  }
}

export async function DELETE(request: Request) {
  await connectDB();
  try {
    const { searchParams } = new URL(request.url);
    const id = searchParams.get("id");
    if (!id) throw new Error("Missing id");
    await Event.findByIdAndDelete(id);
    return NextResponse.json({ success: true });
  } catch (err) {
    console.error("Delete Event Error:", err);
    return NextResponse.json({ error: "Failed to delete event" }, { status: 500 });
  }
}

export async function PUT(request: Request) {
  await connectDB();
  try {
    const form = await request.formData();
    const id = form.get("id")?.toString();
    if (!id) throw new Error("Missing id");

    const update: any = {};
    ["title","start","end","location","time","description"].forEach((k) => {
      const v = form.get(k)?.toString();
      if (v) update[k] = k === "start" || k === "end" ? new Date(v) : v;
    });
    const file = form.get("image") as File | null;
    if (file && file.size) {
      const buf = Buffer.from(await file.arrayBuffer());
      update.image = { data: buf, contentType: file.type };
    }

    const updated = await Event.findByIdAndUpdate(id, update, { new: true });
    return NextResponse.json(updated);
  } catch (err) {
    console.error("Update Event Error:", err);
    return NextResponse.json({ error: "Failed to update event" }, { status: 500 });
  }
}
