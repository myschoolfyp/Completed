// src/app/api/Down/route.ts
import { NextResponse } from "next/server";
import mongoose from "mongoose";
import AssignmentModel from "@/models/Assignment";

const connectDB = async () => {
  if (mongoose.connection.readyState === 0) {
    await mongoose.connect(process.env.MONGODB_URI!);
  }
};

// --- Local typings for the selected fields ---
interface FileField {
  data: Buffer;
  contentType: string;
  fileName: string;
}

interface AssignmentLean {
  file?: FileField; 
}

export async function GET(req: Request) {
  await connectDB();

  const { searchParams } = new URL(req.url);
  const assignmentId = searchParams.get("assignmentId");
  if (!assignmentId) {
    return NextResponse.json({ error: "assignmentId is required" }, { status: 400 });
  }

  // Tell TS that .lean() will return at most these fields
  const assignment = await AssignmentModel
    .findById(assignmentId)
    .select("file.data file.contentType file.fileName")
    .lean<AssignmentLean | null>();

  if (!assignment || !assignment.file?.data) {
    return NextResponse.json({ error: "File not found" }, { status: 404 });
  }

  // assignment.file.data is a Buffer
  const buffer = assignment.file.data;

  return new Response(buffer, {
    status: 200,
    headers: {
      "Content-Type": assignment.file.contentType,
      "Content-Disposition": `attachment; filename="${assignment.file.fileName}"`,
    },
  });
}
