// src/app/Component/P/Complain/page.tsx
"use client";

import { useState, useEffect } from "react";

interface Reply {
  senderCnic: string;
  senderName: string;
  description: string;
  date: string;
}

interface Complaint {
  _id: string;
  teacherName: string;
  parentName: string;
  className: string;
  studentName: string;
  rollNo: string;
  description: string;
  date: string;
  replies: Reply[];
}

export default function ParentComplaints() {
  const [cnic, setCnic] = useState("");
  const [name, setName] = useState("");
  const [view, setView] = useState<"new" | "responses">("new");
  const [complaints, setComplaints] = useState<Complaint[]>([]);
  const [replyText, setReplyText] = useState<Record<string, string>>({});

  // load parent identity
  useEffect(() => {
    const storedCnic = localStorage.getItem("cnic") || "";
    const first = localStorage.getItem("firstName") || "";
    const last = localStorage.getItem("lastName") || "";
    setCnic(storedCnic);
    setName(first && last ? `${first} ${last}` : "");
  }, []);

  // fetch complaints
  useEffect(() => {
    if (!cnic) return;
    fetch(`/api/Component/P/Complain?cnic=${encodeURIComponent(cnic)}`)
      .then((r) => r.json())
      .then((data: Complaint[]) => setComplaints(data))
      .catch(console.error);
  }, [cnic, view]);

  const sendReply = async (id: string) => {
    const text = (replyText[id] || "").trim();
    if (!text) return alert("Reply cannot be empty");
    const payload = { complaintId: id, senderCnic: cnic, senderName: name, description: text };
    const res = await fetch("/api/Component/P/Complain", {
      method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(payload)
    });
    if (!res.ok) return alert("Failed to send reply");
    const newR: Reply = await res.json();
    setComplaints((c) => c.map(cm => cm._id === id ? { ...cm, replies: [...cm.replies, newR] } : cm));
    setReplyText((p) => ({ ...p, [id]: "" }));
  };

  // filter for responses
  const shown = view === "responses"
    ? complaints.filter((c) => c.replies.length > 0)
    : complaints;

  return (
    <div className="min-h-screen p-8 bg-gradient-to-br from-[#0F6466]/10 to-[#0D4B4C]/10">
      {/* Header */}
      <h1 className="text-4xl font-extrabold text-[#0F6466] mb-8">
        Complaint Section
      </h1>

      {/* Tabs */}
      <div className="max-w-3xl mx-auto mb-6 flex gap-4">
        {(["new", "responses"] as const).map((t) => (
          <button
            key={t}
            onClick={() => setView(t)}
            className={`flex-1 py-2 font-semibold rounded-lg transition ${
              view === t
                ? "bg-[#0F6466] text-white shadow-lg"
                : "bg-white text-[#0F6466] shadow-sm hover:shadow-md"
            }`}
          >
            {t === "new" ? "New" : "Responses"}
          </button>
        ))}
      </div>

      {/* No CNIC / No data */}
      {!cnic ? (
        <div className="text-center text-red-600">No CNIC—please log in again.</div>
      ) : shown.length === 0 ? (
        <div className="max-w-3xl mx-auto p-6 bg-white rounded-xl shadow text-center text-gray-500">
          {view === "new" ? "No complaints to display." : "No responses yet."}
        </div>
      ) : (
        shown.map((c) => (
          <div
            key={c._id}
            className="max-w-3xl mx-auto mb-8 p-6 bg-white rounded-2xl shadow-lg"
          >
            {/* Metadata */}
            <div className="grid grid-cols-2 md:grid-cols-3 gap-4 text-sm">
              {[
                ["From", c.teacherName],
                ["To", c.parentName],
                ["Class", c.className],
                ["Student", c.studentName],
                ["Roll No", c.rollNo],
                ["Date", new Date(c.date).toLocaleString()],
              ].map(([label, val]) => (
                <div key={label}>
                  <div className="text-xs font-bold text-[#0F6466] uppercase">
                    {label}
                  </div>
                  <div className="mt-1 text-gray-800">{val}</div>
                </div>
              ))}
            </div>

            {/* Complaint */}
            <div className="mt-6">
              <div className="text-[#0F6466] font-semibold mb-2">Complaint:</div>
              <div className="text-gray-700">{c.description}</div>
            </div>

            {/* Reply form */}
            {view === "new" && (
              <div className="mt-6 flex flex-col gap-3">
                <textarea
                  rows={3}
                  className="w-full border rounded-lg p-3 focus:outline-none focus:ring-2 focus:ring-[#0F6466]/50"
                  placeholder="Write your reply..."
                  value={replyText[c._id] || ""}
                  onChange={(e) =>
                    setReplyText((p) => ({ ...p, [c._id]: e.target.value }))
                  }
                />
                <button
                  onClick={() => sendReply(c._id)}
                  className="self-end px-6 py-2 bg-[#0F6466] text-white font-medium rounded-lg hover:bg-[#0D4B4C] transition-shadow shadow"
                >
                  Reply
                </button>
              </div>
            )}

            {/* Responses */}
            {view === "responses" && c.replies.length > 0 && (
              <div className="mt-6 space-y-4">
                {c.replies.map((r, i) => (
                  <div
                    key={i}
                    className="p-4 bg-[#0F6466]/10 rounded-lg border-l-4 border-[#0F6466]"
                  >
                    <div className="text-xs text-gray-600 mb-1">
                      {new Date(r.date).toLocaleString()} —{" "}
                      <span className="font-semibold text-[#0F6466]">
                        {r.senderName}
                      </span>
                    </div>
                    <div className="text-gray-800">{r.description}</div>
                  </div>
                ))}
              </div>
            )}
          </div>
        ))
      )}
    </div>
  );
}
