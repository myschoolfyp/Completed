// src/app/Component/P/Announcements/page.tsx
"use client";

import { useState, useEffect } from "react";

interface Reply {
  senderCnic: string;
  senderName: string;
  description: string;
  date: string;
}

interface Announcement {
  _id: string;
  description: string;
  date: string;
  replies: Reply[];
}

export default function ParentAnnouncements() {
  const [cnic, setCnic] = useState("");
  const [name, setName] = useState("");
  const [announcements, setAnnouncements] = useState<Announcement[]>([]);
  const [replyText, setReplyText] = useState<Record<string, string>>({});

  useEffect(() => {
    const storedCnic = localStorage.getItem("cnic") || "";
    const first = localStorage.getItem("firstName") || "";
    const last = localStorage.getItem("lastName") || "";
    setCnic(storedCnic);
    setName(first && last ? `${first} ${last}` : "");
  }, []);

  useEffect(() => {
    if (!cnic) return console.warn("No CNIC in localStorage, skipping fetch");
    fetch(`/api/Component/P/Announcements?recipient=${cnic}`)
      .then((r) => r.json())
      .then((data: Announcement[]) => setAnnouncements(data))
      .catch(console.error);
  }, [cnic]);

  const sendReply = async (annId: string) => {
    const text = (replyText[annId] || "").trim();
    if (!text) return alert("Reply cannot be empty");

    const payload = { annId, senderCnic: cnic, senderName: name, description: text };
    const res = await fetch("/api/Component/P/Announcements", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload),
    });

    if (!res.ok) {
      console.error(await res.text());
      return alert("❌ Failed to send reply");
    }

    const newR: Reply = await res.json();
    setAnnouncements((list) =>
      list.map((ann) =>
        ann._id === annId ? { ...ann, replies: [...ann.replies, newR] } : ann
      )
    );
    setReplyText((prev) => ({ ...prev, [annId]: "" }));
  };

  return (
    <div className="min-h-screen p-8 bg-gradient-to-br from-purple-50 via-white to-pink-50">
      <div className="max-w-3xl mx-auto space-y-8">
        <header className="text-center">
          <h1 className="text-4xl font-extrabold text-pink-600">🗞️ Announcements</h1>
          <p className="mt-1 text-gray-600">Keep in touch with school updates</p>
        </header>

        {!cnic ? (
          <div className="text-center text-red-500 font-medium">
            No CNIC found — please log in again.
          </div>
        ) : (
          <div className="text-center text-gray-700">
            Logged in as <strong>{name || "(no name)"}</strong>, CNIC:{" "}
            <strong>{cnic}</strong>
          </div>
        )}

        {cnic && announcements.length === 0 && (
          <div className="text-center text-gray-500">No announcements yet.</div>
        )}

        {announcements.map((ann) => (
          <div
            key={ann._id}
            className="bg-white border border-gray-200 rounded-2xl shadow-lg p-6 space-y-4 transition hover:shadow-2xl"
          >
            <div className="text-sm text-gray-400">
              📅 {new Date(ann.date).toLocaleString()}
            </div>
            <div className="text-lg font-semibold text-gray-800">{ann.description}</div>

            {ann.replies.length > 0 && (
              <div className="pl-4 border-l-4 border-pink-300 bg-pink-50 rounded-lg p-3 space-y-2">
                <div className="text-pink-700 font-medium">💬 Replies</div>
                {ann.replies.map((r, idx) => (
                  <div key={idx} className="text-sm text-gray-700">
                    <span className="italic">
                      [{new Date(r.date).toLocaleString()}] <strong>{r.senderName}:</strong>
                    </span>{" "}
                    {r.description}
                  </div>
                ))}
              </div>
            )}

            <div className="flex flex-col sm:flex-row gap-3 items-stretch">
              <textarea
                rows={2}
                className="flex-1 border border-gray-300 rounded-xl p-3 focus:outline-none focus:ring-2 focus:ring-pink-400"
                placeholder="Write your reply..."
                value={replyText[ann._id] || ""}
                onChange={(e) =>
                  setReplyText((prev) => ({ ...prev, [ann._id]: e.target.value }))
                }
              />
              <button
                onClick={() => sendReply(ann._id)}
                className="bg-gradient-to-r from-pink-500 to-purple-500 hover:from-pink-600 hover:to-purple-600 text-white font-semibold px-6 py-2 rounded-xl transition"
              >
                Reply
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
