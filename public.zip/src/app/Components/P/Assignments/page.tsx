// app/Components/P/Assignments/page.tsx
"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";

// reuse your gradients
const courseGradients = [
  "from-[#0F6466] to-[#2D9F9C]",
  "from-[#4C6EF5] to-[#748FFC]",
  "from-[#7950F2] to-[#9775FA]",
  "from-[#F76707] to-[#FF922B]",
  "from-[#E64980] to-[#F783AC]",
  "from-[#2F9E44] to-[#69DB7C]",
  "from-[#D6336C] to-[#F06595]",
  "from-[#1864AB] to-[#4DABF7]"
];
const assignmentGradients = [
  "from-[#0F6466] to-[#2D9F9C]",
  "from-[#0F6466] via-[#2D9F9C] to-[#4DABF7]",
  "from-[#0F6466] to-[#69DB7C]",
  "from-[#0F6466] to-[#9775FA]",
  "from-[#0F6466] to-[#FF922B]"
];
const submittedGradients = [
  "from-[#1a1a1a] to-[#404040]",
  "from-[#2d2d2d] to-[#666666]",
  "from-[#333333] to-[#999999]"
];

interface Assignment {
  _id: string;
  assignmentTopic: string;
  description?: string;
  deadline?: string;
  totalMarks?: number;
  file?: { fileName: string; contentType: string };
  teacherFirstName: string;
  teacherLastName: string;
  submissions: { rollNo: string; obtainedMarks?: number }[];
}

interface CourseBlock {
  course: string;
  assignments: Assignment[];
}

interface ChildBlock {
  _id: string;
  firstName: string;
  lastName: string;
  className: string;
  rollNo: string;
  courses: CourseBlock[];
}

export default function ParentAssignments() {
  const router = useRouter();
  const [parentName, setParentName] = useState("");
  const [children, setChildren] = useState<ChildBlock[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [childIdx, setChildIdx] = useState(0);
  const [courseIdx, setCourseIdx] = useState<number | null>(null);

  const cnic = typeof window !== "undefined" ? localStorage.getItem("cnic") : null;

  useEffect(() => {
    if (!cnic) {
      router.push("/Components/Login");
      return;
    }
    fetch(`/api/Component/P/Assignments?cnic=${encodeURIComponent(cnic)}`)
      .then((res) => res.json())
      .then((data) => {
        if (data.error) throw new Error(data.error);
        setParentName(data.parentName);
        setChildren(data.children);
      })
      .catch((e) => setError(e.message))
      .finally(() => setLoading(false));
  }, [cnic, router]);

  if (loading)
    return (
      <div className="text-center p-8 text-xl text-[#0F6466] animate-pulse">
        Loading assignments…
      </div>
    );
  if (error)
    return <div className="text-red-500 text-center p-8">⚠️ {error}</div>;
  if (children.length === 0)
    return (
      <div className="text-center p-8 text-gray-500">
        No children found.
      </div>
    );

  const child = children[childIdx];
  const courses = child.courses;
  const selected = courseIdx !== null ? courses[courseIdx] : null;

  return (
    <div className="min-h-screen bg-gradient-to-br from-[#f0fdfa] to-[#e0f8f5] p-6">
      <div className="max-w-5xl mx-auto">
        <h1 className="text-3xl font-bold text-[#0F6466] mb-6 text-center">
          {parentName}’s Dashboard: Assignments
        </h1>

        {/* Child Tabs */}
        <div className="flex justify-center space-x-4 mb-8">
          {children.map((c, i) => (
            <button
              key={c._id}
              onClick={() => {
                setChildIdx(i);
                setCourseIdx(null);
              }}
              className={`px-4 py-2 rounded-full font-medium ${
                i === childIdx
                  ? "bg-[#0F6466] text-white shadow-lg"
                  : "bg-white text-[#0F6466] border border-[#0F6466]/20"
              } transition`}
            >
              {c.firstName} {c.lastName}
            </button>
          ))}
        </div>

        {/* Course Picker */}
        {!selected ? (
          <>
            <h2 className="text-2xl font-semibold text-[#0F6466] mb-4 text-center">
              {child.firstName}’s Courses
            </h2>
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
              {courses.map((blk, idx) => (
                <button
                  key={idx}
                  onClick={() => setCourseIdx(idx)}
                  className={`rounded-xl p-6 min-h-[140px] flex flex-col items-center justify-center
                    transform transition-all duration-200 hover:scale-105 hover:shadow-lg
                    bg-gradient-to-br ${courseGradients[idx % courseGradients.length]}
                    shadow-sm backdrop-blur-sm border border-white/20`}
                >
                  <p className="text-lg font-semibold text-white mb-1">
                    {blk.course.split("-")[0].trim()}
                  </p>
                  <p className="text-white/90 text-sm">
                    {blk.course.split("-")[1]?.trim()}
                  </p>
                  <span className="mt-2 text-sm text-white/80">
                    {blk.assignments.length} Assign.
                  </span>
                </button>
              ))}
            </div>
          </>
        ) : (
          <>
            <button
              onClick={() => setCourseIdx(null)}
              className="mb-6 px-4 py-2 bg-[#0F6466] text-white rounded-lg hover:bg-[#2D9F9C] transition"
            >
              ← Back to Courses
            </button>

            <h2 className="text-2xl font-semibold text-[#0F6466] mb-6">
              {child.firstName}’s "{selected.course.split("-")[0].trim()}" Assignments
            </h2>

            {/* Pending */}
            {selected.assignments.some(a =>
              !a.submissions.some(s => s.rollNo === child.rollNo)
            ) && (
              <div className="mb-12">
                <h3 className="text-xl font-bold text-[#0F6466] mb-4">
                  Pending Submissions
                </h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {selected.assignments
                    .filter(a => !a.submissions.some(s => s.rollNo === child.rollNo))
                    .map((a, i) => (
                      <div
                        key={a._id}
                        className={`rounded-xl p-6 shadow-lg border border-white/20
                          bg-gradient-to-br ${assignmentGradients[i % assignmentGradients.length]}
                          transition-all duration-200 hover:shadow-xl hover:scale-[1.02]`}
                      >
                        <div className="flex justify-between items-start mb-4">
                          <div>
                            <h4 className="text-lg font-bold text-white mb-1">
                              {a.assignmentTopic}
                            </h4>
                            <p className="text-white/90 text-sm">
                              By {a.teacherFirstName} {a.teacherLastName}
                            </p>
                          </div>
                          <span className="bg-white text-[#0F6466] px-3 py-1 rounded-full text-sm font-medium">
                            {a.totalMarks ?? "N/A"} Marks
                          </span>
                        </div>
                        {a.description && (
                          <p className="text-white/80 mb-4">{a.description}</p>
                        )}
                        <div className="flex justify-between items-center">
                          <p className="text-white/90 text-sm">
                            {a.deadline
                              ? new Date(a.deadline).toLocaleDateString()
                              : "No deadline"}
                          </p>
                          {a.file && (
                            <Link
                              href={`/api/files?fileName=${encodeURIComponent(
                                a.file.fileName
                              )}`}
                              className="text-white hover:underline text-sm flex items-center"
                            >
                              Download
                            </Link>
                          )}
                          <Link
                            href={`/Components/S/Assignments/Submit?assignmentId=${a._id}`}
                            className="bg-white text-[#0F6466] px-4 py-2 rounded-lg font-medium hover:bg-opacity-90 transition"
                          >
                            Submit
                          </Link>
                        </div>
                      </div>
                    ))}
                </div>
              </div>
            )}

            {/* Submitted */}
            {selected.assignments.some(a =>
              a.submissions.some(s => s.rollNo === child.rollNo)
            ) && (
              <div>
                <h3 className="text-xl font-bold text-[#0F6466] mb-4">
                  Submitted
                </h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {selected.assignments
                    .filter(a => a.submissions.some(s => s.rollNo === child.rollNo))
                    .map((a, i) => {
                      const sub = a.submissions.find(s => s.rollNo === child.rollNo)!;
                      return (
                        <div
                          key={a._id}
                          className={`rounded-xl p-6 shadow-lg border border-white/20
                            bg-gradient-to-br ${submittedGradients[i % submittedGradients.length]}
                            transition-all duration-200 hover:shadow-xl hover:scale-[1.02] relative group`}
                        >
                          <div className="flex justify-between items-start mb-4">
                            <div>
                              <h4 className="text-lg font-bold text-gray-100 mb-1">
                                {a.assignmentTopic}
                              </h4>
                              <p className="text-gray-300 text-sm">
                                By {a.teacherFirstName} {a.teacherLastName}
                              </p>
                            </div>
                            <span className="bg-white text-[#333] px-3 py-1 rounded-full text-sm font-medium">
                              {sub.obtainedMarks != null
                                ? `${sub.obtainedMarks}/${a.totalMarks ?? "N/A"}`
                                : `Total: ${a.totalMarks ?? "N/A"}`}
                            </span>
                          </div>
                          {a.description && (
                            <p className="text-gray-300 mb-4">{a.description}</p>
                          )}
                          {a.file && (
                            <Link
                              href={`/api/files?fileName=${encodeURIComponent(
                                a.file.fileName
                              )}`}
                              className="text-gray-200 hover:underline text-sm flex items-center mb-4"
                            >
                              Download
                            </Link>
                          )}
                          <div className="opacity-0 group-hover:opacity-100 transition-opacity absolute right-4 bottom-4">
                            <Link
                              href={`/Components/S/Assignments/View?assignmentId=${a._id}&rollNo=${child.rollNo}`}
                              className="bg-white text-[#333] px-4 py-2 rounded-lg hover:bg-gray-100 font-medium shadow"
                            >
                              View
                            </Link>
                          </div>
                        </div>
                      );
                    })}
                </div>
              </div>
            )}
          </>
        )}
      </div>
    </div>
  );
}
