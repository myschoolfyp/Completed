// app/Components/P/Quiz/page.tsx
"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";

interface QuizWithStatus {
  _id: string;
  quizTitle: string;
  totalMarks: number;
  questionCount?: number;
  deadline: string;
  submitted: boolean;
}

interface ChildQuiz {
  _id: string;
  firstName: string;
  lastName: string;
  className: string;
  rollNo: string;
  courses: string[];
  quizzesByCourse: Record<string, QuizWithStatus[]>;
}

interface ParentQuizData {
  parentName: string;
  children: ChildQuiz[];
}

export default function ParentQuizView() {
  const router = useRouter();
  const [data, setData] = useState<ParentQuizData | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [childIdx, setChildIdx] = useState(0);
  const [selectedCourse, setSelectedCourse] = useState<string | null>(null);

  // for result modal
  const [showResultModal, setShowResultModal] = useState(false);
  const [resultLoading, setResultLoading] = useState(false);
  const [resultError, setResultError] = useState("");
  const [quizResult, setQuizResult] = useState<any>(null);
  const [activeQuizId, setActiveQuizId] = useState<string>("");

  const cnic = typeof window !== "undefined"
    ? localStorage.getItem("cnic")
    : null;

  useEffect(() => {
    if (!cnic) {
      router.push("/Components/Login");
      return;
    }
    fetch(`/api/Component/P/Quiz?cnic=${encodeURIComponent(cnic)}`)
      .then(r => {
        if (!r.ok) throw new Error("Failed to load parent quizzes");
        return r.json();
      })
      .then((d: ParentQuizData) => {
        setData(d);
      })
      .catch(e => setError(e.message))
      .finally(() => setLoading(false));
  }, [cnic, router]);

  const child = data?.children[childIdx];

  const quizzes = child && selectedCourse
    ? child.quizzesByCourse[selectedCourse] || []
    : [];

  const pending   = quizzes.filter(q => !q.submitted);
  const completed = quizzes.filter(q => q.submitted);

  const viewResult = async (quizId: string) => {
    setActiveQuizId(quizId);
    setShowResultModal(true);
    setResultLoading(true);
    setResultError("");
    try {
      const res = await fetch(
        `/api/Component/S/Quiz/Submit?quizId=${quizId}&rollNo=${child!.rollNo}`
      );
      if (!res.ok) throw new Error("Failed to fetch result");
      const body = await res.json();
      setQuizResult(body.result);
    } catch (e: any) {
      setResultError(e.message);
    } finally {
      setResultLoading(false);
    }
  };

  if (loading)
    return <div className="p-8 text-center text-[#0F6466] animate-pulse">Loading…</div>;
  if (error)
    return <div className="p-8 text-red-500 text-center">⚠️ {error}</div>;
  if (!data || data.children.length === 0)
    return <div className="p-8 text-center text-gray-500">No children found.</div>;

  return (
    <div className="min-h-screen bg-gradient-to-br from-[#f0fdfa] to-[#e0f8f5] p-6">
      <div className="max-w-4xl mx-auto">
        <h1 className="text-3xl font-bold text-[#0F6466] mb-6 text-center">
          {data.parentName}’s Children Quizzes
        </h1>

        {/* Child Tabs */}
        <div className="flex justify-center space-x-4 mb-8">
          {data.children.map((c, i) => (
            <button
              key={c._id}
              onClick={() => { setChildIdx(i); setSelectedCourse(null); }}
              className={`px-4 py-2 rounded-full font-medium ${
                i === childIdx
                  ? "bg-[#0F6466] text-white shadow-lg"
                  : "bg-white text-[#0F6466] border border-[#0F6466]/20"
              } transition`}
            >
              {c.firstName} {c.lastName}
            </button>
          ))}
        </div>

        {/* Course selector */}
        {!selectedCourse && child ?  (
          <div>
            <h2 className="text-2xl font-semibold text-[#0F6466] mb-4 text-center">
              {child.className} — Select Course
            </h2>
            <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
              {child.courses.map((course, idx) => (
                <button
                  key={idx}
                  onClick={() => setSelectedCourse(course)}
                  className={`
                    rounded-xl p-6 flex items-center justify-center
                    transform hover:scale-105 transition
                    bg-gradient-to-br ${["from-[#0F6466] to-[#2D9F9C]",
                                         "from-[#4C6EF5] to-[#748FFC]",
                                         "from-[#7950F2] to-[#9775FA]"]
                                          [idx % 3]}
                    text-white font-medium text-center
                  `}
                >
                  <div>
                    <p className="text-lg">{course.split("-")[0].trim()}</p>
                    <p className="text-sm opacity-90">{course.split("-")[1]?.trim()}</p>
                  </div>
                </button>
              ))}
            </div>
          </div>
        ) : child ? (
          <>
            <button
              onClick={() => { setSelectedCourse(null); }}
              className="mb-6 px-4 py-2 bg-[#0F6466] text-white rounded-lg"
            >
              ← Back to Courses
            </button>
            <h2 className="text-2xl font-bold text-[#0F6466] mb-4">
              {child.className} — {selectedCourse}
            </h2>

            {pending.length > 0 && (
              <>
                <h3 className="mt-6 text-xl font-semibold text-[#0F6466]">Pending</h3>
                <div className="space-y-6">
                  {pending.map(q => (
                    <div
                      key={q._id}
                      className="relative rounded-lg shadow-lg p-6 bg-white"
                    >
                      <h4 className="text-lg font-semibold">{q.quizTitle}</h4>
                      <p className="mt-2 text-sm">
                        Marks: {q.totalMarks} • Deadline:{" "}
                        {new Date(q.deadline).toLocaleDateString()}
                      </p>
                      <Link
                        href={`/Components/S/Quiz/Submit?quizId=${q._id}`}
                        className="absolute bottom-4 right-4 px-4 py-2 bg-[#4C6EF5] text-white rounded"
                      >
                        Open
                      </Link>
                    </div>
                  ))}
                </div>
              </>
            )}

            {completed.length > 0 && (
              <>
                <h3 className="mt-8 text-xl font-semibold text-gray-700">Completed</h3>
                <div className="space-y-6">
                  {completed.map(q => (
                    <div
                      key={q._id}
                      className="relative rounded-lg shadow-lg p-6 bg-gray-50"
                    >
                      <h4 className="text-lg font-semibold">{q.quizTitle}</h4>
                      <p className="mt-2 text-sm">
                        Marks: {q.totalMarks} • Deadline:{" "}
                        {new Date(q.deadline).toLocaleDateString()}
                      </p>
                      <button
                        onClick={() => viewResult(q._id)}
                        className="absolute bottom-4 right-4 px-4 py-2 bg-green-500 text-white rounded"
                      >
                        View Result
                      </button>
                    </div>
                  ))}
                </div>
              </>
            )}
            {(pending.length === 0 && completed.length === 0) && (
              <p className="text-center text-gray-500 mt-8">
                No quizzes found for this course.
              </p>
            )}
          </>
        ): null}

        {/* Result Modal */}
        {showResultModal && (
          <div className="fixed inset-0 bg-black bg-opacity-60 flex items-center justify-center p-4 z-50">
            <div className="bg-white rounded-lg w-full max-w-lg p-6 relative">
              <button
                onClick={() => setShowResultModal(false)}
                className="absolute top-4 right-4 text-gray-500 hover:text-gray-800"
              >
                ✕
              </button>
              {resultLoading ? (
                <p className="text-center py-8">Loading result…</p>
              ) : resultError ? (
                <p className="text-center text-red-500">{resultError}</p>
              ) : quizResult ? (
                <>
                  <h3 className="text-2xl font-bold mb-4">Result Summary</h3>
                  {quizResult.details.map((d: any) => (
                    <p key={d.question} className="mb-1">
                      Q{d.question}: Your “{d.studentAnswer}” —{" "}
                      {d.isCorrect
                        ? <span className="text-green-600">Correct</span>
                        : <span className="text-red-600">
                            Wrong (correct: {d.correctAnswer})
                          </span>
                      }
                    </p>
                  ))}
                  <p className="mt-4 font-semibold">
                    Score: {quizResult.obtainedMarks} / {quizResult.totalMarks}
                  </p>
                </>
              ) : null}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
