// app/Components/P/Attendance/page.tsx
"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";

const courseGradients = [
  "from-[#0F6466] to-[#2D9F9C]",
  "from-[#4C6EF5] to-[#748FFC]",
  "from-[#7950F2] to-[#9775FA]",
  "from-[#F76707] to-[#FF922B]",
  "from-[#E64980] to-[#F783AC]",
  "from-[#2F9E44] to-[#69DB7C]",
  "from-[#D6336C] to-[#F06595]",
  "from-[#1864AB] to-[#4DABF7]",
];

interface Record {
  date: string;
  startTime: string;
  endTime: string;
  status: string;
}

interface CourseAttendance {
  course: string;
  records: Record[];
  percentage: number;
}

interface ChildAttendance {
  _id: string;
  firstName: string;
  lastName: string;
  className: string;
  rollNo: string;
  courses: CourseAttendance[];
}

export default function ParentAttendance() {
  const router = useRouter();
  const [parentName, setParentName] = useState("");
  const [children, setChildren] = useState<ChildAttendance[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [childIdx, setChildIdx] = useState(0);
  const [courseIdx, setCourseIdx] = useState<number | null>(null);

  const cnic =
    typeof window !== "undefined" ? localStorage.getItem("cnic") : null;

  useEffect(() => {
    if (!cnic) {
      router.push("/Components/Login");
      return;
    }
    const fetchAll = async () => {
      try {
        const res = await fetch(
          `/api/Component/P/Attendance?cnic=${encodeURIComponent(cnic!)}`
        );
        if (!res.ok) {
          const err = await res.json();
          throw new Error(err.error || "Failed to load attendance");
        }
        const data = await res.json();
        setParentName(data.parentName);
        setChildren(data.children);
      } catch (err: any) {
        setError(err.message);
      } finally {
        setLoading(false);
      }
    };
    fetchAll();
  }, [cnic, router]);

  if (loading)
    return (
      <div className="text-center p-8 text-xl text-[#0F6466] animate-pulse">
        Loading attendance…
      </div>
    );
  if (error)
    return (
      <div className="text-red-500 text-center p-8">⚠️ {error}</div>
    );
  if (children.length === 0)
    return (
      <div className="text-center p-8 text-gray-500">
        No children found.
      </div>
    );

  const child = children[childIdx];
  const courseList = child.courses;

  const selectedCourse =
    courseIdx !== null ? courseList[courseIdx] : null;

  return (
    <div className="min-h-screen bg-gradient-to-br from-[#f0fdfa] to-[#e0f8f5] p-6">
      <div className="max-w-4xl mx-auto">
        <h1 className="text-3xl font-bold text-[#0F6466] mb-6 text-center">
          {parentName}’s Children Attendance
        </h1>

        {/* Child Tabs */}
        <div className="flex justify-center space-x-4 mb-8">
          {children.map((c, i) => (
            <button
              key={c._id}
              onClick={() => {
                setChildIdx(i);
                setCourseIdx(null);
              }}
              className={`px-4 py-2 rounded-full font-medium ${
                i === childIdx
                  ? "bg-[#0F6466] text-white shadow-lg"
                  : "bg-white text-[#0F6466] border border-[#0F6466]/20"
              } transition`}
            >
              {c.firstName} {c.lastName}
            </button>
          ))}
        </div>

        {/* Course selector */}
        {!selectedCourse ? (
          <div>
            <h2 className="text-2xl font-semibold text-[#0F6466] mb-4 text-center">
              {child.firstName}’s Courses
            </h2>
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 mb-6">
              {courseList.map((c, idx) => (
                <button
                  key={idx}
                  onClick={() => setCourseIdx(idx)}
                  className={`rounded-xl p-4 min-h-[120px] flex items-center justify-center
                    transform transition-all duration-200 hover:scale-105 hover:shadow-lg
                    bg-gradient-to-br ${courseGradients[idx % courseGradients.length]}
                    shadow-sm backdrop-blur-sm border border-white/20`}
                >
                  <div className="text-center">
                    <p className="text-lg font-semibold text-white mb-1">
                      {c.course.split("-")[0].trim()}
                    </p>
                    <p className="text-white/90 text-sm">
                      {c.course.split("-")[1]?.trim()}
                    </p>
                  </div>
                </button>
              ))}
            </div>
          </div>
        ) : (
          <div>
            <button
              onClick={() => setCourseIdx(null)}
              className="mb-6 px-4 py-2 bg-[#0F6466] text-white rounded-lg hover:bg-[#2D9F9C] transition"
            >
              ← Back to Courses
            </button>

            {/* Attendance Meter */}
            <div className="flex flex-col items-center mb-8">
              <div className="relative w-32 h-32 mb-4">
                <svg
                  viewBox="0 0 36 36"
                  className="w-full h-full transform -rotate-90"
                >
                  <circle
                    cx="18"
                    cy="18"
                    r="15"
                    stroke="#e5e7eb"
                    strokeWidth="4"
                    fill="none"
                  />
                  <circle
                    cx="18"
                    cy="18"
                    r="15"
                    stroke="#0F6466"
                    strokeWidth="4"
                    fill="none"
                    strokeDasharray={`${selectedCourse.percentage},100`}
                    strokeLinecap="round"
                  />
                </svg>
                <div className="absolute inset-0 flex items-center justify-center text-xl font-bold">
                  {selectedCourse.percentage}%
                </div>
              </div>
              <p className="text-lg font-medium text-[#0F6466]">
                {child.firstName}’s attendance in{" "}
                <span className="underline">
                  {selectedCourse.course.split("-")[0].trim()}
                </span>
              </p>
            </div>

            {/* Attendance Table */}
            <div className="bg-white rounded-lg shadow-md overflow-hidden">
              <table className="w-full">
                <thead className="bg-[#0F6466] text-white">
                  <tr>
                    <th className="px-4 py-3">Date</th>
                    <th className="px-4 py-3">Start</th>
                    <th className="px-4 py-3">End</th>
                    <th className="px-4 py-3">Status</th>
                  </tr>
                </thead>
                <tbody>
                  {selectedCourse.records.map((r, i) => (
                    <tr
                      key={i}
                      className="border-b even:bg-gray-50"
                    >
                      <td className="px-4 py-3 text-center">
                        {new Date(r.date).toLocaleDateString()}
                      </td>
                      <td className="px-4 py-3 text-center">{r.startTime}</td>
                      <td className="px-4 py-3 text-center">{r.endTime}</td>
                      <td className="px-4 py-3 text-center">
                        <span
                          className={`px-2 py-1 rounded-full text-sm font-medium ${
                            r.status === "P"
                              ? "bg-green-100 text-green-800"
                              : r.status === "A"
                              ? "bg-red-100 text-red-800"
                              : "bg-yellow-100 text-yellow-800"
                          }`}
                        >
                          {r.status}
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
              {selectedCourse.records.length === 0 && (
                <div className="text-center p-8 text-gray-500">
                  No records found.
                </div>
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
