"use client";

import { useState, useEffect } from "react";

interface Reply {
  senderRollNo: string;
  senderName: string;
  description: string;
  date: string;
}

interface Announcement {
  _id: string;
  description: string;
  date: string;
  replies: Reply[];
}

export default function StudentAnnouncements() {
  const [rollNo, setRollNo] = useState("");
  const [name, setName] = useState("");
  const [announcements, setAnnouncements] = useState<Announcement[]>([]);
  const [replyText, setReplyText] = useState<Record<string, string>>({});

  useEffect(() => {
    const r = localStorage.getItem("rollNo") || "";
    const first = localStorage.getItem("firstName") || "";
    const last = localStorage.getItem("lastName") || "";
    setRollNo(r);
    setName(first && last ? `${first} ${last}` : "");
  }, []);

  useEffect(() => {
    if (!rollNo) return console.warn("No rollNo—skipping fetch");
    const url = `/api/Component/S/Announcements?stream=students&recipient=${rollNo}`;
    fetch(url)
      .then((r) => r.json())
      .then((data: Announcement[]) => setAnnouncements(data))
      .catch(console.error);
  }, [rollNo]);

  const sendReply = async (annId: string) => {
    const text = (replyText[annId] || "").trim();
    if (!text) return alert("Reply cannot be empty");

    const payload = {
      annId,
      senderRollNo: rollNo,
      senderName: name,
      description: text,
    };

    const res = await fetch("/api/Component/S/Announcements", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload),
    });

    if (!res.ok) {
      const err = await res.text();
      console.error("Student POST failed:", err);
      return alert("Failed to send reply");
    }

    const newR: Reply = await res.json();
    setAnnouncements((a) =>
      a.map((ann) =>
        ann._id === annId ? { ...ann, replies: [...ann.replies, newR] } : ann
      )
    );
    setReplyText((p) => ({ ...p, [annId]: "" }));
  };

  return (
    <div className="p-8 min-h-screen bg-gradient-to-tr from-sky-100 via-white to-indigo-100">
      <div className="max-w-4xl mx-auto space-y-8">
        <div className="text-center">
          <h1 className="text-4xl font-bold text-indigo-800">📢 Announcements</h1>
          <p className="text-gray-600 mt-2">Stay updated with the latest news</p>
        </div>

        {!rollNo ? (
          <div className="text-center text-red-500 font-medium">
            No roll number found—please log in again.
          </div>
        ) : (
          <div className="text-center text-gray-700">
            Logged in as <strong>{name || "(no name)"}</strong>, Roll No:{" "}
            <strong>{rollNo}</strong>
          </div>
        )}

        {announcements.length === 0 && rollNo && (
          <div className="text-center text-gray-500">No announcements yet.</div>
        )}

        {announcements.map((ann) => (
          <div
            key={ann._id}
            className="bg-white border shadow-xl rounded-2xl p-6 space-y-4 transition hover:shadow-2xl"
          >
            <div className="text-sm text-gray-500">
              📅 {new Date(ann.date).toLocaleString()}
            </div>
            <div className="text-lg font-semibold text-gray-800">{ann.description}</div>

            {ann.replies.length > 0 && (
              <div className="space-y-2 pl-4 border-l-4 border-indigo-300 bg-indigo-50 rounded-lg p-3">
                <div className="text-indigo-700 font-medium">💬 Replies:</div>
                {ann.replies.map((r, i) => (
                  <div key={i} className="text-sm text-gray-700">
                    <span className="italic">
                      [{new Date(r.date).toLocaleString()}]{" "}
                      <strong>{r.senderName}:</strong>
                    </span>{" "}
                    {r.description}
                  </div>
                ))}
              </div>
            )}

            <div className="flex flex-col sm:flex-row gap-3 items-start sm:items-center">
              <textarea
                rows={2}
                className="w-full sm:flex-1 border border-gray-300 rounded-lg p-3 focus:outline-none focus:ring-2 focus:ring-indigo-400"
                placeholder="Write your reply..."
                value={replyText[ann._id] || ""}
                onChange={(e) =>
                  setReplyText((p) => ({ ...p, [ann._id]: e.target.value }))
                }
              />
              <button
                onClick={() => sendReply(ann._id)}
                className="bg-gradient-to-r from-indigo-500 to-blue-500 hover:from-indigo-600 hover:to-blue-600 text-white font-semibold px-6 py-2 rounded-xl transition"
              >
                Reply
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
