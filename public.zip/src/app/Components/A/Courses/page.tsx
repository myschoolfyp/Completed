// app/Components/A/Courses/page.tsx
"use client";
import { useState, useEffect } from "react";
import { useRouter } from "next/navigation";
import { Trash2, Plus, ArrowRight } from "lucide-react";

interface CourseData {
  educationLevel: string;
  classLevel:     string;
  courses:        string[];
}

export default function ViewCourses() {
  const router = useRouter();

  /** State **/
  const [coursesData, setCoursesData]     = useState<CourseData[]>([]);
  const [loading,     setLoading]         = useState(true);
  const [error,       setError]           = useState<string|null>(null);
  const [selectedLevel, setSelectedLevel] = useState("PrimaryLevel");

  // Modal state
  const [showModal,     setShowModal]     = useState(false);
  const [modalStep,     setModalStep]     = useState<1|2>(1);
  const [quantity,      setQuantity]      = useState(1);
  const [newCourses,    setNewCourses]    = useState<string[]>([]);
  const [addLevel,      setAddLevel]      = useState("PrimaryLevel");
  const [addClassLevel, setAddClassLevel] = useState("");
  const [submitting,    setSubmitting]    = useState(false);
  const [submitError,   setSubmitError]   = useState<string|null>(null);

  /** Fetch all courses **/
  const fetchCourses = async () => {
    setLoading(true);
    try {
      const res = await fetch("/api/Component/A/courses?action=fetchCourses");
      if (!res.ok) throw new Error("Failed to fetch");
      setCoursesData(await res.json());
      setError(null);
    } catch (e: any) {
      setError(e.message);
    } finally {
      setLoading(false);
    }
  };
  useEffect(() => { fetchCourses(); }, []);

  /** DELETE a single existing course **/
  const deleteCourse = async (level: string, cls: string, course: string) => {
    if (!confirm(`Delete "${course}" from ${cls}?`)) return;
    await fetch("/api/Component/A/courses", {
      method: "DELETE",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ educationLevel: level, classLevel: cls, course }),
    });
    fetchCourses();
  };

  /** Start “Add” flow by choosing quantity **/
  const openModal = () => {
    setModalStep(1);
    setQuantity(1);
    setNewCourses([]);
    setAddLevel("PrimaryLevel");
    setAddClassLevel("");
    setSubmitError(null);
    setShowModal(true);
  };

  /** After quantity chosen, build blank inputs **/
  const handleQuantity = () => {
    if (quantity < 1 || quantity > 10) {
      return setSubmitError("Choose between 1 and 10 courses");
    }
    setNewCourses(Array(quantity).fill(""));
    setModalStep(2);
    setSubmitError(null);
  };

  /** Submit new courses in one batch **/
  const handleAddSubmit = async () => {
    const trimmed = newCourses.map(s => s.trim()).filter(s => s);
    if (!addClassLevel) {
      return setSubmitError("Select a Class Level");
    }
    if (trimmed.length === 0) {
      return setSubmitError("Enter at least one course name");
    }
    setSubmitting(true);
    try {
      const res = await fetch("/api/Component/A/courses", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          educationLevel: addLevel,
          classLevel:     addClassLevel,
          newCourses:     trimmed,
        }),
      });
      const json = await res.json();
      if (!res.ok) throw new Error(json.error || "Failed to add");
      setShowModal(false);
      fetchCourses();
    } catch (e: any) {
      setSubmitError(e.message);
    } finally {
      setSubmitting(false);
    }
  };

  // Classes for the chosen band
  const availableClasses = Array.from(
    new Set(
      coursesData
        .filter(c => c.educationLevel === addLevel)
        .map(c => c.classLevel)
    )
  );

  return (
    <div className="p-8 max-w-7xl mx-auto">
      {/* Header & Buttons */}
      <div className="flex items-center justify-between mb-8">
        <h1 className="text-4xl font-bold text-white p-6 rounded-lg bg-gradient-to-r from-[#0F6466] to-[#2D9F9C]">
          School Course Catalog
        </h1>
        <div className="flex gap-4">
          <button
            onClick={() => router.push("/Components/A/Courses/Assign")}
            className="inline-flex items-center bg-gradient-to-r from-[#0F6466] to-[#2D9F9C] text-white px-5 py-2 rounded-md hover:opacity-90 transition"
          >
            Assign Courses <ArrowRight className="ml-2" size={16}/>
          </button>
          <button
            onClick={openModal}
            className="inline-flex items-center bg-gradient-to-r from-[#0F6466] to-[#2D9F9C] text-white px-5 py-2 rounded-md hover:opacity-90 transition"
          >
            <Plus size={16} className="mr-2"/> Add Courses
          </button>
        </div>
      </div>

      {/* Level Tabs */}
      <div className="flex gap-4 mb-6">
        {["PrimaryLevel","MiddleLevel","SecondaryLevel"].map(lvl=>(
          <button
            key={lvl}
            onClick={()=>setSelectedLevel(lvl)}
            className={`px-6 py-2 rounded-md text-sm font-medium ${
              selectedLevel===lvl
                ? "bg-[#0F6466] text-white"
                : "bg-gray-200 text-gray-700 hover:bg-gray-300"
            }`}
          >
            {lvl.replace("Level"," Level")}
          </button>
        ))}
      </div>

      {/* Loading/Error */}
      {loading && <div className="text-center text-gray-600">Loading…</div>}
      {error   && <div className="text-center text-red-600">Error: {error}</div>}

      {/* Courses Table */}
      {!loading && !error && (
        <div className="bg-white rounded-lg shadow-md p-6">
          <h2 className="text-2xl font-semibold text-[#0F6466] mb-4">
            {selectedLevel.replace("Level"," Level")} Courses
          </h2>
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-[#0F6466] text-white">
                <tr>
                  <th className="p-3 text-left">Class Level</th>
                  <th className="p-3 text-left">Courses</th>
                </tr>
              </thead>
              <tbody>
                {coursesData
                  .filter(c=>c.educationLevel===selectedLevel)
                  .map(cls=>(
                  <tr key={cls.classLevel} className="border-b hover:bg-gray-50">
                    <td className="p-3 font-medium">
                      {cls.classLevel.replace("_"," ")}
                    </td>
                    <td className="p-3">
                      <div className="flex flex-wrap gap-2">
                        {cls.courses.map(course=>(
                          <div
                            key={course}
                            className="flex items-center bg-gray-100 px-3 py-1 rounded-full text-sm"
                          >
                            <span>{course}</span>
                            <button
                              onClick={()=>deleteCourse(cls.educationLevel, cls.classLevel, course)}
                              className="ml-2 text-red-600 hover:text-red-800"
                            >
                              <Trash2 size={14}/>
                            </button>
                          </div>
                        ))}
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Add Courses Modal */}
      {showModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="bg-white w-full max-w-md p-6 rounded-lg shadow-lg">
            {modalStep === 1 ? (
              <>
                <h3 className="text-xl font-semibold mb-4">How many courses?</h3>
                <input
                  type="number"
                  min={1}
                  max={10}
                  value={quantity}
                  onChange={e => setQuantity(Number(e.target.value))}
                  className="w-full p-2 border rounded mb-4"
                />
                {submitError && (
                  <div className="text-red-600 text-sm mb-2">{submitError}</div>
                )}
                <div className="flex justify-end gap-4">
                  <button onClick={()=>setShowModal(false)} className="px-4 py-2">
                    Cancel
                  </button>
                  <button onClick={handleQuantity} className="px-4 py-2 bg-[#0F6466] text-white rounded">
                    Next
                  </button>
                </div>
              </>
            ) : (
              <>
                <h3 className="text-xl font-semibold mb-4">Enter Course Details</h3>

                {/* Level & Class selects */}
                <div className="space-y-4 mb-4">
                  <div>
                    <label className="block mb-1">Education Level</label>
                    <select
                      value={addLevel}
                      onChange={e => {
                        setAddLevel(e.target.value);
                        setAddClassLevel("");
                      }}
                      className="w-full p-2 border rounded"
                    >
                      <option value="PrimaryLevel">Primary Level</option>
                      <option value="MiddleLevel">Middle Level</option>
                      <option value="SecondaryLevel">Secondary Level</option>
                    </select>
                  </div>
                  <div>
                    <label className="block mb-1">Class Level</label>
                    <select
                      value={addClassLevel}
                      onChange={e=>setAddClassLevel(e.target.value)}
                      className="w-full p-2 border rounded"
                    >
                      <option value="">Select Class</option>
                      {availableClasses.map(cls=>(
                        <option key={cls} value={cls}>
                          {cls.replace("_"," ")}
                        </option>
                      ))}
                    </select>
                  </div>
                </div>

                {/* Dynamic inputs */}
                <div className="space-y-2">
                  {newCourses.map((val,i)=>(
                    <div key={i} className="flex items-center gap-2">
                      <input
                        type="text"
                        value={val}
                        onChange={e=>{
                          const arr = [...newCourses];
                          arr[i] = e.target.value;
                          setNewCourses(arr);
                        }}
                        placeholder="e.g. Mathematics - 1 (MATH101)"
                        className="flex-grow p-2 border rounded"
                      />
                      <button
                        onClick={()=>{
                          setNewCourses(prev=>prev.filter((_,idx)=>idx!==i));
                        }}
                        className="p-2 text-red-600"
                      >
                        <Trash2 size={16}/>
                      </button>
                    </div>
                  ))}
                </div>

                {submitError && (
                  <div className="text-red-600 text-sm mt-2">{submitError}</div>
                )}

                {/* Actions */}
                <div className="mt-6 flex justify-end gap-4">
                  <button onClick={()=>setModalStep(1)} className="px-4 py-2" disabled={submitting}>
                    Back
                  </button>
                  <button
                    onClick={handleAddSubmit}
                    className="px-4 py-2 bg-gradient-to-r from-[#0F6466] to-[#2D9F9C] text-white rounded"
                    disabled={submitting}
                  >
                    {submitting ? "Adding…" : "Add Courses"}
                  </button>
                </div>
              </>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
