"use client";
import { useState, useEffect } from "react";

interface ClassData {
  classLevel: string;
  className: string;
  stream: string;
  courses: string[];
}

interface CourseData {
  educationLevel: string;
  classLevel: string;
  courses: string[];
}

export default function AssignCourse() {
  // — logic unchanged —
  const [classes, setClasses] = useState<ClassData[]>([]);
  const [assignedCourses, setAssignedCourses] = useState<string[]>([]);
  const [selectedClass, setSelectedClass] = useState<string>("");
  const [allCourses, setAllCourses] = useState<CourseData[]>([]);
  const [selectedLevel, setSelectedLevel] = useState<string>("PrimaryLevel");
  const [selectedCourses, setSelectedCourses] = useState<string[]>([]);
  const [finalizedData, setFinalizedData] = useState<
    { classLevel: string; className: string; stream: string; courses: string[] }[]
  >([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [submissionStatus, setSubmissionStatus] = useState<{
    success: boolean;
    message: string;
  } | null>(null);

  useEffect(() => {
    async function fetchClasses() {
      try {
        const res = await fetch("/api/Component/A/courses/assign");
        if (!res.ok) throw new Error("Failed to fetch classes");
        setClasses(await res.json());
      } catch (err) {
        setError(err instanceof Error ? err.message : "Error loading classes");
      } finally {
        setIsLoading(false);
      }
    }
    fetchClasses();
  }, []);

  useEffect(() => {
    async function fetchCourses() {
      try {
        const res = await fetch(
          "/api/Component/A/courses?action=fetchCourses"
        );
        if (!res.ok) throw new Error("Failed to fetch courses");
        setAllCourses(await res.json());
      } catch (err) {
        setError(err instanceof Error ? err.message : "Error loading courses");
      }
    }
    fetchCourses();
  }, []);

  const handleSelectClass = (className: string) => {
    setSelectedClass(className);
    setSelectedCourses([]);
    const cls = classes.find((c) => c.className === className);
    setAssignedCourses(cls?.courses ?? []);
  };

  const handleSelectCourse = (course: string) =>
    setSelectedCourses((prev) =>
      prev.includes(course) ? prev.filter((c) => c !== course) : [...prev, course]
    );

  const handleSelectAll = (classCourses: string[]) => {
    const allSel = classCourses.every((c) => selectedCourses.includes(c));
    setSelectedCourses((prev) =>
      allSel
        ? prev.filter((c) => !classCourses.includes(c))
        : Array.from(new Set([...prev, ...classCourses]))
    );
  };

  useEffect(() => {
    if (!selectedClass || selectedCourses.length === 0) {
      setFinalizedData([]);
      return;
    }
    const cls = classes.find((c) => c.className === selectedClass);
    if (!cls) return;
    setFinalizedData([
      {
        classLevel: cls.classLevel,
        className: cls.className,
        stream: cls.stream,
        courses: selectedCourses,
      },
    ]);
  }, [selectedClass, selectedCourses, classes]);

  const handleSubmit = async () => {
    if (!selectedClass) return;
    const cls = classes.find((c) => c.className === selectedClass);
    if (!cls) return;

    const merged = Array.from(new Set([...assignedCourses, ...selectedCourses]));
    const payload = [
      {
        classLevel: cls.classLevel,
        className: cls.className,
        stream: cls.stream,
        courses: merged,
      },
    ];

    try {
      const res = await fetch("/api/Component/A/courses/assign", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });
      const json = await res.json();
      if (res.ok) {
        setSubmissionStatus({ success: true, message: json.message });
        setSelectedClass("");
        setSelectedCourses([]);
        setAssignedCourses([]);
        setFinalizedData([]);
      } else {
        setSubmissionStatus({ success: false, message: json.error });
      }
    } catch {
      setSubmissionStatus({
        success: false,
        message: "Network error. Please try again.",
      });
    }
  };

  const filteredCourses = allCourses.filter(
    (c) => c.educationLevel === selectedLevel
  );

  return (
    <div className="min-h-screen bg-gradient-to-br from-[#0F6466] to-[#0A4A4C] py-12">
      <div className="max-w-7xl mx-auto px-6">
        <h1 className="text-5xl font-extrabold text-center text-white mb-12">
          Course Assignment
        </h1>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Class Selector */}
          <section className="bg-white rounded-2xl shadow-xl p-6 flex flex-col">
            <h2 className="text-2xl font-semibold text-[#0F6466] mb-4">
              1. Choose Class
            </h2>
            {isLoading ? (
              <p className="text-gray-500">Loading classes…</p>
            ) : error ? (
              <p className="text-red-600">{error}</p>
            ) : (
              <select
                value={selectedClass}
                onChange={(e) => handleSelectClass(e.target.value)}
                className="mt-2 p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#0F6466]"
              >
                <option value="">— Select a class —</option>
                {classes.map((c) => (
                  <option key={c.className} value={c.className}>
                    {c.classLevel} / {c.className} / {c.stream}
                  </option>
                ))}
              </select>
            )}

            {assignedCourses.length > 0 && (
              <div className="mt-6 bg-[#0F6466]/10 rounded-lg p-4 flex-1">
                <h3 className="text-lg font-medium text-[#0F6466] mb-2">
                  Already Assigned
                </h3>
                <ul className="list-disc list-inside text-gray-800 space-y-1">
                  {assignedCourses.map((c) => (
                    <li key={c}>{c}</li>
                  ))}
                </ul>
              </div>
            )}
          </section>

          {/* Course Picker */}
          {selectedClass && (
            <section className="lg:col-span-2 bg-white rounded-2xl shadow-xl p-6 flex flex-col">
              <h2 className="text-2xl font-semibold text-[#0F6466] mb-4">
                2. Select Courses
              </h2>

              <div className="flex space-x-4 mb-6">
                {(["PrimaryLevel", "MiddleLevel", "SecondaryLevel"] as const).map(
                  (lvl) => (
                    <button
                      key={lvl}
                      onClick={() => setSelectedLevel(lvl)}
                      className={`flex-1 py-2 rounded-full text-center font-medium transition ${
                        selectedLevel === lvl
                          ? "bg-[#0F6466] text-white shadow-md"
                          : "bg-gray-100 text-gray-700 hover:bg-gray-200"
                      }`}
                    >
                      {lvl.replace("Level", " Level")}
                    </button>
                  )
                )}
              </div>

              <div className="overflow-auto flex-1">
                <table className="w-full table-auto text-sm">
                  <thead className="bg-[#0F6466] text-white">
                    <tr>
                      <th className="p-3 text-left">Level</th>
                      <th className="p-3 text-left">Courses</th>
                    </tr>
                  </thead>
                  <tbody>
                    {filteredCourses.map((grp) => (
                      <tr
                        key={grp.classLevel}
                        className="border-b hover:bg-gray-50"
                      >
                        <td className="p-3 font-medium">{grp.classLevel}</td>
                        <td className="p-3">
                          <div className="flex flex-wrap gap-3">
                            <label className="flex items-center">
                              <input
                                type="checkbox"
                                checked={grp.courses.every((c) =>
                                  selectedCourses.includes(c)
                                )}
                                onChange={() => handleSelectAll(grp.courses)}
                                className="mr-2"
                              />
                              All
                            </label>
                            {grp.courses.map((course) => (
                              <label
                                key={course}
                                className="flex items-center"
                              >
                                <input
                                  type="checkbox"
                                  checked={selectedCourses.includes(course)}
                                  onChange={() => handleSelectCourse(course)}
                                  className="mr-1"
                                />
                                <span className="px-2 py-1 bg-gray-100 rounded-full">
                                  {course}
                                </span>
                              </label>
                            ))}
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </section>
          )}
        </div>

        {/* Preview & Submit */}
        {finalizedData.length > 0 && (
          <section className="mt-12 bg-white rounded-2xl shadow-xl p-6">
            <h2 className="text-2xl font-semibold text-[#0F6466] mb-4">
              3. Preview & Submit
            </h2>
            <div className="overflow-auto">
              <table className="w-full text-sm">
                <thead className="bg-[#0F6466] text-white">
                  <tr>
                    <th className="p-2">Level</th>
                    <th className="p-2">Class</th>
                    <th className="p-2">Stream</th>
                    <th className="p-2">New Courses</th>
                  </tr>
                </thead>
                <tbody>
                  {finalizedData.map((d, i) => (
                    <tr key={i} className="hover:bg-gray-50">
                      <td className="p-2">{d.classLevel}</td>
                      <td className="p-2">{d.className}</td>
                      <td className="p-2">{d.stream}</td>
                      <td className="p-2">
                        <ul className="list-disc list-inside space-y-1">
                          {d.courses.map((c, idx) => (
                            <li key={idx}>{c}</li>
                          ))}
                        </ul>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            <div className="mt-6 text-center">
              <button
                onClick={handleSubmit}
                className="px-8 py-3 rounded-full bg-gradient-to-r from-[#0F6466] to-[#0A4A4C] text-white font-medium shadow-lg hover:scale-105 transform transition"
              >
                Confirm Submission
              </button>
              {submissionStatus && (
                <p
                  className={`mt-4 ${
                    submissionStatus.success ? "text-green-600" : "text-red-600"
                  }`}
                >
                  {submissionStatus.message}
                </p>
              )}
            </div>
          </section>
        )}
      </div>
    </div>
  );
}
