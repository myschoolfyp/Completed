// app/Components/A/Timetable/page.tsx
"use client";
import { useState, useEffect } from "react";
import { useRouter } from "next/navigation";

interface Timetable {
  _id: string;
  className: string;
  days: {
    name: string;
    slots: {
      startTime: string;
      endTime: string;
      course: string;
      teacher: string;
      room: string;
    }[];
  }[];
  breakTime: {
    start: string;
    end: string;
  };
}

export default function TimetablePage() {
  const router = useRouter();
  const [classes, setClasses] = useState<string[]>([]);
  const [selectedClass, setSelectedClass] = useState("");
  const [timetable, setTimetable] = useState<Timetable | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string>("");

  // Fetch all class names
  useEffect(() => {
    fetch("/api/Component/A/timetable")
      .then((res) => res.json())
      .then((data) => setClasses(data.classNames))
      .catch((err) => console.error("Error fetching classes:", err));
  }, []);

  // Fetch timetable for selected class
  useEffect(() => {
    if (!selectedClass) return;
    setLoading(true);
    fetch(`/api/Component/A/timetable?className=${encodeURIComponent(selectedClass)}`)
      .then(async (res) => {
        if (!res.ok) throw new Error(`Status ${res.status}`);
        return res.json();
      })
      .then((data: Timetable) => {
        setTimetable(data);
        setError("");
      })
      .catch((err) => {
        setTimetable(null);
        setError(err.message);
      })
      .finally(() => setLoading(false));
  }, [selectedClass]);

  // Delete timetable
  const handleDelete = async () => {
    if (!timetable) return;
    const confirmDelete = window.confirm("Are you sure you want to delete this timetable?");
    if (!confirmDelete) return;

    try {
      const res = await fetch(`/api/Component/A/timetable?id=${timetable._id}`, {
        method: "DELETE",
      });
      

      if (!res.ok) throw new Error(`Failed to delete: ${res.statusText}`);

      setTimetable(null);
      setSelectedClass("");
      alert("Timetable deleted successfully.");
    } catch (err) {
      console.error(err);
      alert("Failed to delete timetable.");
    }
  };

  return (
    <div className="flex flex-col min-h-screen bg-gray-50 p-8 space-y-8">
      <div className="flex justify-between items-center">
        <h1 className="text-3xl font-bold text-[#0F6466]">Timetable</h1>
        <div className="flex gap-4">
          <button
            className="px-5 py-2 bg-[#0F6466] text-white rounded-lg hover:bg-[#0D4B4C] transition"
            onClick={() => router.push("/Components/A/Timetable/Create")}
          >
            Create New
          </button>
          {timetable && (
            <>
              <button
                className="px-5 py-2 bg-gradient-to-r from-[#0F6466] to-[#2D9F9C] text-white rounded-lg hover:opacity-90 transition"
                onClick={() =>
                  router.push(`/Components/A/Timetable/Edit?timetableId=${timetable._id}`)
                }
              >
                Edit
              </button>
              <button
                className="px-5 py-2 bg-red-500 text-white rounded-lg hover:bg-red-600 transition"
                onClick={handleDelete}
              >
                Delete
              </button>
            </>
          )}
        </div>
      </div>

      {/* Class Selection */}
      <div className="flex flex-wrap gap-4">
        {classes.map((cls) => (
          <button
            key={cls}
            onClick={() => setSelectedClass(cls)}
            className={`px-6 py-2 rounded-md font-medium ${
              selectedClass === cls
                ? "bg-[#0F6466] text-white"
                : "bg-gray-200 text-gray-700 hover:bg-gray-300"
            }`}
          >
            {cls}
          </button>
        ))}
      </div>

      {/* Timetable Display */}
      <div className="flex-grow p-8 rounded-xl shadow-lg bg-white border-2 border-[#0F6466]">
        {loading ? (
          <p className="text-center text-gray-600">Loading timetable...</p>
        ) : error ? (
          <p className="text-center text-red-600">{error}</p>
        ) : timetable ? (
          <div className="grid grid-cols-6 gap-4">
            {timetable.days.map((day) => (
              <div key={day.name} className="border rounded-lg p-4">
                <h3 className="text-lg font-semibold text-[#0F6466] mb-2">
                  {day.name}
                </h3>
                {day.slots.map((slot, idx) => (
                  <div key={idx} className="mb-4 p-2 bg-gray-50 rounded">
                    <div className="text-sm text-[#0F6466]">
                      {slot.startTime} - {slot.endTime}
                    </div>
                    <div className="font-medium my-1">{slot.course}</div>
                    <div className="text-sm flex justify-between">
                      <span>{slot.teacher}</span>
                      <span>{slot.room}</span>
                    </div>
                  </div>
                ))}
              </div>
            ))}
            <div className="bg-[#0F6466] text-white p-4 rounded-lg text-center col-span-6">
              <h3 className="font-semibold mb-2">Break</h3>
              <p>
                {timetable.breakTime.start} - {timetable.breakTime.end}
              </p>
            </div>
          </div>
        ) : (
          <p className="text-center text-gray-600">
            {selectedClass
              ? "No timetable found"
              : "Select a class to view timetable"}
          </p>
        )}
      </div>
    </div>
  );
}
