"use client";

import { useEffect, useState } from "react";

interface Datesheet {
  _id: string;
  datesheetName: string;
  className: string;
}

interface ClassType {
  _id: string;
  className: string;
  classLevel: string;
}

interface ResultRecord {
  course: string;
  totalMarks: number;
  obtainedMarks: number;
  grade: string;
}

export default function ViewResult() {
  const [datesheets, setDatesheets] = useState<Datesheet[]>([]);
  const [classes, setClasses] = useState<ClassType[]>([]);
  const [selectedDatesheet, setSelectedDatesheet] = useState("");
  const [selectedClass, setSelectedClass] = useState("");
  const [rollNo, setRollNo] = useState("");
  const [studentResult, setStudentResult] = useState<ResultRecord[]>([]);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    fetchDatesheets();
  }, []);

  const fetchDatesheets = async () => {
    setLoading(true);
    try {
      const res = await fetch(
        "/api/Component/A/Datesheet/View?action=fetchDatesheets"
      );
      if (!res.ok) throw new Error("Failed to load datesheets");
      const data: Datesheet[] = await res.json();
      setDatesheets(data);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Error loading datesheets");
    } finally {
      setLoading(false);
    }
  };

  const fetchClasses = async (datesheetName: string) => {
    setLoading(true);
    try {
      const res = await fetch(
        `/api/Component/A/Datesheet/View?action=fetchClasses&datesheetName=${encodeURIComponent(
          datesheetName
        )}`
      );
      if (!res.ok) throw new Error("Failed to load classes");
      const data: ClassType[] = await res.json();
      setClasses(data);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Error loading classes");
    } finally {
      setLoading(false);
    }
  };

  const handleDatesheetSelect = (name: string) => {
    setSelectedDatesheet(name);
    setSelectedClass("");
    setStudentResult([]);
    fetchClasses(name);
  };

  const handleRollNoChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.value.length <= 9) {
      setRollNo(e.target.value);
    }
  };

  const handleSearch = async () => {
    setError("");
    setStudentResult([]);

    if (!selectedDatesheet) {
      setError("Please select a datesheet");
      return;
    }
    if (!selectedClass) {
      setError("Please select a class");
      return;
    }
    if (rollNo.length < 3) {
      setError("Roll number must be at least 3 characters");
      return;
    }

    setLoading(true);
    try {
      const res = await fetch("/api/Component/A/Results/View", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          datesheetName: selectedDatesheet,
          className: selectedClass,
          rollNo,
        }),
      });

      if (!res.ok) {
        const err = await res.json();
        throw new Error(err.error || "Failed to fetch results");
      }

      const data: { records: ResultRecord[] } = await res.json();
      if (data.records.length === 0) {
        setError("No results found for this student");
      } else {
        setStudentResult(data.records);
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : "Error fetching results");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div
      className="min-h-screen p-8"
      style={{
        background: "linear-gradient(135deg, #0F6466 0%, #18A298 100%)",
      }}
    >
      <div className="max-w-3xl mx-auto bg-white bg-opacity-20 backdrop-blur-md rounded-2xl shadow-xl p-8">
        <h1 className="text-4xl font-extrabold text-center mb-6 bg-clip-text text-transparent bg-gradient-to-r from-[#e0e4e4] to-[#f1f1f1]">
          View Student Results
        </h1>

        <div className="space-y-5">
          {/* Datesheet */}
          <div>
            <label className="block mb-2 font-medium text-gray-800">
              Select Datesheet
            </label>
            <select
              value={selectedDatesheet}
              onChange={(e) => handleDatesheetSelect(e.target.value)}
              disabled={loading}
              className="w-full border border-gray-300 rounded-lg px-4 py-2 focus:outline-none focus:ring-2 focus:ring-[#0F6466] focus:border-transparent transition"
            >
              <option value="">-- Select Datesheet --</option>
              {datesheets.map((d) => (
                <option key={d._id} value={d.datesheetName}>
                  {d.datesheetName} — {d.className}
                </option>
              ))}
            </select>
          </div>

          {/* Class */}
          <div>
            <label className="block mb-2 font-medium text-gray-800">
              Select Class
            </label>
            <select
              value={selectedClass}
              onChange={(e) => setSelectedClass(e.target.value)}
              disabled={loading || !selectedDatesheet}
              className="w-full border border-gray-300 rounded-lg px-4 py-2 focus:outline-none focus:ring-2 focus:ring-[#0F6466] focus:border-transparent transition"
            >
              <option value="">-- Select Class --</option>
              {classes.map((cls) => (
                <option key={cls._id} value={cls.className}>
                  {cls.className} ({cls.classLevel})
                </option>
              ))}
            </select>
          </div>

          {/* Roll No */}
          <div>
            <label className="block mb-2 font-medium text-gray-800">
              Enter Roll No
            </label>
            <input
              type="text"
              value={rollNo}
              onChange={handleRollNoChange}
              disabled={loading || !selectedClass}
              maxLength={9}
              placeholder="e.g. 200300002"
              className="w-full border border-gray-300 rounded-lg px-4 py-2 focus:outline-none focus:ring-2 focus:ring-[#0F6466] focus:border-transparent transition"
            />
          </div>

          {/* Search Button */}
          <button
            onClick={handleSearch}
            disabled={loading || !selectedDatesheet || !selectedClass || !rollNo}
            className={`w-full py-3 rounded-lg text-white font-semibold transition transform ${
              loading
                ? "opacity-50 cursor-not-allowed"
                : "bg-gradient-to-r from-[#0F6466] to-[#18A298] hover:scale-105"
            }`}
          >
            {loading ? "Searching..." : "Search Results"}
          </button>

          {error && (
            <div className="mt-4 text-red-700 font-medium">{error}</div>
          )}
        </div>

        {studentResult.length > 0 && (
          <div className="mt-8 overflow-x-auto rounded-lg bg-white bg-opacity-30 p-4">
            <h2 className="text-2xl font-semibold mb-4 text-gray-800">
              Results
            </h2>
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="bg-opacity-50" style={{ backgroundColor: "#0F6466" }}>
                  <th className="px-4 py-2 text-white">Course</th>
                  <th className="px-4 py-2 text-white text-center">Total</th>
                  <th className="px-4 py-2 text-white text-center">Obtained</th>
                  <th className="px-4 py-2 text-white text-center">Grade</th>
                </tr>
              </thead>
              <tbody>
                {studentResult.map((rec, i) => (
                  <tr
                    key={i}
                    className={i % 2 === 0 ? "bg-white bg-opacity-50" : ""}
                  >
                    <td className="px-4 py-2">{rec.course}</td>
                    <td className="px-4 py-2 text-center">{rec.totalMarks}</td>
                    <td className="px-4 py-2 text-center">{rec.obtainedMarks}</td>
                    <td className="px-4 py-2 text-center font-semibold">
                      {rec.grade}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}
