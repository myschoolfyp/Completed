"use client";
import { useState, useEffect } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import { Trash2, Edit2, Eye, X } from "lucide-react";

const gradients = [
  "from-green-400 to-blue-500",
  "from-purple-400 to-pink-500",
  "from-yellow-400 to-orange-500",
  "from-indigo-400 to-purple-600",
  "from-teal-400 to-cyan-500",
  "from-red-400 to-pink-600",
  "from-blue-400 to-indigo-500",
  "from-lime-400 to-green-500",
];

export default function Classes() {
  const [classes, setClasses] = useState<any[]>([]);
  const [selectedClass, setSelectedClass] = useState<any>(null); // for view
  const router = useRouter();

  useEffect(() => {
    fetchClasses();
  }, []);

  const fetchClasses = async () => {
    const res  = await fetch("/api/Component/A/classes");
    const data = await res.json();
    setClasses(data);
  };

  const deleteClass = async (id: string) => {
    if (!confirm("Are you sure you want to delete this class?")) return;
    const res = await fetch("/api/Component/A/classes", {
      method:  "DELETE",
      headers: { "Content-Type": "application/json" },
      body:    JSON.stringify({ id }),
    });
    if (res.ok) fetchClasses();
    else       alert("Failed to delete class");
  };

  return (
    <div className="p-8">
      <div className="flex justify-between items-center mb-8">
        <h1 className="text-3xl font-bold text-[#0F6466]">Class Management</h1>
        <div className="flex gap-4">
          <Link
            href="/Components/A/Classes/Newclass"
            className="flex items-center bg-gradient-to-r from-purple-500 to-indigo-500 text-white px-6 py-2 rounded-lg hover:opacity-90 transition"
          >
            + Add New Class
          </Link>
          <Link
            href="/Components/A/Courses/Assign"
            className="flex items-center bg-gradient-to-r from-blue-500 to-teal-500 text-white px-6 py-2 rounded-lg hover:opacity-90 transition"
          >
            🎓 Assign Courses
          </Link>
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
        {classes.map((cls, idx) => (
          <div
            key={cls._id}
            className={`group relative p-8 min-h-[220px] rounded-lg text-white shadow-md transition-shadow hover:shadow-xl bg-gradient-to-br ${gradients[idx % gradients.length]}`}
          >
            <h3 className="text-2xl font-bold mb-2">{cls.className}</h3>
            <p className="opacity-90">Level: {cls.classLevel}</p>
            {cls.stream && <p className="opacity-90">Stream: {cls.stream}</p>}

            <div className="
              absolute inset-0 bg-black bg-opacity-50
              flex items-center justify-center space-x-4
              opacity-0 group-hover:opacity-100 transition-opacity
            ">
              <button
                className="flex items-center bg-white text-gray-800 px-3 py-1 rounded hover:bg-gray-100"
                onClick={() => setSelectedClass(cls)}
              >
                <Eye size={16} className="mr-1" /> View
              </button>
              <button
                className="flex items-center bg-white text-gray-800 px-3 py-1 rounded hover:bg-gray-100"
                onClick={() =>
                  router.push(`/Components/A/Classes/Edit?classId=${cls._id}`)
                }
              >
                <Edit2 size={16} className="mr-1" /> Edit
              </button>
              <button
                className="flex items-center bg-red-500 text-white px-3 py-1 rounded hover:bg-red-600"
                onClick={() => deleteClass(cls._id)}
              >
                <Trash2 size={16} className="mr-1" /> Delete
              </button>
            </div>
          </div>
        ))}
      </div>

      {/* View Modal */}
      {selectedClass && (
  <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 overflow-auto">
    <div className="bg-white w-[90%] max-w-2xl p-6 rounded-lg relative shadow-lg">
      <button
        className="absolute top-3 right-3 text-gray-600 hover:text-black"
        onClick={() => setSelectedClass(null)}
      >
        <X size={24} />
      </button>
      <h2 className="text-2xl font-bold mb-6 text-center text-[#0F6466]">Class Full Details</h2>

      <div className="space-y-4">
        <div>
          <p><strong>Class Name:</strong> {selectedClass.className}</p>
          <p><strong>Level:</strong> {selectedClass.classLevel}</p>
          <p><strong>Stream:</strong> {selectedClass.stream}</p>
        </div>

        <div>
          <h3 className="text-lg font-semibold text-gray-700 mt-4 mb-2">Students:</h3>
          {selectedClass.students && selectedClass.students.length > 0 ? (
            <ul className="list-disc list-inside space-y-1 max-h-40 overflow-y-auto">
              {selectedClass.students.map((student: any, idx: number) => (
                <li key={idx}>
                  {student.name} (Roll No: {student.rollNo})
                </li>
              ))}
            </ul>
          ) : (
            <p className="text-gray-500">No students enrolled.</p>
          )}
        </div>

        <div>
          <h3 className="text-lg font-semibold text-gray-700 mt-4 mb-2">Courses:</h3>
          {selectedClass.courses && selectedClass.courses.length > 0 ? (
            <ul className="list-disc list-inside space-y-1 max-h-40 overflow-y-auto">
              {selectedClass.courses.map((course: any, idx: number) => (
                <li key={idx}>{course.name || course}</li> // safe check
              ))}
            </ul>
          ) : (
            <p className="text-gray-500">No courses assigned.</p>
          )}
        </div>
      </div>
    </div>
  </div>
)}

    </div>
  );
}
