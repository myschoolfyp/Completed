"use client";
export const dynamic = "force-dynamic";

import { useState, useEffect } from "react";

import { useRouter, useSearchParams } from "next/navigation";
import { Trash2, Plus, Save } from "lucide-react";

const gradients = "from-[#0F6466] to-[#2D9F9C]";

interface Student {
  _id: string;
  rollNo: string;
  name: string;
}

export default function EditClass() {
  const router        = useRouter();
  const searchParams  = useSearchParams();
  const classId       = searchParams.get("classId") || "";

  const [loading, setLoading]     = useState(true);
  const [error,   setError]       = useState("");
  const [form,    setForm]        = useState({
    classLevel: "",
    className:  "",
    stream:     "General",
  });
  const [students,      setStudents]      = useState<Student[]>([]);
  const [courses,       setCourses]       = useState<string[]>([]);
  // For adding students:
  const [showSelector,  setShowSelector]  = useState(false);
  const [allStudents,   setAllStudents]   = useState<Student[]>([]);
  const [tray,          setTray]          = useState<Student[]>([]);
  const [selectAll,     setSelectAll]     = useState(false);
  const [selectedLevel, setSelectedLevel] = useState("");
  const [selectedStream,setSelectedStream]= useState("General");

  // Fetch existing class
  useEffect(() => {
    if (!classId) {
      setError("No classId provided");
      setLoading(false);
      return;
    }
    fetch(`/api/Component/A/classes/Edit?classId=${classId}`)
      .then(r => r.json())
      .then(data => {
        if (data.message) {
          setError(data.message);
        } else {
          setForm({
            classLevel: data.classLevel,
            className:  data.className,
            stream:     data.stream,
          });
          setStudents(data.students);
          setCourses(data.courses || []);
        }
      })
      .catch(() => setError("Failed to load class"))
      .finally(() => setLoading(false));
  }, [classId]);

  // Fetch students for selection panel
  const fetchAll = async () => {
    if (!selectedLevel) return alert("Select class level first");
    try {
      const res = await fetch(
        `/api/Component/A/classes/newclass?classLevel=${encodeURIComponent(selectedLevel)}&stream=${encodeURIComponent(selectedStream)}`
      );
      if (!res.ok) throw new Error("Fetch failed");
      setAllStudents(await res.json());
    } catch (e: any) {
      alert(e.message || "Error fetching students");
    }
  };

  // Tray management
  const toggleSelectAll = () => {
    if (!selectAll) {
      setTray(allStudents);
    } else {
      setTray([]);
    }
    setSelectAll(!selectAll);
  };
  const addTray = () => {
    setStudents(prev => {
      const newOnes = tray.filter(s => !prev.some(p => p._id === s._id));
      return prev.concat(newOnes);
    });
    setShowSelector(false);
    setTray([]);
    setSelectAll(false);
  };
  const removeStudent = (id: string) => {
    setStudents(prev => prev.filter(s => s._id !== id));
  };

  // Course management
  const addCourse = () => {
    const name = prompt("Enter new course name (e.g. Math - 2)");
    if (name && !courses.includes(name)) {
      setCourses(prev => [...prev, name]);
    }
  };
  const removeCourse = (idx: number) => {
    setCourses(prev => prev.filter((_, i) => i !== idx));
  };

  // Submit updated class
  const handleSave = async () => {
    try {
      const res = await fetch("/api/Component/A/classes/Edit", {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          classId,
          ...form,
          students: students.map(s => s.rollNo),
          courses,
        }),
      });
      const json = await res.json();
      if (!res.ok) throw new Error(json.message);
      alert("Class updated!");
      router.push("/Components/A/Classes");
    } catch (e: any) {
      alert(e.message || "Failed to update");
    }
  };

  if (loading) return <p className="p-8 text-center">Loading…</p>;
  if (error)   return <p className="p-8 text-red-500 text-center">{error}</p>;

  return (
    <div className="p-8 max-w-4xl mx-auto space-y-6">
      <h1 className={`text-3xl font-bold text-white p-4 rounded-lg bg-gradient-to-r ${gradients}`}>
        Edit Class: {form.className}
      </h1>

      {/* Basic Info */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div>
          <label className="block mb-1">Class Level</label>
          <select
            className="w-full p-2 border rounded"
            value={form.classLevel}
            onChange={e => setForm(f => ({ ...f, classLevel: e.target.value }))}
          >
            <option value="">Select Level</option>
            {Array.from({ length: 10 }, (_, i) => `Class ${i+1}`).map(l => (
              <option key={l} value={l}>{l}</option>
            ))}
          </select>
        </div>
        <div>
          <label className="block mb-1">Class Name</label>
          <input
            className="w-full p-2 border rounded"
            value={form.className}
            onChange={e => setForm(f => ({ ...f, className: e.target.value }))}
          />
        </div>
        {["Class 9","Class 10"].includes(form.classLevel) && (
          <div>
            <label className="block mb-1">Stream</label>
            <select
              className="w-full p-2 border rounded"
              value={form.stream}
              onChange={e => setForm(f => ({ ...f, stream: e.target.value }))}
            >
              {["Arts","Science","Computer"].map(s => (
                <option key={s} value={s}>{s}</option>
              ))}
            </select>
          </div>
        )}
      </div>

      {/* Students Section */}
      <div className="bg-white p-4 rounded-lg shadow space-y-4">
        <div className="flex justify-between items-center">
          <h2 className="text-xl font-semibold">Students</h2>
          <button
            className="flex items-center text-white bg-gradient-to-r from-[#0F6466] to-[#2D9F9C] px-3 py-1 rounded"
            onClick={() => setShowSelector(true)}
          >
            <Plus size={16} className="mr-1"/> Add
          </button>
        </div>
        <ul className="space-y-2">
          {students.map(s => (
            <li key={s._id} className="flex justify-between bg-gray-50 p-2 rounded">
              <span>{s.name} ({s.rollNo})</span>
              <button onClick={() => removeStudent(s._id)}>
                <Trash2 size={16} className="text-red-600"/>
              </button>
            </li>
          ))}
        </ul>
      </div>

      {/* Student Selector Modal */}
      {showSelector && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4">
          <div className="bg-white w-full max-w-2xl p-6 rounded-lg shadow-lg space-y-4">
            <h3 className="text-lg font-semibold">Select Students to Add</h3>
            <div className="grid grid-cols-2 gap-4">
              <select
                className="p-2 border rounded"
                value={selectedLevel}
                onChange={e => setSelectedLevel(e.target.value)}
              >
                <option value="">Level</option>
                {Array.from({ length: 10 }, (_, i) => `Class ${i+1}`).map(l => (
                  <option key={l} value={l}>{l}</option>
                ))}
              </select>
              {["Class 9","Class 10"].includes(selectedLevel) && (
                <select
                  className="p-2 border rounded"
                  value={selectedStream}
                  onChange={e => setSelectedStream(e.target.value)}
                >
                  {["Arts","Science","Computer"].map(s => (
                    <option key={s} value={s}>{s}</option>
                  ))}
                </select>
              )}
              <button
                className="bg-[#0F6466] text-white p-2 rounded"
                onClick={fetchAll}
              >
                Fetch
              </button>
            </div>
            <div className="overflow-y-auto max-h-64 border rounded">
              <table className="w-full">
                <thead className="bg-gray-100">
                  <tr>
                    <th className="p-2">
                      <input type="checkbox" checked={selectAll} onChange={toggleSelectAll}/>
                    </th>
                    <th className="p-2">Name</th>
                    <th className="p-2">Roll No</th>
                  </tr>
                </thead>
                <tbody>
                  {allStudents.map(s => (
                    <tr key={s._id} className="even:bg-gray-50">
                      <td className="p-2">
                        <input
                          type="checkbox"
                          checked={tray.some(t => t._id === s._id)}
                          onChange={() => {
                            setTray(prev => 
                              prev.some(t => t._id===s._id)
                                ? prev.filter(x=>x._id!==s._id)
                                : [...prev, s]
                            );
                          }}
                        />
                      </td>
                      <td className="p-2">{s.name}</td>
                      <td className="p-2">{s.rollNo}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
            <div className="flex justify-end space-x-4">
              <button className="px-4 py-2" onClick={()=>setShowSelector(false)}>Cancel</button>
              <button className="px-4 py-2 bg-[#0F6466] text-white rounded" onClick={addTray}>
                Add Selected
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Courses Section */}
      <div className="bg-white p-4 rounded-lg shadow space-y-4">
        <div className="flex justify-between items-center">
          <h2 className="text-xl font-semibold">Courses</h2>
          <button
            className="flex items-center text-white bg-gradient-to-r from-[#0F6466] to-[#2D9F9C] px-3 py-1 rounded"
            onClick={addCourse}
          >
            <Plus size={16} className="mr-1"/> Add
          </button>
        </div>
        <ul className="space-y-2">
          {courses.map((c, i) => (
            <li key={i} className="flex justify-between bg-gray-50 p-2 rounded">
              <span>{c}</span>
              <button onClick={() => removeCourse(i)}>
                <Trash2 size={16} className="text-red-600"/>
              </button>
            </li>
          ))}
        </ul>
      </div>

      {/* Save */}
      <div className="text-right">
        <button
          className="inline-flex items-center bg-gradient-to-r from-[#0F6466] to-[#2D9F9C] text-white px-6 py-2 rounded-lg"
          onClick={handleSave}
        >
          <Save size={16} className="mr-2"/> Save Changes
        </button>
      </div>
    </div>
  );
}
