// src/app/Component/A/Announcements/page.tsx
"use client";

import { useState, useEffect } from "react";
import { Plus, Trash2 } from "lucide-react";

interface Recipient {
  _id: string;
  cnic?: string;
  rollNo?: string;
  firstName: string;
  lastName: string;
  classLevel?: string;
  department?: string;
}

interface Reply {
  senderCnic: string;
  senderName: string;
  description: string;
  date: string;
}

interface Announcement {
  _id: string;
  stream: Stream;
  description: string;
  recipients: string[];
  date: string;
  replies?: Reply[];
}

type Stream = "admins" | "teachers" | "parents" | "students";

const APIPATH = "/api/Component/A/Announcements";
const STUDENT_CLASSES = ["Class 1","Class 2","Class 3","Class 4","Class 5"];
const TEACHER_DEPTS = ["Arts","Maths","Chem","Physics","English","Urdu","Islamiat","History"];

export default function Announcements() {
  const [mode, setMode] = useState<"new"|"replies"|"sent">("new");
  const [stream, setStream] = useState<Stream>("admins");

  const [list, setList] = useState<Recipient[]>([]);
  const [filtered, setFiltered] = useState<Recipient[]>([]);
  const [selected, setSelected] = useState<string[]>([]);
  const [search, setSearch] = useState("");
  const [filterClass, setFilterClass] = useState<string>("");
  const [filterDept, setFilterDept] = useState<string>("");

  const [description, setDescription] = useState("");
  const [file, setFile] = useState<File|null>(null);
  const [sentList, setSentList] = useState<Announcement[]>([]);
  const [repliesList, setRepliesList] = useState<Announcement[]>([]);

  const [adminCnic, setAdminCnic] = useState<string>("");
  useEffect(() => {
    setAdminCnic(localStorage.getItem("adminCnic") || "");
  }, []);

  // fetch for "new" and "sent"
  useEffect(() => {
    if (mode === "new") fetchStream();
    if (mode === "sent") fetchSent();
  }, [mode, stream, adminCnic]);

  // fetch for "replies"
  useEffect(() => {
    if (mode === "replies") fetchReplies();
  }, [mode]);

  // filtering recipients
  useEffect(() => {
    let temp = list.filter(u =>
      `${u.firstName} ${u.lastName}`.toLowerCase().includes(search.toLowerCase()) ||
      (u.cnic||u.rollNo||"").includes(search)
    );
    if (stream === "students" && filterClass) {
      temp = temp.filter(u => u.classLevel === filterClass);
    }
    if (stream === "teachers" && filterDept) {
      temp = temp.filter(u => u.department === filterDept);
    }
    setFiltered(temp);
  }, [search, list, filterClass, filterDept, stream]);

  async function fetchStream() {
    const url = `/api/Component/A/${stream.charAt(0).toUpperCase()+stream.slice(1)}`;
    const res = await fetch(url);
    const data: Recipient[] = await res.json();
    setList(data);
    setSelected([]);
    setSearch("");
  }

  async function fetchSent() {
    const res = await fetch(`${APIPATH}?sender=${adminCnic}`);
    setSentList(await res.json());
  }

  async function fetchReplies() {
    const res = await fetch(APIPATH);
    const all: Announcement[] = await res.json();
    // only keep those that have at least one reply
    setRepliesList(all.filter(a => Array.isArray(a.replies) && a.replies.length > 0));
  }

  function toggle(id: string) {
    setSelected(s => s.includes(id) ? s.filter(x=>x!==id) : [...s, id]);
  }

  async function handleSend() {
    const recipients = selected.map(id => {
      const u = list.find(x => x._id === id)!;
      return stream === "students" ? u.rollNo! : u.cnic!;
    });

    const form = new FormData();
    form.append("stream", stream);
    form.append("recipients", JSON.stringify(recipients));
    form.append("sender", adminCnic);
    form.append("description", description);
    if (file) form.append("attachment", file);

    const res = await fetch(APIPATH, { method: "POST", body: form });
    const json = await res.json();
    if (res.ok) {
      alert("✅ Announcement sent!");
      setMode("sent");
      setDescription("");
      setFile(null);
      setSelected([]);
    } else {
      console.error(json);
      alert("❌ Failed to send. See console.");
    }
  }

  async function handleDelete(id: string) {
    await fetch(APIPATH, {
      method: "DELETE",
      headers: {"Content-Type":"application/json"},
      body: JSON.stringify({ id }),
    });
    setSentList(s => s.filter(x => x._id !== id));
  }

  return (
    <div className="p-6 space-y-6 bg-gray-50 rounded-2xl shadow-lg">
      {/* Mode Tabs */}
      <div className="flex space-x-4">
        {["new","replies","sent"].map(m => (
          <button
            key={m}
            className={`flex-1 py-2 rounded-xl text-center font-medium 
              ${mode===m
                ? "bg-gradient-to-r from-indigo-500 to-purple-600 text-white shadow"
                : "bg-white text-gray-600"
              }`}
            onClick={() => setMode(m as any)}
          >
            {m.charAt(0).toUpperCase()+m.slice(1)}
          </button>
        ))}
      </div>

      {/* NEW Mode */}
      {mode==="new" && (
        <div className="space-y-4">
          {/* Stream selector */}
          <div className="flex space-x-3">
            {(["admins","teachers","parents","students"] as Stream[]).map(s => (
              <button
                key={s}
                className={`px-3 py-1 rounded-lg font-medium 
                  ${stream===s ? "bg-gradient-to-r from-indigo-500 to-purple-600 text-white" : "bg-white text-gray-700"}`}
                onClick={()=>{setStream(s); setFilterClass(""); setFilterDept("");}}
              >
                {s.charAt(0).toUpperCase()+s.slice(1)}
              </button>
            ))}
          </div>

          {/* Search & filter */}
          <div className="flex flex-wrap gap-4">
            <input
              type="text"
              placeholder="Search..."
              className="flex-1 border p-2 rounded-lg"
              value={search}
              onChange={e=>setSearch(e.target.value)}
            />
            {stream==="students" && (
              <select
                value={filterClass}
                onChange={e=>setFilterClass(e.target.value)}
                className="border p-2 rounded-lg"
              >
                <option value="">All Classes</option>
                {STUDENT_CLASSES.map(c=>(<option key={c} value={c}>{c}</option>))}
              </select>
            )}
            {stream==="teachers" && (
              <select
                value={filterDept}
                onChange={e=>setFilterDept(e.target.value)}
                className="border p-2 rounded-lg"
              >
                <option value="">All Departments</option>
                {TEACHER_DEPTS.map(d=>(<option key={d} value={d}>{d}</option>))}
              </select>
            )}
          </div>

          {/* Recipients */}
          <div className="overflow-x-auto">
            <table className="w-full bg-white rounded-xl shadow">
              <thead className="bg-gray-100">
                <tr>
                  <th className="p-3">
                    <input
                      type="checkbox"
                      onChange={e=>setSelected(
                        e.target.checked ? filtered.map(u=>u._id) : []
                      )}
                      checked={filtered.length>0 && selected.length===filtered.length}
                    />
                  </th>
                  <th className="p-3 text-left">Name</th>
                  <th className="p-3 text-left">{stream==="students"?"Roll No":"CNIC"}</th>
                  {stream==="students" && <th className="p-3 text-left">Class</th>}
                  {stream==="teachers" && <th className="p-3 text-left">Dept</th>}
                </tr>
              </thead>
              <tbody>
                {filtered.map(u=>(
                  <tr key={u._id} className="even:bg-gray-50">
                    <td className="p-2 text-center">
                      <input
                        type="checkbox"
                        checked={selected.includes(u._id)}
                        onChange={()=>toggle(u._id)}
                      />
                    </td>
                    <td className="p-2">{u.firstName} {u.lastName}</td>
                    <td className="p-2">{stream==="students"?u.rollNo:u.cnic}</td>
                    {stream==="students" && <td className="p-2">{u.classLevel}</td>}
                    {stream==="teachers" && <td className="p-2">{u.department}</td>}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {/* Description & Send */}
          <div className="space-y-3">
            <textarea
              placeholder="Announcement description..."
              className="w-full border p-3 rounded-lg h-28"
              value={description}
              onChange={e=>setDescription(e.target.value)}
            />
            <div className="flex items-center gap-4">
              <button
                className="ml-auto bg-gradient-to-r from-green-400 to-blue-500 hover:from-green-500 hover:to-blue-600 text-white px-6 py-2 rounded-xl shadow-md flex items-center gap-2"
                onClick={handleSend}
                disabled={!selected.length || !description}
              >
                <Plus size={18}/> Send
              </button>
            </div>
          </div>
        </div>
      )}

      {/* SENT Mode */}
      {mode==="sent" && (
        <div className="space-y-4">
          <h2 className="text-xl font-semibold text-gray-700">Sent Announcements</h2>
          <div className="overflow-x-auto">
            <table className="w-full bg-white rounded-xl shadow">
              <thead className="bg-gray-100">
                <tr>
                  <th className="p-3">Date</th>
                  <th className="p-3">Stream</th>
                  <th className="p-3"># Recipients</th>
                  <th className="p-3">Description</th>
                  <th className="p-3">Action</th>
                </tr>
              </thead>
              <tbody>
                {sentList.map(a=>(
                  <tr key={a._id} className="even:bg-gray-50">
                    <td className="p-2">{new Date(a.date).toLocaleString()}</td>
                    <td className="p-2 capitalize">{a.stream}</td>
                    <td className="p-2 text-center">{a.recipients.length}</td>
                    <td className="p-2">{a.description}</td>
                    <td className="p-2">
                      <button
                        className="bg-red-500 hover:bg-red-600 text-white p-2 rounded-full"
                        onClick={()=>handleDelete(a._id)}
                      >
                        <Trash2 size={16}/>
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* REPLIES Mode */}
      {mode==="replies" && (
        <div className="space-y-4">
          <h2 className="text-xl font-semibold text-gray-700">Announcement Replies</h2>
          <div className="overflow-x-auto">
            <table className="w-full bg-white rounded-xl shadow">
              <thead className="bg-gray-100">
                <tr>
                  <th className="p-3">Announcement</th>
                  <th className="p-3">Reply</th>
                  <th className="p-3">Replier</th>
                  <th className="p-3">CNIC / Roll No.</th>
                  <th className="p-3">Date</th>
                </tr>
              </thead>
              <tbody>
                {repliesList.flatMap(a =>
                  a.replies!.map((r, idx) => (
                    <tr key={`${a._id}-${idx}`} className="even:bg-gray-50">
                      <td className="p-2">{a.description}</td>
                      <td className="p-2">{r.description}</td>
                      <td className="p-2">{r.senderName}</td>
                      <td className="p-2">{r.senderCnic}</td>
                      <td className="p-2">{new Date(r.date).toLocaleString()}</td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
}
