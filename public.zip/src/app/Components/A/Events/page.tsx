// @ts-nocheck
"use client";

import { useEffect, useState } from "react";
// @ts-ignore
import { Calendar, momentLocalizer, View } from "react-big-calendar";
// @ts-ignore
import moment from "moment";
import "react-big-calendar/lib/css/react-big-calendar.css";

import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";

const localizer = momentLocalizer(moment);
const primaryColor = "#0F6466";

export default function AdminEventsPage() {
  const [events, setEvents]     = useState<any[]>([]);
  const [dialogOpen, setDialog] = useState(false);
  const [mode, setMode]         = useState<"add"|"edit">("add");
  const [current, setCurrent]   = useState<any>({});
  const [form, setForm]         = useState<any>({});
  const [date, setDate]         = useState<Date>(new Date());
  const [view, setView]         = useState<View>("month");

  useEffect(() => { fetchEvents(); }, []);

  async function fetchEvents() {
    const res = await fetch("/api/Component/A/Events");
    const data = await res.json();
    setEvents(Array.isArray(data) ? data : []);
  }

  function openAdd() {
    setMode("add");
    setCurrent({});
    setForm({});
    setDialog(true);
  }

  function openEdit(evt: any) {
    setMode("edit");
    setCurrent(evt);
    // preload form, including date strings
    setForm({
      ...evt,
      start: evt.start.toISOString().slice(0,10),
      end:   evt.end   ? evt.end.toISOString().slice(0,10) : "",
      image: null, // reset file input
    });
    setDialog(true);
  }

  async function handleDelete() {
    await fetch(`/api/Component/A/Events?id=${current._id}`, { method: "DELETE" });
    setDialog(false);
    setForm({});
    setCurrent({});
    fetchEvents();
  }

  async function handleSubmit() {
    const fd = new FormData();
    if (mode === "edit") fd.append("id", current._id);
    Object.entries(form).forEach(([k, v]) => {
      if (v) fd.append(k, v as any);
    });
    await fetch(
      "/api/Component/A/Events",
      { method: mode==="add"?"POST":"PUT", body: fd }
    );
    setDialog(false);
    setForm({});
    setCurrent({});
    fetchEvents();
  }

  return (
    <div className="p-4">
      <div className="flex justify-between items-center mb-4">
        <h1 className="text-2xl font-bold text-[#0F6466]">Event Calendar</h1>
        <Button className="bg-[#0F6466] text-white" onClick={openAdd}>
          Add New Event
        </Button>
      </div>

      <div className="bg-white shadow-lg p-2 rounded-lg border" style={{ height: "50vh" }}>
        <Calendar
          localizer={localizer}
          events={events.map(e => ({
            ...e,
            start: new Date(e.start),
            end:   new Date(e.end || e.start),
            title: e.title,
          }))}
          startAccessor="start"
          endAccessor="end"
          views={["month","week","day","agenda"] as View[]}
          date={date}
          view={view}
          onNavigate={(newDate) => setDate(newDate)}
          onView={(newView)   => setView(newView as View)}
          onSelectEvent={openEdit}
          style={{ height: "100%" }}
          eventPropGetter={() => ({
            style: {
              backgroundColor: primaryColor,
              color: "white",
              borderRadius: "6px",
              border: "none",
            },
          })}
        />
      </div>

      <Dialog open={dialogOpen} onOpenChange={setDialog}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>{mode==="add" ? "Add New Event" : "Edit Event"}</DialogTitle>
          </DialogHeader>

          <div className="grid gap-3 my-4">
            <Input
              name="title"
              required
              value={form.title || ""}
              onChange={e => setForm(f => ({ ...f, title: e.target.value }))}
              placeholder="Event Name *"
            />
            <Input
              name="start"
              type="date"
              value={form.start||""}
              onChange={e => setForm(f => ({ ...f, start: e.target.value }))}
            />
            <Input
              name="end"
              type="date"
              value={form.end||""}
              onChange={e => setForm(f => ({ ...f, end: e.target.value }))}
            />
            <Input
              name="location"
              value={form.location||""}
              onChange={e => setForm(f => ({ ...f, location: e.target.value }))}
              placeholder="Location"
            />
            <Input
              name="time"
              value={form.time||""}
              onChange={e => setForm(f => ({ ...f, time: e.target.value }))}
              placeholder="Time"
            />
            <Textarea
              name="description"
              value={form.description||""}
              onChange={e => setForm(f => ({ ...f, description: e.target.value }))}
              placeholder="Description"
            />

            {/* file input */}
            <Input
              name="image"
              type="file"
              accept="image/*"
              onChange={e => {
                const file = (e.target as any).files?.[0];
                setForm(f => ({ ...f, image: file }));
              }}
            />

            {/* preview */}
            {mode==="edit" && current.imageUrl && (
  <img
    src={current.imageUrl}
    alt="Preview"
    className="mt-2 max-h-40 object-contain"
  />
)}

          </div>

          <div className="flex justify-end space-x-2">
            {mode==="edit" && (
              <Button className="bg-red-600 text-white" onClick={handleDelete}>
                Delete
              </Button>
            )}
            <Button onClick={() => setDialog(false)}>Cancel</Button>
            <Button className="bg-[#0F6466] text-white" onClick={handleSubmit}>
              {mode==="add" ? "Create" : "Save"}
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
