"use client";

import { useState, useEffect } from "react";
import { useRouter } from "next/navigation";

interface Teacher {
  _id: string;
  cnic: string;
  firstName: string;
  lastName: string;
  email: string;
  contactNumber: string;
  department: string;
}

interface TeacherForm {
  firstName: string;
  lastName: string;
  cnic: string;
  department: string;
  email: string;
  contactNumber: string;
  password: string;
}

const API = "/api/Component/A/Teachers";
const departments = [
  "Arts", "Maths", "Chem", "Physics",
  "English", "Urdu", "Islamiat", "History"
];

export default function Teachers() {
  const router = useRouter();

  // All teachers list + filter
  const [teachers, setTeachers] = useState<Teacher[]>([]);
  const [searchTerm, setSearchTerm] = useState("");

  // Add form
  const [showAddForm, setShowAddForm] = useState(false);
  const [newTeacher, setNewTeacher] = useState<TeacherForm>({
    firstName: "",
    lastName: "",
    cnic: "",
    department: "",
    email: "",
    contactNumber: "",
    password: ""
  });

  // Update form
  const [showUpdateForm, setShowUpdateForm] = useState(false);
  const [updateCnic, setUpdateCnic] = useState("");
  const [updateTeacher, setUpdateTeacher] = useState<Partial<TeacherForm> & { _id?: string; email?: string; cnic?: string }>({});

  // Error / success messaging
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);

  // Initial load
  useEffect(() => {
    fetchTeachers();
  }, []);

  async function fetchTeachers() {
    try {
      const res = await fetch(API);
      if (res.ok) setTeachers(await res.json());
    } catch (e) {
      console.error(e);
    }
  }

  // ── ADD TEACHER ───────────────────────────────────────────────────────────────
  function validateAdd() {
    const { firstName, lastName, cnic, email, department, contactNumber, password } = newTeacher;
    if (![firstName, lastName, cnic, email, department, contactNumber, password].every(Boolean)) {
      setError("All fields are required.");
      return false;
    }
    if (!/^[A-Za-z]+$/.test(firstName) || !/^[A-Za-z]+$/.test(lastName)) {
      setError("Names must contain letters only.");
      return false;
    }
    if (!/^\d{13}$/.test(cnic)) {
      setError("CNIC must be exactly 13 digits.");
      return false;
    }
    if (!email.includes("@")) {
      setError("Email must include “@”.");
      return false;
    }
    setError(null);
    return true;
  }

  async function handleAdd() {
    if (!validateAdd()) return;
    try {
      const res = await fetch(API, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(newTeacher)
      });
      const data = await res.json();
      if (res.ok) {
        setSuccess("Teacher added successfully!");
        setNewTeacher({ firstName: "", lastName: "", cnic: "", department: "", email: "", contactNumber: "", password: "" });
        fetchTeachers();
      } else {
        setError(data.message || "Failed to add teacher.");
      }
    } catch {
      setError("Unexpected error.");
    }
  }

  // ── UPDATE TEACHER ────────────────────────────────────────────────────────────
  async function handleSearch() {
    setError(null);
    setSuccess(null);
    if (!/^\d{13}$/.test(updateCnic)) {
      setError("Enter a valid 13-digit CNIC.");
      return;
    }
    try {
      const res = await fetch(`${API}?cnic=${updateCnic}`);
      if (!res.ok) {
        const err = await res.json();
        setError(err.message || "Teacher not found.");
        return;
      }
      const data: any = await res.json();
      setUpdateTeacher({ ...data, password: "" });
    } catch {
      setError("Error searching for teacher.");
    }
  }

  function validateUpdate() {
    const { firstName, lastName, department, contactNumber, password } = updateTeacher;
    if (![firstName, lastName, department, contactNumber].every(Boolean)) {
      setError("All fields except email & CNIC are required.");
      return false;
    }
    if (!/^[A-Za-z]+$/.test(firstName!) || !/^[A-Za-z]+$/.test(lastName!)) {
      setError("Names must contain letters only.");
      return false;
    }
    if (password && password.length < 6) {
      setError("Password must be at least 6 characters.");
      return false;
    }
    setError(null);
    return true;
  }

  async function handleUpdate() {
    if (!validateUpdate()) return;
    try {
      const payload: any = {
        id: updateTeacher._id,
        firstName: updateTeacher.firstName,
        lastName: updateTeacher.lastName,
        department: updateTeacher.department,
        contactNumber: updateTeacher.contactNumber
      };
      if (updateTeacher.password) payload.password = updateTeacher.password;
      const res = await fetch(API, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload)
      });
      const data = await res.json();
      if (res.ok) {
        setSuccess("Teacher updated successfully!");
        setUpdateTeacher({});
        setUpdateCnic("");
        fetchTeachers();
      } else {
        setError(data.message || "Failed to update.");
      }
    } catch {
      setError("Server error.");
    }
  }

  // ── DELETE TEACHER ────────────────────────────────────────────────────────────
  async function handleDelete(id: string) {
    await fetch(API, {
      method: "DELETE",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ id })
    });
    fetchTeachers();
  }

  const filtered = teachers.filter(t =>
    t.firstName.toLowerCase().includes(searchTerm.toLowerCase()) ||
    t.lastName.toLowerCase().includes(searchTerm.toLowerCase()) ||
    t.cnic.includes(searchTerm)
  );


  return (
    <div className="p-8">
      {/* Header */}
      <div className="flex justify-between mb-6">
        <h1 className="text-3xl font-bold text-[#0F6466]">Teachers Management</h1>
        <button
          className="bg-[#0F6466] text-white px-6 py-3 rounded-lg hover:bg-[#0D4B4C]"
          onClick={() => router.back()}
        >
          Back to Dashboard
        </button>
      </div>

      {/* Mode Buttons */}
      <div className="flex space-x-4 mb-6">
        <button
          className="bg-green-600 text-white px-4 py-2 rounded"
          onClick={() => {
            setShowAddForm(true);
            setShowUpdateForm(false);
            setError(null);
            setSuccess(null);
          }}
        >
          Add Teacher
        </button>
        <button
          className="bg-blue-600 text-white px-4 py-2 rounded"
          onClick={() => {
            setShowUpdateForm(true);
            setShowAddForm(false);
            setError(null);
            setSuccess(null);
          }}
        >
          Update Teacher
        </button>
      </div>

      {/* ADD FORM */}
      {showAddForm && (
        <div className="mb-8 border p-6 rounded shadow">
          {error && <p className="text-red-500 mb-2">{error}</p>}
          {success && <p className="text-green-500 mb-2">{success}</p>}
          <div className="grid grid-cols-3 gap-4 mb-4">
            {[
              { name: "firstName", placeholder: "First Name", type: "text" },
              { name: "lastName", placeholder: "Last Name", type: "text" },
              { name: "cnic", placeholder: "CNIC", type: "text" },
              { name: "email", placeholder: "Email", type: "email" },
              { name: "contactNumber", placeholder: "Contact Number", type: "text" },
              { name: "password", placeholder: "Password", type: "password" }
            ].map(fld => (
              <input
                key={fld.name}
                name={fld.name}
                type={fld.type}
                placeholder={fld.placeholder}
                className="border p-3 rounded-lg"
                value={(newTeacher as any)[fld.name]}
                onChange={e => {
                  setNewTeacher(prev => ({
                    ...prev,
                    [fld.name]: fld.name === "cnic"
                      ? e.target.value.replace(/\D/g, "").slice(0,13)
                      : e.target.value
                  }));
                  setError(null);
                  setSuccess(null);
                }}
              />
            ))}
            <select
              name="department"
              className="border p-3 rounded-lg"
              value={newTeacher.department}
              onChange={e =>
                setNewTeacher(prev => ({ ...prev, department: e.target.value }))
              }
            >
              <option value="">Select Department</option>
              {departments.map(dep => (
                <option key={dep} value={dep}>{dep}</option>
              ))}
            </select>
          </div>
          <div className="flex gap-4">
            <button
              className="bg-[#0F6466] text-white px-6 py-2 rounded-lg"
              onClick={handleAdd}
            >
              Save Teacher
            </button>
            <button
              className="bg-gray-400 text-white px-6 py-2 rounded-lg"
              onClick={() => setShowAddForm(false)}
            >
              Cancel
            </button>
          </div>
        </div>
      )}

      {/* UPDATE FORM */}
      {showUpdateForm && (
        <div className="mb-8 border p-6 rounded shadow">
          <h2 className="text-xl font-semibold mb-4">Search by CNIC</h2>
          {error && <p className="text-red-500 mb-2">{error}</p>}
          {success && <p className="text-green-500 mb-2">{success}</p>}
          <div className="flex items-center mb-4">
            <input
              type="text"
              placeholder="CNIC"
              value={updateCnic}
              onChange={e => setUpdateCnic(e.target.value.replace(/\D/g, "").slice(0,13))}
              className="border p-3 rounded-lg mr-2"
            />
            <button
              className="bg-blue-600 text-white px-4 py-2 rounded"
              onClick={handleSearch}
            >
              Search
            </button>
            <button
              className="ml-2 px-4 py-2 rounded bg-gray-200"
              onClick={() => {
                setUpdateTeacher({});
                setUpdateCnic("");
                setError(null);
                setSuccess(null);
              }}
            >
              Clear
            </button>
          </div>

          {updateTeacher._id && (
            <>
              <h3 className="text-lg font-medium mb-3">Update Details</h3>
              <div className="grid grid-cols-3 gap-4 mb-4">
                <input
                  name="firstName"
                  placeholder="First Name"
                  value={updateTeacher.firstName}
                  onChange={e =>
                    setUpdateTeacher(prev => ({ ...prev, firstName: e.target.value }))
                  }
                  className="border p-3 rounded-lg"
                />
                <input
                  name="lastName"
                  placeholder="Last Name"
                  value={updateTeacher.lastName}
                  onChange={e =>
                    setUpdateTeacher(prev => ({ ...prev, lastName: e.target.value }))
                  }
                  className="border p-3 rounded-lg"
                />
                <select
                  name="department"
                  value={updateTeacher.department}
                  onChange={e =>
                    setUpdateTeacher(prev => ({ ...prev, department: e.target.value }))
                  }
                  className="border p-3 rounded-lg"
                >
                  <option value="">Select Department</option>
                  {departments.map(dep => (
                    <option key={dep} value={dep}>{dep}</option>
                  ))}
                </select>
                <input
                  name="contactNumber"
                  placeholder="Contact Number"
                  value={updateTeacher.contactNumber}
                  onChange={e =>
                    setUpdateTeacher(prev => ({ ...prev, contactNumber: e.target.value }))
                  }
                  className="border p-3 rounded-lg"
                />
                <input
                  name="password"
                  type="password"
                  placeholder="New Password (optional)"
                  value={updateTeacher.password}
                  onChange={e =>
                    setUpdateTeacher(prev => ({ ...prev, password: e.target.value }))
                  }
                  className="border p-3 rounded-lg"
                />
                <input
                  name="cnic"
                  placeholder="CNIC"
                  value={updateTeacher.cnic}
                  disabled
                  className="border p-3 rounded-lg bg-gray-100 cursor-not-allowed"
                />
                <input
                  name="email"
                  placeholder="Email"
                  value={updateTeacher.email}
                  disabled
                  className="border p-3 rounded-lg bg-gray-100 cursor-not-allowed"
                />
              </div>
              <div className="flex gap-4">
                <button
                  className="bg-[#0F6466] text-white px-6 py-2 rounded-lg"
                  onClick={handleUpdate}
                >
                  Save Changes
                </button>
                <button
                  className="bg-gray-400 text-white px-6 py-2 rounded-lg"
                  onClick={() => {
                    setUpdateTeacher({});
                    setError(null);
                    setSuccess(null);
                  }}
                >
                  Cancel
                </button>
              </div>
            </>
          )}
        </div>
      )}

      {/* SEARCH + TABLE */}
      <div className="mb-6">
        <input
          type="text"
          placeholder="Filter by CNIC or name..."
          className="border p-3 rounded-lg w-64"
          value={searchTerm}
          onChange={e => setSearchTerm(e.target.value)}
        />
      </div>
      <table className="w-full border-collapse shadow-lg">
        <thead className="bg-[#0F6466] text-white">
          <tr>
            <th className="p-4">CNIC</th>
            <th className="p-4">First Name</th>
            <th className="p-4">Last Name</th>
            <th className="p-4">Department</th>
            <th className="p-4">Email</th>
            <th className="p-4">Contact</th>
            <th className="p-4">Actions</th>
          </tr>
        </thead>
        <tbody>
          {filtered.map(t => (
            <tr key={t._id} className="border-b hover:bg-gray-50">
              <td className="p-4 text-center">{t.cnic}</td>
              <td className="p-4 text-center">{t.firstName}</td>
              <td className="p-4 text-center">{t.lastName}</td>
              <td className="p-4 text-center">{t.department}</td>
              <td className="p-4 text-center">{t.email}</td>
              <td className="p-4 text-center">{t.contactNumber}</td>
              <td className="p-4 text-center">
                <button
                  onClick={() => handleDelete(t._id)}
                  className="bg-red-500 text-white px-3 py-1 rounded hover:bg-red-600"
                >
                  Delete
                </button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
