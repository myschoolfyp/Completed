'use client';

import React, { useState, useEffect } from 'react';
import { Calendar, momentLocalizer, Views } from 'react-big-calendar';
import moment from 'moment';
import 'react-big-calendar/lib/css/react-big-calendar.css';
import { Dialog, DialogContent } from '@/components/ui/dialog';
import { format } from 'date-fns';
import type { View } from 'react-big-calendar';

const localizer = momentLocalizer(moment);

type EventType = {
  _id?: string;
  title: string;
  description: string;
  start: Date;
  end: Date;
  image?: string;
};

const gradientColors = [
  'linear-gradient(to right, #ff7e5f, #feb47b)',
  'linear-gradient(to right, #6a11cb, #2575fc)',
  'linear-gradient(to right, #ff9966, #ff5e62)',
  'linear-gradient(to right, #00c6ff, #0072ff)',
  'linear-gradient(to right, #f7971e, #ffd200)',
  'linear-gradient(to right, #f953c6, #b91d73)',
  'linear-gradient(to right, #43e97b, #38f9d7)',
  'linear-gradient(to right, #30cfd0, #330867)',
];

export default function TeacherEventsCalendar() {
  const [events, setEvents] = useState<EventType[]>([]);
  const [selectedEvent, setSelectedEvent] = useState<EventType | null>(null);
  const [upcomingEvents, setUpcomingEvents] = useState<EventType[]>([]);
  const [date, setDate] = useState<Date>(new Date());

  const [view, setView] = useState<View>('month');
  


  useEffect(() => {
    fetchEvents();
  }, []);

  const fetchEvents = async () => {
    try {
      const res = await fetch('/api/Component/T/Events');
      const data = await res.json();
      const parsedEvents = data.map((event: EventType) => ({
        ...event,
        start: new Date(event.start),
        end: new Date(event.end),
      }));
      setEvents(parsedEvents);

      const upcoming = parsedEvents
        .filter((event: EventType) => {
          const now = new Date();
          const diff = (event.start.getTime() - now.getTime()) / (1000 * 60 * 60 * 24);
          return diff >= 0 && diff <= 7;
        })
        .sort((a: EventType, b: EventType) => a.start.getTime() - b.start.getTime());

      setUpcomingEvents(upcoming);
    } catch (err) {
      console.error('Error fetching events:', err);
    }
  };

  const eventStyleGetter = (
    event: EventType,
    start: Date,
    end: Date,
    isSelected: boolean
  ) => {
    const index = events.findIndex((e) => e._id === event._id);
    const background = gradientColors[index % gradientColors.length];
    const style = {
      background,
      borderRadius: '8px',
      color: 'white',
      border: 'none',
      display: 'block',
      padding: '4px',
    };
    return {
      style,
    };
  };

  return (
    <div className="p-4 relative">
      <h1 className="text-2xl font-bold mb-4"> Events Calendar</h1>

      <Calendar
        localizer={localizer}
        events={events}
        startAccessor="start"
        endAccessor="end"
        views={[Views.MONTH, Views.WEEK, Views.DAY, Views.AGENDA]}
        date={date}
        view={view}
        onNavigate={(newDate) => setDate(newDate)}
        onView={(newView) => setView(newView)}
        eventPropGetter={eventStyleGetter}
        onSelectEvent={(event: EventType) => setSelectedEvent(event)}
        style={{ height: '60vh', minHeight: 400 }}
      />

      {/* Event Details Modal */}
      {selectedEvent && (
        <Dialog open={true} onOpenChange={() => setSelectedEvent(null)}>
          <DialogContent>
            <h2 className="text-xl font-bold mb-2">{selectedEvent.title}</h2>
            <p className="text-sm text-gray-500 mb-2">
              {format(selectedEvent.start, 'PPpp')} - {format(selectedEvent.end, 'PPpp')}
            </p>
            <p className="mb-2">{selectedEvent.description}</p>
            {selectedEvent.image && (
              <img
                src={selectedEvent.image}
                alt="Event"
                className="w-full h-auto rounded-md"
              />
            )}
          </DialogContent>
        </Dialog>
      )}

      {/* Upcoming Events Section (Below Calendar) */}
      {upcomingEvents.length > 0 && (
        <div className="mt-6 bg-gradient-to-r from-indigo-500 to-purple-500 text-white p-4 shadow-lg rounded-md">
          <h3 className="text-lg font-semibold mb-2">Upcoming Events (Next 7 Days)</h3>
          <div className="flex flex-wrap gap-4 overflow-x-auto">
            {upcomingEvents.map((event) => (
              <div
                key={event._id}
                className="bg-white text-black p-2 rounded-md shadow-md cursor-pointer min-w-[200px]"
                onClick={() => setSelectedEvent(event)}
              >
                <h4 className="font-bold">{event.title}</h4>
                <p className="text-sm">{format(event.start, 'PPpp')}</p>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
