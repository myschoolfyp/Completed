// src/app/Component/T/Complain/page.tsx
"use client";

import { useState, useEffect } from "react";

interface ClassSlot {
  className: string;
  course: string;
  startTime: string;
  endTime: string;
  room: string;
}

interface Entry {
  studentId: string;
  rollNo: string;
  studentName: string;
  parentName: string;
  parentCnic: string;
}

interface Complaint {
  _id: string;
  studentName: string;
  rollNo: string;
  className: string;
  description: string;
  createdAt: string;
  parentReplies?: {
    senderCnic: string;
    senderName: string;
    description: string;
    date: string;
  }[];
}

export default function TeacherComplain() {
  // which tab: new, sent, replies
  const [view, setView] = useState<"new" | "sent" | "replies">("new");

  // teacher info
  const [teacherId, setTeacherId] = useState("");
  const [teacherName, setTeacherName] = useState("");

  // assigned classes
  const [classes, setClasses] = useState<ClassSlot[]>([]);
  const [classLevel, setClassLevel] = useState("");
  const [selectedClass, setSelectedClass] = useState<ClassSlot | null>(null);

  // NEW complaint state
  const [entries, setEntries] = useState<Entry[]>([]);
  const [selected, setSelected] = useState<Record<string, boolean>>({});
  const [description, setDescription] = useState("");
  const [submitting, setSubmitting] = useState(false);

  // SENT complaints
  const [sentList, setSentList] = useState<Complaint[]>([]);
  const [loadingSent, setLoadingSent] = useState(false);

  // REPLIES (parent replies)
  const [replyList, setReplyList] = useState<Complaint[]>([]);
  const [replyText, setReplyText] = useState<Record<string, string>>({});

  // load teacher credentials
  useEffect(() => {
    const tid = localStorage.getItem("teacherId") || "";
    const fn = localStorage.getItem("firstName") || "";
    const ln = localStorage.getItem("lastName") || "";
    setTeacherId(tid);
    setTeacherName(fn && ln ? `${fn} ${ln}` : "");
  }, []);

  // fetch teacher's assigned classes
  useEffect(() => {
    if (!teacherId) return;
    fetch(`/api/Component/T/timetable?teacherId=${teacherId}`)
      .then((r) => r.json())
      .then(setClasses)
      .catch(console.error);
  }, [teacherId]);

  // NEW: fetch entries when switching to "new"
  useEffect(() => {
    if (view !== "new" || !classLevel || !selectedClass) return;
    const qs = new URLSearchParams({
      classLevel,
      className: selectedClass.className,
    });
    fetch(`/api/Component/T/Complain?${qs}`)
      .then((r) => r.json())
      .then((data: Entry[]) => {
        setEntries(data);
        const sel: Record<string, boolean> = {};
        data.forEach((e) => (sel[e.studentId] = false));
        setSelected(sel);
      })
      .catch(console.error);
  }, [view, classLevel, selectedClass]);

  // SENT: fetch sent complaints when switching to "sent"
  useEffect(() => {
    if (view !== "sent" || !teacherId) return;
    setLoadingSent(true);
    const qs = new URLSearchParams({ sent: "true", teacherId });
    fetch(`/api/Component/T/Complain?${qs}`)
      .then((r) => r.json())
      .then((data: Complaint[]) => setSentList(data))
      .catch(console.error)
      .finally(() => setLoadingSent(false));
  }, [view, teacherId]);

  // REPLIES: fetch complaints with parent replies when switching to "replies"
  useEffect(() => {
    if (view !== "replies" || !teacherId) return;
    const qs = new URLSearchParams({ replies: "true", teacherId });
    fetch(`/api/Component/T/Complain?${qs}`)
      .then((r) => r.json())
      .then((data: Complaint[]) => setReplyList(data))
      .catch(console.error);
  }, [view, teacherId]);

  // toggle student selection
  const toggle = (id: string) =>
    setSelected((s) => ({ ...s, [id]: !s[id] }));

  // submit new complaint
  const handleSubmit = async () => {
    if (!description.trim()) {
      alert("Enter a description");
      return;
    }
    const studentIds = Object.keys(selected).filter((id) => selected[id]);
    if (!studentIds.length) {
      alert("Please select at least one student");
      return;
    }
    if (!classLevel || !selectedClass) {
      alert("Please select level & class");
      return;
    }
    if (!teacherId || !teacherName) {
      alert("Teacher credentials not found");
      return;
    }

    setSubmitting(true);
    try {
      const res = await fetch("/api/Component/T/Complain", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          studentIds,
          description,
          classLevel,
          className: selectedClass.className,
          teacherId,
          teacherName,
        }),
      });
      if (!res.ok) throw new Error(res.statusText);
      alert("Complaint submitted!");
      setDescription("");
      setSelected((prev) => {
        const next = { ...prev };
        Object.keys(next).forEach((k) => (next[k] = false));
        return next;
      });
    } catch (e) {
      console.error(e);
      alert("Submission failed");
    } finally {
      setSubmitting(false);
    }
  };

  // delete a sent complaint
  const handleDelete = async (id: string) => {
    if (!confirm("Delete this complaint? This cannot be undone.")) return;
    await fetch("/api/Component/T/Complain", {
      method: "DELETE",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ complaintId: id, teacherId }),
    });
    setSentList((curr) => curr.filter((c) => c._id !== id));
  };

  // reply to a parent reply
  const sendReplyToParent = async (complaintId: string) => {
    const text = (replyText[complaintId] || "").trim();
    if (!text) {
      alert("Reply cannot be empty");
      return;
    }
    await fetch("/api/Component/T/Complain/Reply", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        complaintId,
        teacherId,
        teacherName,
        description: text,
      }),
    });
    setReplyText((prev) => ({ ...prev, [complaintId]: "" }));
  };

  return (
    <div className="max-w-4xl mx-auto p-6 space-y-6 bg-gradient-to-br from-blue-50 to-green-50 rounded-lg shadow-lg">
      {/* Tabs */}
      <div className="flex space-x-4">
        {(["new", "sent", "replies"] as const).map((tab) => (
          <button
            key={tab}
            onClick={() => setView(tab)}
            className={`px-4 py-2 font-medium rounded ${
              view === tab
                ? "bg-gradient-to-r from-blue-600 to-indigo-600 text-white"
                : "bg-white text-gray-700 shadow-sm"
            }`}
          >
            {tab === "new"
              ? "New"
              : tab === "sent"
              ? "Sent"
              : "Replies"}
          </button>
        ))}
      </div>

      {/* NEW */}
      {view === "new" && (
        <>
          <h1 className="text-2xl font-semibold text-gray-800">
            File Complaint to Parents
          </h1>

          {/* Class Level */}
          <div>
            <label className="block mb-1 font-medium">Class Level</label>
            <select
              className="w-1/4 p-2 border rounded"
              value={classLevel}
              onChange={(e) => {
                setClassLevel(e.target.value);
                setSelectedClass(null);
                setEntries([]);
              }}
            >
              <option value="">— level —</option>
              {Array.from({ length: 12 }, (_, i) => i + 1).map((lvl) => (
                <option key={lvl} value={lvl}>
                  {lvl}
                </option>
              ))}
            </select>
          </div>

          {/* Assigned Class */}
          {classLevel && (
            <div>
              <label className="block mb-1 font-medium">
                Your Class
              </label>
              <select
                className="w-full p-2 border rounded"
                value={
                  selectedClass
                    ? classes.findIndex(
                        (c) => c.className === selectedClass.className
                      )
                    : ""
                }
                onChange={(e) => {
                  const idx = Number(e.target.value);
                  setSelectedClass(classes[idx] || null);
                  setEntries([]);
                }}
              >
                <option value="">— class —</option>
                {classes.map((cls, i) => (
                  <option key={i} value={i}>
                    {cls.className} ({cls.course})
                  </option>
                ))}
              </select>
            </div>
          )}

          {/* Entries Table */}
          {entries.length > 0 && (
            <div className="overflow-x-auto">
              <table className="w-full mt-4 border-collapse">
                <thead>
                  <tr className="bg-gray-200">
                    <th className="p-2 border">Send?</th>
                    <th className="p-2 border">Roll No</th>
                    <th className="p-2 border">Student</th>
                    <th className="p-2 border">Parent</th>
                    <th className="p-2 border">CNIC</th>
                  </tr>
                </thead>
                <tbody>
                  {entries.map((e) => (
                    <tr
                      key={e.studentId}
                      className="hover:bg-gray-100"
                    >
                      <td className="p-2 border text-center">
                        <input
                          type="checkbox"
                          checked={selected[e.studentId]}
                          onChange={() => toggle(e.studentId)}
                        />
                      </td>
                      <td className="p-2 border text-center">
                        {e.rollNo}
                      </td>
                      <td className="p-2 border">
                        {e.studentName}
                      </td>
                      <td className="p-2 border">
                        {e.parentName}
                      </td>
                      <td className="p-2 border text-center">
                        {e.parentCnic}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}

          {classLevel &&
            selectedClass &&
            entries.length === 0 && (
              <p className="text-center text-gray-500">
                No students found for level {classLevel} in class{" "}
                {selectedClass.className}.
              </p>
            )}

          {/* Description & Submit */}
          {entries.length > 0 && (
            <>
              <div>
                <label className="block mb-1 font-medium">
                  Complaint Description
                </label>
                <textarea
                  value={description}
                  onChange={(e) =>
                    setDescription(e.target.value)
                  }
                  className="w-full p-2 border rounded h-32"
                  placeholder="Enter complaint details..."
                />
              </div>
              <button
                onClick={handleSubmit}
                disabled={submitting}
                className="px-6 py-2 font-medium text-white rounded bg-gradient-to-r from-green-600 to-teal-600 hover:from-green-700 hover:to-teal-700 disabled:opacity-50"
              >
                {submitting ? "Submitting..." : "Submit Complaint"}
              </button>
            </>
          )}
        </>
      )}

      {/* SENT */}
      {view === "sent" && (
        <>
          <h1 className="text-2xl font-semibold text-gray-800">
            Sent Complaints
          </h1>
          {loadingSent ? (
            <p>Loading…</p>
          ) : sentList.length === 0 ? (
            <p>No complaints sent yet.</p>
          ) : (
            <div className="space-y-4">
              {sentList.map((c) => (
                <div
                  key={c._id}
                  className="p-4 bg-white rounded-lg shadow"
                >
                  <div className="flex justify-between items-start">
                    <div>
                      <div className="font-medium">
                        {c.studentName} ({c.rollNo})
                      </div>
                      <div className="text-sm text-gray-500">
                        {c.className} •{" "}
                        {new Date(c.createdAt).toLocaleString()}
                      </div>
                      <div className="mt-2">
                        {c.description}
                      </div>
                    </div>
                    <button
                      onClick={() => handleDelete(c._id)}
                      className="px-3 py-1 text-sm text-red-600 border border-red-600 rounded hover:bg-red-50"
                    >
                      Delete
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </>
      )}

      {/* REPLIES */}
      {view === "replies" && (
        <>
          <h1 className="text-2xl font-semibold text-gray-800">
            Parent Replies
          </h1>
          {replyList.length === 0 ? (
            <p>No parent replies yet.</p>
          ) : (
            <div className="space-y-6">
              {replyList.map((c) => (
                <div


                  key={c._id}
                  className="p-4 bg-white rounded-lg shadow"
                >
                  <div className="font-medium text-lg">
                    Complaint: {c.description}
                  </div>
                  <div className="text-sm text-gray-500 mb-4">
                    To {c.studentName} ({c.rollNo}) in{" "}
                    {c.className}
                  </div>


                  {(c.parentReplies || []).map((r, i) => (
                    <div
                      key={i}
                      className="p-3 bg-gray-100 rounded mb-4"
                    >
                      <div className="text-sm text-gray-600">
                        {r.senderName} ({r.senderCnic}) at{" "}
                        {new Date(r.date).toLocaleString()}
                      </div>


                      <div className="mt-1">{r.description}</div>


                      

                    </div>
                  ))}



                </div>
              ))}
            </div>
          )}
        </>
      )}
    </div>
  );
}
