// models/Result.ts
import mongoose from "mongoose";
const { Schema } = mongoose;

const studentResultSchema = new Schema({
  studentId:     { type: Schema.Types.ObjectId, ref: "Student", required: true },
  rollNo:        { type: String, required: true },
  name:          { type: String, required: true },
  totalMarks:    { type: Number, required: true },
  obtainedMarks: { type: Number, required: true },
  grade:         { type: String, required: true },
});

const resultSchema = new Schema({
  datesheetId:    { type: Schema.Types.ObjectId, ref: "Datesheet", required: true },
  datesheetName:  { type: String, required: true },
  className:      { type: String, required: true },
  course:         { type: String, required: true },
  totalMarks:     { type: Number, required: true },
  studentResults: { type: [studentResultSchema], default: [] },
  createdAt:      { type: Date, default: Date.now },
}, { collection: "results" });

// — delete any cached copy so we pick up your new schema every time
if (mongoose.models.Result) {
  delete mongoose.models.Result;
}

const ResultModel = mongoose.model("Result", resultSchema);
export default ResultModel;
