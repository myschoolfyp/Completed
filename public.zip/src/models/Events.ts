import mongoose from "mongoose";

const EventSchema = new mongoose.Schema({
  title: String,
  description: String,
  location: String,
  time: String,
  start: Date,
  end: Date,
  image: {
    data: Buffer,
    contentType: String,
  },
});

export default mongoose.models.Event || mongoose.model("Event", EventSchema);
