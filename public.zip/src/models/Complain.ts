// models/Complain.ts
import mongoose from "mongoose";

const ReplySchema = new mongoose.Schema({
  senderCnic:   { type: String, required: true },
  senderName:   { type: String, required: true },
  description:  { type: String, required: true },
  date:         { type: Date,   default: Date.now }
}, { _id: false });

const ComplainSchema = new mongoose.Schema({
  studentId:    { type: mongoose.Schema.Types.ObjectId, required: true },
  studentName:  { type: String,               required: true },
  rollNo:       { type: String,               required: true },
  className:    { type: String,               required: true },

  parentName:   { type: String,               required: true },
  parentCnic:   { type: String,               required: true },
  teacherName:  { type: String,               required: true },
  teacherId:    { type: mongoose.Schema.Types.ObjectId, required: true },

  description:  { type: String,               required: true },
  createdAt:    { type: Date,   default: Date.now },

  parentReplies:  { type: [ReplySchema], default: [] },
  teacherReplies: { type: [ReplySchema], default: [] }
});

export default mongoose.models.Complain ||
  mongoose.model("Complain", ComplainSchema, "complain");
